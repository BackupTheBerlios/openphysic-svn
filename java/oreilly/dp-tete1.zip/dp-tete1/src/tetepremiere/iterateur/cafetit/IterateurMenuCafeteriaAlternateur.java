package tetepremiere.iterateur.cafetit;

import java.util.Iterator;
import java.util.Calendar;

public class IterateurMenuCafeteriaAlternateur implements Iterator {
	Plat[] plats;
	int position;

	public IterateurMenuCafeteriaAlternateur(Plat[] plats) {
		this.plats = plats;
		Calendar maintenant = Calendar.getInstance();
		position = maintenant.DAY_OF_WEEK % 2;
	}
	public Object next() {
		Plat plat = plats[position];
		position = position + 2;
		return plat;
	}
	public boolean hasNext() {
		if (position >= plats.length || plats[position] == null) {
			return false;
		} else {
			return true;
		}
	}
	public void remove() {
		throw new UnsupportedOperationException(
			"IterateurMenuCafeteriaAlternateur ne supporte pas remove()");
	}
}
