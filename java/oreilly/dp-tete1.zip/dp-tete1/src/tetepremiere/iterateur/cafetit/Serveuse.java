package tetepremiere.iterateur.cafetit;

import java.util.Iterator;
  
 
public class Serveuse {
	Menu menuCreperie;
	Menu menuCafeteria;
 
	public Serveuse(Menu menuCreperie, Menu menuCafeteria) {
		this.menuCreperie = menuCreperie;
		this.menuCafeteria = menuCafeteria;
	}
 
	public void afficherMenu() {
		Iterator iterateurCrepe = menuCreperie.creerIterateur();
		Iterator iterateurCafet = menuCafeteria.creerIterateur();

		System.out.println("MENU\n----\nBRUNCH'");
		afficherMenu(iterateurCrepe);
		System.out.println("\nDEJEUNER");
		afficherMenu(iterateurCafet);
	}
 
	private void afficherMenu(Iterator iterateur) {
		while (iterateur.hasNext()) {
			Plat plat = (Plat)iterateur.next();
			System.out.print(plat.getNom() + ", ");
			System.out.print(plat.getPrix() + " -- ");
			System.out.println(plat.getDescription());
		}
	}
 
	public void afficherMenuVegetarien() {
		System.out.println("\nMENU VEGETARIEN\n----\nBRUNCH");
		afficherMenuVegetarien(menuCreperie.creerIterateur());
		System.out.println("\nDEJEUNER");
		afficherMenuVegetarien(menuCafeteria.creerIterateur());
	}
 
	public boolean estPlatVegetarien(String nom) {
		Iterator iterateurCrepe = menuCreperie.creerIterateur();
		if (estVegetarien(nom, iterateurCrepe)) {
			return true;
		}
		Iterator iterateurCafet = menuCafeteria.creerIterateur();
		if (estVegetarien(nom, iterateurCafet)) {
			return true;
		}
		return false;
	}


	private void afficherMenuVegetarien(Iterator iterateur) {
		while (iterateur.hasNext()) {
			Plat plat = (Plat)iterateur.next();
			if (plat.estVegetarien()) {
				System.out.print(plat.getNom());
				System.out.println("\t\t" + plat.getPrix());
				System.out.println("\t" + plat.getDescription());
			}
		}
	}

	private boolean estVegetarien(String nom, Iterator iterateur) {
		while (iterateur.hasNext()) {
			Plat plat = (Plat)iterateur.next();
			if (plat.getNom().equals(nom)) {
				if (plat.estVegetarien()) {
					return true;
				}
			}
		}
		return false;
	}
}
