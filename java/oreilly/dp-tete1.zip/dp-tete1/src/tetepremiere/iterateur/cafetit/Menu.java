package tetepremiere.iterateur.cafetit;

import java.util.Iterator;

public interface Menu {
	public Iterator creerIterateur();
}
