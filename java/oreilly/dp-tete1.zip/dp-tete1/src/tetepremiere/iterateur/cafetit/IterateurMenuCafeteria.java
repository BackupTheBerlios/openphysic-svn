package tetepremiere.iterateur.cafetit;
 
import java.util.Iterator;
  
public class IterateurMenuCafeteria implements Iterator {
	Plat[] liste;
	int position = 0;
 
	public IterateurMenuCafeteria(Plat[] liste) {
		this.liste = liste;
	}
 
	public Object next() {
		Plat plat = liste[position];
		position = position + 1;
		return plat;
	}
 
	public boolean hasNext() {
		if (position >= liste.length || liste[position] == null) {
			return false;
		} else {
			return true;
		}
	}
  
	public void remove() {
		if (position <= 0) {
			throw new IllegalStateException
				("Vous ne pouvez pas supprimer d'élément si vous n'avez pas exécuté au moins un next()");
		}
		if (liste[position-1] != null) {
			for (int i = position-1; i < (liste.length-1); i++) {
				liste[i] = liste[i+1];
			}
			liste[liste.length-1] = null;
		}
	}
}
