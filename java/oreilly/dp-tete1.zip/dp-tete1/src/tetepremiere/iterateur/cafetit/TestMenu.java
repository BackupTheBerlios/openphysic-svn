package tetepremiere.iterateur.cafetit;


public class TestMenu {
	public static void main(String args[]) {
		MenuCreperie menuCreperie = new MenuCreperie();
		MenuCafeteria menuCafeteria = new MenuCafeteria();
		Serveuse serveuse = new Serveuse(menuCreperie, menuCafeteria);
		serveuse.afficherMenu();
		serveuse.afficherMenuVegetarien();

		System.out.println("\nLe client demande : la Soupe du jour est-elle végétarienne ?");
		System.out.print("La serveuse répond : ");
		if (serveuse.estPlatVegetarien("Soupe du jour")) {
			System.out.println("Oui");
		} else {
			System.out.println("Non");
		}
		System.out.println("\nCLe client demande , la Quiche aux épinards est-elle végétarienne ?");
		System.out.print("La serveuse répond : ");
		if (serveuse.estPlatVegetarien("Quiche aux épinards")) {
			System.out.println("Oui");
		} else {
			System.out.println("Non");
		}

	}
}
