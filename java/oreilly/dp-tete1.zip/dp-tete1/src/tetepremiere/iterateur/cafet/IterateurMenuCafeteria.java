package tetepremiere.iterateur.cafet;

public class IterateurMenuCafeteria implements Iterateur {
	Plat[] elements;

	int position = 0;

	public IterateurMenuCafeteria(Plat[] plats) {
		this.elements = plats;
	}

	public Object suivant() {
		Plat plat = elements[position];
		position = position + 1;
		return plat;
	}

	public boolean encore() {
		if (position >= elements.length || elements[position] == null) {
			return false;
		} else {
			return true;
		}
	}
}
