package tetepremiere.iterateur.cafet;

import java.util.ArrayList;

public class IterateurMenuCreperie implements Iterateur {
	ArrayList plats;

	int position = 0;

	public IterateurMenuCreperie(ArrayList plats) {
		this.plats = plats;
	}

	public Object suivant() {
		Object object = plats.get(position);
		position = position + 1;
		return object;
	}

	public boolean encore() {
		if (position >= plats.size()) {
			return false;
		} else {
			return true;
		}
	}
}
