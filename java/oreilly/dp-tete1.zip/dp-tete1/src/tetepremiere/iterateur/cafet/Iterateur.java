package tetepremiere.iterateur.cafet;

public interface Iterateur {
	boolean encore();

	Object suivant();
}
