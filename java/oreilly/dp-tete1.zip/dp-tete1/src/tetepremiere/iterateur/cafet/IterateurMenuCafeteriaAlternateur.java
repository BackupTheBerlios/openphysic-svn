package tetepremiere.iterateur.cafet;

import java.util.Calendar;

public class IterateurMenuCafeteriaAlternateur implements Iterateur {
	Plat[] liste;

	int position;

	public IterateurMenuCafeteriaAlternateur(Plat[] liste) {
		this.liste = liste;
		Calendar maintenant = Calendar.getInstance();
		position = maintenant.DAY_OF_WEEK % 2;
	}

	public Object suivant() {
		Plat plat = liste[position];
		position = position + 2;
		return plat;
	}

	public boolean encore() {
		if (position >= liste.length || liste[position] == null) {
			return false;
		} else {
			return true;
		}
	}

	public String toString() {
		return "Itérateur Menu Cafeteria Alternateur";
	}
}
