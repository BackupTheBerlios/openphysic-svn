package tetepremiere.iterateur.cafet;

public class IterateurTableau implements Iterateur {
	Plat[] plats;

	int position = 0;

	public IterateurTableau(Plat[] plats) {
		this.plats = plats;
	}

	public Object suivant() {
		Plat plat = plats[position];
		position = position + 1;
		return plat;
	}

	public boolean encore() {
		if (position >= plats.length || plats[position] == null) {
			return false;
		} else {
			return true;
		}
	}
}
