package tetepremiere.iterateur.cafet;

public class Serveuse {
	MenuCreperie menuCreperie;

	MenuCafeteria menuCafeteria;

	public Serveuse(MenuCreperie menuCreperie, MenuCafeteria menuCafeteria) {
		this.menuCreperie = menuCreperie;
		this.menuCafeteria = menuCafeteria;
	}

	public void afficherMenu() {
		Iterateur iterateurCrepe = menuCreperie.creerIterateur();
		Iterateur iterateurCafet = menuCafeteria.creerIterateur();

		System.out.println("MENU\n----\nBRUNCH");
		afficherMenu(iterateurCrepe);
		System.out.println("\nDEJEUNER");
		afficherMenu(iterateurCafet);
	}

	private void afficherMenu(Iterateur iterateur) {
		while (iterateur.encore()) {
			Plat plat = (Plat) iterateur.suivant();
			System.out.print(plat.getNom() + ", ");
			System.out.print(plat.getPrix() + " -- ");
			System.out.println(plat.getDescription());
		}
	}

	public void afficherMenuVegetarien() {
		afficherMenuVegetarien(menuCreperie.creerIterateur());
		afficherMenuVegetarien(menuCafeteria.creerIterateur());
	}

	public boolean estPlatVegetarien(String nom) {
		Iterateur iterateurBrunch = menuCreperie.creerIterateur();
		if (estVegetarien(nom, iterateurBrunch)) {
			return true;
		}
		Iterateur iterateurCafet = menuCafeteria.creerIterateur();
		if (estVegetarien(nom, iterateurCafet)) {
			return true;
		}
		return false;
	}

	private void afficherMenuVegetarien(Iterateur iterateur) {
		while (iterateur.encore()) {
			Plat plat = (Plat) iterateur.suivant();
			if (plat.estVegetarien()) {
				System.out.print(plat.getNom());
				System.out.println("\t\t" + plat.getPrix());
				System.out.println("\t" + plat.getDescription());
			}
		}
	}

	private boolean estVegetarien(String nom, Iterateur iterateur) {
		while (iterateur.encore()) {
			Plat plat = (Plat) iterateur.suivant();
			if (plat.getNom().equals(nom)) {
				if (plat.estVegetarien()) {
					return true;
				}
			}
		}
		return false;
	}
}
