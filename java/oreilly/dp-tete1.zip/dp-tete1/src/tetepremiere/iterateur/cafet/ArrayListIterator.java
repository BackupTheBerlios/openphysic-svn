package tetepremiere.iterateur.cafet;

import java.util.ArrayList;

public class ArrayListIterator implements Iterateur {
	ArrayList items;

	int position = 0;

	public ArrayListIterator(ArrayList items) {
		this.items = items;
	}

	public Object suivant() {
		Object object = items.get(position);
		position = position + 1;
		return object;
	}

	public boolean encore() {
		if (position >= items.size()) {
			return false;
		} else {
			return true;
		}
	}
}
