package tetepremiere.iterateur.cafet;

import java.util.*;

public class TestMenu {
	public static void main(String args[]) {
		MenuCreperie menuCreperie = new MenuCreperie();
		MenuCafeteria menuCafeteria = new MenuCafeteria();

		Serveuse serveuse = new Serveuse(menuCreperie, menuCafeteria);

		serveuse.afficherMenu();
	}

	public static void afficherMenu() {
		MenuCreperie menuCreperie = new MenuCreperie();
		MenuCafeteria menuCafeteria = new MenuCafeteria();

		ArrayList platsBrunch = menuCreperie.getPlats();

		for (int i = 0; i < platsBrunch.size(); i++) {
			Plat plat = (Plat) platsBrunch.get(i);
			System.out.print(plat.getNom());
			System.out.println("\t\t" + plat.getPrix());
			System.out.println("\t" + plat.getDescription());
		}

		Plat[] platsDejeuner = menuCafeteria.getPlats();

		for (int i = 0; i < platsDejeuner.length; i++) {
			Plat plat = platsDejeuner[i];
			System.out.print(plat.getNom());
			System.out.println("\t\t" + plat.getPrix());
			System.out.println("\t" + plat.getDescription());
		}
	}
}
