package tetepremiere.iterateur.cafet;

public interface Menu {
	public Iterateur creerIterateur();
}
