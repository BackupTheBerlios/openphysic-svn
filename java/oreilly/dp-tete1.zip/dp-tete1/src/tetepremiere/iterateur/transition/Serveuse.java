package tetepremiere.iterateur.transition;
import java.util.*;
  
     
public class Serveuse {
	ArrayList menus;
     
  
	public Serveuse(ArrayList menus) {
		this.menus = menus;
	}
   
	public void afficherMenu() {
		Iterator menuIterator = menus.iterator();
		while(menuIterator.hasNext()) {
			Menu menu = (Menu)menuIterator.next();
			afficherMenu(menu.createIterator());
		}
	}
   
	void afficherMenu(Iterator iterateur) {
		while (iterateur.hasNext()) {
			Plat plat = (Plat)iterateur.next();
			System.out.print(plat.getNom() + ", ");
			System.out.print(plat.getPrix() + " -- ");
			System.out.println(plat.getDescription());
		}
	}
}  
