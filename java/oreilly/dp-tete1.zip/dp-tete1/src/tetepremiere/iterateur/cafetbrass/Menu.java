package tetepremiere.iterateur.cafetbrass;

import java.util.Iterator;

public interface Menu {
	public Iterator creerIterateur();
}
