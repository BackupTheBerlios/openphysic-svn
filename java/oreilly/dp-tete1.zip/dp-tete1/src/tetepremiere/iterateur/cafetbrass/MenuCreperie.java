package tetepremiere.iterateur.cafetbrass;

import java.util.ArrayList;
import java.util.Iterator;

public class MenuCreperie implements Menu {
	ArrayList plats;

	public MenuCreperie() {
		plats = new ArrayList();

		ajouterPlat("Crèpe à l'oeuf", "Crèpe avec oeuf au plat ou brouillé",
				true, 2.99);

		ajouterPlat("Crèpe complète", "Crèpe avec oeuf au plat et jambon",
				false, 2.99);

		ajouterPlat("Crèpe forestière",
				"Myrtilles fraîches et sirop de myrtilles", true, 3.49);

		ajouterPlat("Crèpe du chef", "Crème fraîche et fruits rouges au choix",
				true, 3.59);
	}

	public void ajouterPlat(String nom, String description, boolean vegetarien,
			double prix) {
		Plat plat = new Plat(nom, description, vegetarien, prix);
		plats.add(plat);
	}

	public ArrayList getPlats() {
		return plats;
	}

	public Iterator creerIterateur() {
		return plats.iterator();
	}

	// autres methodes

}
