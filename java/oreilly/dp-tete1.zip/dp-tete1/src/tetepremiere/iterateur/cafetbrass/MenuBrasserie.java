package tetepremiere.iterateur.cafetbrass;

import java.util.*;

public class MenuBrasserie implements Menu {
	Hashtable plats = new Hashtable();
  
	public MenuBrasserie() {
		ajouterPlat("Omelette sarladaise",
			"Omelette aux champignons et pommes sautées",
			true, 3.99);
		ajouterPlat("Soupe de poissons",
			"Soupe de poissons, rouille et croûtons",
			false, 3.69);
		ajouterPlat("Tagliatelles Primavera",
			"Pâtes fraîches, brocoli, petits pois, crème fraîche",
			true, 4.29);
	}
 
	public void ajouterPlat(String nom, String description, 
	                     boolean vegetarien, double prix) 
	{
		Plat plat = new Plat(nom, description, vegetarien, prix);
		plats.put(plat.getNom(), plat);
	}
 
	public Hashtable getPlats() {
		return plats;
	}
  
	public Iterator creerIterateur() {
		return plats.values().iterator();
	}
}
