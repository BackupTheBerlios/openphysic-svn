package tetepremiere.iterateur.cafetbrass;

import java.util.Iterator;
  
public class Serveuse {
	Menu menuCreperie;
	Menu menuCafeteria;
	Menu menuBrasserie;
 
	public Serveuse(Menu menuCreperie, Menu menuCafeteria, Menu menuBrasserie) {
		this.menuCreperie = menuCreperie;
		this.menuCafeteria = menuCafeteria;
		this.menuBrasserie = menuBrasserie;
	}
 
	public void afficherMenu() {
		Iterator iterateurCrepe = menuCreperie.creerIterateur();
		Iterator iterateurCafet = menuCafeteria.creerIterateur();
		Iterator iterateurBrass = menuBrasserie.creerIterateur();

		System.out.println("MENU\n----\nBRUNCH");
		printMenu(iterateurCrepe);
		System.out.println("\nDEJEUNER");
		printMenu(iterateurCafet);
		System.out.println("\nDINER");
		printMenu(iterateurBrass);
	}
 
	private void printMenu(Iterator iterateur) {
		while (iterateur.hasNext()) {
			Plat plat = (Plat)iterateur.next();
			System.out.print(plat.getNom() + ", ");
			System.out.print(plat.getPrix() + " -- ");
			System.out.println(plat.getDescription());
		}
	}
 
	public void afficherMenuVegetarien() {
		System.out.println("\nMENU VEGETARIEN\n---------------");
		afficherMenuVegetarien(menuCreperie.creerIterateur());
		afficherMenuVegetarien(menuCafeteria.creerIterateur());
		afficherMenuVegetarien(menuBrasserie.creerIterateur());
	}
 
	public boolean estPlatVegetarien(String nom) {
		Iterator iterateurCrepe = menuCreperie.creerIterateur();
		if (estVegetarien(nom, iterateurCrepe)) {
			return true;
		}
		Iterator iterateurCafet = menuCafeteria.creerIterateur();
		if (estVegetarien(nom, iterateurCafet)) {
			return true;
		}
		Iterator iterateurBrass = menuBrasserie.creerIterateur();
		if (estVegetarien(nom, iterateurBrass)) {
			return true;
		}
		return false;
	}


	private void afficherMenuVegetarien(Iterator iterateur) {
		while (iterateur.hasNext()) {
			Plat plat = (Plat)iterateur.next();
			if (plat.estVegetarien()) {
				System.out.print(plat.getNom() + ", ");
				System.out.print(plat.getPrix() + " -- ");
				System.out.println(plat.getDescription());
			}
		}
	}

	private boolean estVegetarien(String nom, Iterator iterateur) {
		while (iterateur.hasNext()) {
			Plat plat = (Plat)iterateur.next();
			if (plat.getNom().equals(nom)) {
				if (plat.estVegetarien()) {
					return true;
				}
			}
		}
		return false;
	}
}
