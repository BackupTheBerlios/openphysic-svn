package tetepremiere.iterateur.cafetbrass;

public class TestMenu {
	public static void main(String args[]) {
		MenuCreperie menuCreperie = new MenuCreperie();
		MenuCafeteria menuCafeteria = new MenuCafeteria();
		MenuBrasserie menuBrasserie = new MenuBrasserie();
 
		Serveuse serveuse = new Serveuse(menuCreperie, menuCafeteria, menuBrasserie);
 
		serveuse.afficherMenu();
		serveuse.afficherMenuVegetarien();

		System.out.println("\nLe client demande : la Soupe du jour est-elle végétarienne ?");
		System.out.print("La serveuse répond : ");
		if (serveuse.estPlatVegetarien("Soupe du jour")) {
			System.out.println("Oui");
		} else {
			System.out.println("Non");
		}
		System.out.println("\nCLe client demande , l'Omelette sarladaise est-elle végétarienne ?");
		System.out.print("La serveuse répond : ");
		if (serveuse.estPlatVegetarien("Omelette sarladaise")) {
			System.out.println("Oui");
		} else {
			System.out.println("Non");
		}
	}
}
