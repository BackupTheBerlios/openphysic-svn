package tetepremiere.singleton.chocolat;
 
public class BouilleurChocolat {
	private boolean vide;
	private boolean bouilli;
	private static BouilleurChocolat uniqueInstance;
  
	private BouilleurChocolat() {
		vide = true;
		bouilli = false;
	}
  
	public static BouilleurChocolat getInstance() {
		if (uniqueInstance == null) {
			System.out.println("Création d'une instance unique du bouilleur de chocolat");
			uniqueInstance = new BouilleurChocolat();
		}
		System.out.println("Retourne l'instance du bouilleur de chocolat");
		return uniqueInstance;
	}

	public void remplir() {
		if (estVide()) {
			vide = false;
			bouilli = false;
			// remplir le bouilleur du mélange lait/chocolat
		}
	}
 
	public void vider() {
		if (!estVide() && estBouilli()) {
			// vider le chocolat et le lait bouillis
			vide = true;
		}
	}
 
	public void bouillir() {
		if (!estVide() && !estBouilli()) {
			// faire bouillir le contenu
			bouilli = true;
		}
	}
  
	public boolean estVide() {
		return vide;
	}
 
	public boolean estBouilli() {
		return bouilli;
	}
}
