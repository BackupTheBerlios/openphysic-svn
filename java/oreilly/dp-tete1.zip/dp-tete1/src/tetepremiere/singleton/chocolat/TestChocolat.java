package tetepremiere.singleton.chocolat;
 
public class TestChocolat {
	public static void main(String args[]) {
		BouilleurChocolat bouilleur = BouilleurChocolat.getInstance();
		bouilleur.remplir();
		bouilleur.bouillir();
		bouilleur.vider();

		// retourne une instance existante
		BouilleurChocolat bouilleur2 = BouilleurChocolat.getInstance();
	}
}
