package tetepremiere.singleton.sousclasse;

public class SingletonPlusChaud extends Singleton {
	// autres variables d'instance
 
	private SingletonPlusChaud() {
		super();
	}
 
	// autres méthodes
}
