package tetepremiere.singleton.sousclasse;

public class SingletonPlusFroid extends Singleton {
	// autres variables d'instance
	protected static Singleton uniqueInstance;
 
	private SingletonPlusFroid() {
		super();
	}
 
	// autres méthodes
}
