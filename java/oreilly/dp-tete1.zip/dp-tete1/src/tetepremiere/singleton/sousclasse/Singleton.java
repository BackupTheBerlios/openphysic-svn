package tetepremiere.singleton.sousclasse;

public class Singleton {
	protected static Singleton uniqueInstance;
 
	// autres variables d'instance
 
	protected Singleton() {}
 
	public static synchronized Singleton getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new Singleton();
		}
		return uniqueInstance;
	}
 
	// autres méthodes
}
