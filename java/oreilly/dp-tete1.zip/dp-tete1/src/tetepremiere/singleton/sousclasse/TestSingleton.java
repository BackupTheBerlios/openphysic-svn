package tetepremiere.singleton.sousclasse;

public class TestSingleton {
	public static void main(String[] args) {
		Singleton foo = SingletonPlusFroid.getInstance();
		Singleton bar = SingletonPlusChaud.getInstance();
		System.out.println(foo);
		System.out.println(bar);
 	}
}
