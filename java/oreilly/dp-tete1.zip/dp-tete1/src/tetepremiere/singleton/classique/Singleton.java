package tetepremiere.singleton.classique;

// NOTE: Non sûr vis-à-vis des threads !

public class Singleton {
	private static Singleton uniqueInstance;
 
	// autres variables d'instance
 
	private Singleton() {}
 
	public static Singleton getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new Singleton();
		}
		return uniqueInstance;
	}
 
	// autres méthodes
}
