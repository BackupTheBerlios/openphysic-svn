package tetepremiere.singleton.threadsafe;

public class Singleton {
	private static Singleton uniqueInstance;
 
	// autres variables d'instance
 
	private Singleton() {}
 
	public static synchronized Singleton getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new Singleton();
		}
		return uniqueInstance;
	}
 
	// autres méthodes
}
