package tetepremiere.etat.bonbonetat;

public interface Etat {
 
	public void insererPiece();
	public void ejecterPiece();
	public void tournerPoignee();
	public void delivrer();
}
