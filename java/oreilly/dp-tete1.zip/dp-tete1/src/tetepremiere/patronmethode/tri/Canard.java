package tetepremiere.patronmethode.tri;

public class Canard implements Comparable {
	String nom;
	int poids;
  
	public Canard(String nom, int poids) {
		this.nom = nom;
		this.poids = poids;
	}
 
	public String toString() {
		return nom + " pèse " + poids;
	}
 
 
  
	public int compareTo(Object object) {
 
		Canard autreCanard = (Canard)object;
  
		if (this.poids < autreCanard.poids) {
			return -1;
		} else if (this.poids == autreCanard.poids) {
			return 0;
		} else { // this.poids > autreCanard.poids
			return 1;
		}
	}
}
