package tetepremiere.patronmethode.cadre;

import java.awt.*;
import javax.swing.*;

public class MonCadre extends JFrame {

	public MonCadre(String titre) {
		super(titre);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.setSize(300,300);
		this.setVisible(true);
	}

	public void paint(Graphics graphics) {
		super.paint(graphics);
		String msg = "Je suis le maître du monde !!";
		graphics.drawString(msg, 100, 100);
	}

	public static void main(String[] args) {
		MonCadre monCadre = new MonCadre("Design Patterns Tête la Première");
	}
}
