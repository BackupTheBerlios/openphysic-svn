package tetepremiere.patronmethode.applet;

import java.applet.Applet;
import java.awt.Graphics;

public class MonApplet extends Applet {
    String message;
 
    public void init() {
        message = "Bonjour, me voilà!";
        repaint();
    }
 
    public void start() {
        message = "Je démarre...";
        repaint();
    }
 
    public void stop() {
        message = "Oh, on m'arrète...";
        repaint();
    }
 
    public void destroy() {
        message = "Je m'en vais...";
        repaint();
    }
 
    public void paint(Graphics g) {
        g.drawString(message, 5, 15);
    }
}

