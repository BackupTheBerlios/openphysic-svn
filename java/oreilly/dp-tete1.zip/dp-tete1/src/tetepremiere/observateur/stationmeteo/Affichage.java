package tetepremiere.observateur.stationmeteo;

public interface Affichage {
	public void afficher();
}
