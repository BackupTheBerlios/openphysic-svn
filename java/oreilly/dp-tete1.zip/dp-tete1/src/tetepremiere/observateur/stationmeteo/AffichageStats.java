package tetepremiere.observateur.stationmeteo;

public class AffichageStats implements Observateur, Affichage {
	private float tempMax = 0.0f;
	private float tempMin = 200;
	private float somTemp= 0.0f;
	private int nbLectures;
	private DonneesMeteo donneesMeteo;

	public AffichageStats(DonneesMeteo donneesMeteo) {
		this.donneesMeteo = donneesMeteo;
		donneesMeteo.enregistrerObservateur(this);
	}

	public void actualiser(float temp, float humidite, float pression) {
		somTemp += temp;
		nbLectures++;

		if (temp > tempMax) {
			tempMax = temp;
		}
 
		if (temp < tempMin) {
			tempMin = temp;
		}

		afficher();
	}

	public void afficher() {
		System.out.println("Température Moy/Max/Min = " + (somTemp / nbLectures)
			+ "/" + tempMax + "/" + tempMin);
	}
}
