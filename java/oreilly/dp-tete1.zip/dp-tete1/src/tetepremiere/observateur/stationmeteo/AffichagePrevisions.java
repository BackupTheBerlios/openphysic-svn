package tetepremiere.observateur.stationmeteo;

public class AffichagePrevisions implements Observateur, Affichage {
	private float pressionCourante = 1012;

	private float dernierePression;

	private DonneesMeteo donneesMeteo;

	public AffichagePrevisions(DonneesMeteo donneesMeteo) {
		this.donneesMeteo = donneesMeteo;
		donneesMeteo.enregistrerObservateur(this);
	}

	public void actualiser(float temp, float humidite, float pression) {
		dernierePression = pressionCourante;
		pressionCourante = pression;

		afficher();
	}

	public void afficher() {
		System.out.print("Prévision : ");
		if (pressionCourante > dernierePression) {
			System.out.println("Amélioration en cours !");
		} else if (pressionCourante == dernierePression) {
			System.out.println("Le temps se rafraîchit");
		} else if (pressionCourante < dernierePression) {
			System.out.println("Dépression bien installée");
		}
	}
}
