package tetepremiere.observateur.stationmeteo;

import java.util.*;

public class DonneesMeteo implements Sujet {
	private ArrayList observateurs;
	private float temperature;
	private float humidite;
	private float pression;
	
	public DonneesMeteo() {
		observateurs = new ArrayList();
	}
	
	public void enregistrerObservateur(Observateur o) {
		observateurs.add(o);
	}
	
	public void supprimerObservateur(Observateur o) {
		int i = observateurs.indexOf(o);
		if (i >= 0) {
			observateurs.remove(i);
		}
	}
	
	public void notifierObservateurs() {
		for (int i = 0; i < observateurs.size(); i++) {
			Observateur observer = (Observateur)observateurs.get(i);
			observer.actualiser(temperature, humidite, pression);
		}
	}
	
	public void actualiserMesures() {
		notifierObservateurs();
	}
	
	public void setMesures(float temperature, float humidite, float pression) {
		this.temperature = temperature;
		this.humidite = humidite;
		this.pression = pression;
		actualiserMesures();
	}
	
	// autres méthodes de DonneesMeteo 
	
	public float getTemperature() {
		return temperature;
	}
	
	public float getHumidite() {
		return humidite;
	}
	
	public float getPression() {
		return pression;
	}
}
