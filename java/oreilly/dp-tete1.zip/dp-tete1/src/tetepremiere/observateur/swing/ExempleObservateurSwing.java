package tetepremiere.observateur.swing;
	
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
	
public class ExempleObservateurSwing {
	JFrame frame;
	
	public static void main(String[] args) {
		ExempleObservateurSwing exemple = new ExempleObservateurSwing();
		exemple.go();
	}
	
	public void go() {
		frame = new JFrame();

		JButton bouton = new JButton("Dois-je le faire ?");
		bouton.addActionListener(new AuditeurAnge());
		bouton.addActionListener(new AuditeurDemon());
		frame.getContentPane().add(BorderLayout.CENTER, bouton);

		// D�finir les propri�t�s du cadre ici
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(BorderLayout.CENTER, bouton);
		frame.setSize(300,300);
		frame.setVisible(true);
	}
	
	class AuditeurAnge implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			System.out.println("Ne le fais pas, tu pourrais le regretter!");
		}
	}

	class AuditeurDemon implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			System.out.println("Allez, vas-y, fais-le !");
		}
	}
}
