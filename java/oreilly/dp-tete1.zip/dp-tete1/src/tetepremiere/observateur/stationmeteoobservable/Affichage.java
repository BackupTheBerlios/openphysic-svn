package tetepremiere.observateur.stationmeteoobservable;

public interface Affichage {
	public void afficher();
}
