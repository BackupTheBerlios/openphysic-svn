package tetepremiere.observateur.stationmeteoobservable;

import java.util.Observable;
import java.util.Observer;

public class AffichagePrevisions implements Observer, Affichage {
	private float pressionCourante = 1012;  
	private float dernierePression;

	public AffichagePrevisions(Observable observable) {
		observable.addObserver(this);
	}

	public void update(Observable observable, Object arg) {
		if (observable instanceof DonneesMeteo) {
			DonneesMeteo donneesMeteo = (DonneesMeteo)observable;
			dernierePression = pressionCourante;
			pressionCourante = donneesMeteo.getPression();
			afficher();
		}
	}

	public void afficher() {
		System.out.print("Prévision : ");
		if (pressionCourante > dernierePression) {
			System.out.println("Amélioration en cours !");
		} else if (pressionCourante == dernierePression) {
			System.out.println("Le temps se rafraîchit");
		} else if (pressionCourante < dernierePression) {
			System.out.println("Dépression bien installée");
		}
	}
}
