package tetepremiere.observateur.stationmeteoobservable;

import java.util.Observable;
import java.util.Observer;

public class AffichageStats implements Observer, Affichage {
	private float tempMax = 30.0f;
	private float minTemp = 0.0f;
	private float somTemp= 0.0f;
	private int nbLectures;

	public AffichageStats(Observable observable) {
		observable.addObserver(this);
	}

	public void update(Observable observable, Object arg) {
		if (observable instanceof DonneesMeteo) {
			DonneesMeteo weatherData = (DonneesMeteo)observable;
			float temp = weatherData.getTemperature();
			somTemp += temp;
			nbLectures++;

			if (temp > tempMax) {
				tempMax = temp;
			}
 
			if (temp < minTemp) {
				minTemp = temp;
			}

			afficher();
		}
	}

	public void afficher() {
		System.out.println("Température Moy/Max/Min = " + (somTemp / nbLectures)
			+ "/" + tempMax + "/" + minTemp);
	}
}
