package tetepremiere.strategie;

public class PropulsionAReaction implements ComportementVol {
	public void voler() {
		System.out.println("Je vole avec un réacteur !");
	}
}
