package tetepremiere.strategie;

public class CancanMuet implements ComportementCancan {
	public void cancaner() {
		System.out.println("<< Silence >>");
	}
}
