package tetepremiere.strategie;

public class FauxCancan implements ComportementCancan {
	public void cancaner() {
		System.out.println("CuicCuic");
	}
}
