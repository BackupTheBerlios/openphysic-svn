package tetepremiere.strategie;

public class NePasVoler implements ComportementVol {
	public void voler() {
		System.out.println("Je ne sais pas voler");
	}
}
