package tetepremiere.strategie;

public interface ComportementVol {
	public void voler();
}
