package tetepremiere.strategie;

public class Cancan implements ComportementCancan {
	public void cancaner() {
		System.out.println("Cancan");
	}
}
