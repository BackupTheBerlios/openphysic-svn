package tetepremiere.composite.iterateurmenu;

 
import java.util.*;
  
public class IterateurComposite implements Iterator {
	Stack pile = new Stack();
   
	public IterateurComposite(Iterator iterateur) {
		pile.push(iterateur);
	}
   
	public Object next() {
		if (hasNext()) {
			Iterator iterator = (Iterator) pile.peek();
			ComposantDeMenu composant = (ComposantDeMenu) iterator.next();
			if (composant instanceof Menu) {
				pile.push(composant.creerIterateur());
			} 
			return composant;
		} else {
			return null;
		}
	}
  
	public boolean hasNext() {
		if (pile.empty()) {
			return false;
		} else {
			Iterator iterateur = (Iterator) pile.peek();
			if (!iterateur.hasNext()) {
				pile.pop();
				return hasNext();
			} else {
				return true;
			}
		}
	}
   
	public void remove() {
		throw new UnsupportedOperationException();
	}
}


