package tetepremiere.composite.iterateurmenu;

import java.util.Iterator;
  
public class Serveuse {
	ComposantDeMenu tousMenus;
 
	public Serveuse(ComposantDeMenu tousMenus) {
		this.tousMenus = tousMenus;
	}
 
	public void afficherMenu() {
		tousMenus.afficher();
	}
  
	public void afficherMenuVegetarien() {
		Iterator iterateur = tousMenus.creerIterateur();

		System.out.println("\nMENU VEGETARIEN\n----");
		while (iterateur.hasNext()) {
			ComposantDeMenu composantDeMenu = 
					(ComposantDeMenu)iterateur.next();
			try {
				if (composantDeMenu.estVegetarien()) {
					composantDeMenu.afficher();
				}
			} catch (UnsupportedOperationException e) {}
		}
	}
}
