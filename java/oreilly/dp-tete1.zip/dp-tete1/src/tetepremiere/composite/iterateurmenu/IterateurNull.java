package tetepremiere.composite.iterateurmenu;
 
import java.util.Iterator;
  
public class IterateurNull implements Iterator {
   
	public Object next() {
		return null;
	}
  
	public boolean hasNext() {
		return false;
	}
   
	public void remove() {
		throw new UnsupportedOperationException();
	}
}
