package tetepremiere.composite.iterateurmenu;

import java.util.Iterator;
import java.util.ArrayList;

public class Menu extends ComposantDeMenu {
 
	ArrayList composantsMenu = new ArrayList();
	String nom;
	String description;
  
	public Menu(String nom, String description) {
		this.nom = nom;
		this.description = description;
	}
 
	public void ajouter(ComposantDeMenu composantDeMenu) {
		composantsMenu.add(composantDeMenu);
	}
 
	public void remove(ComposantDeMenu composantDeMenu) {
		composantsMenu.remove(composantDeMenu);
	}
 
	public ComposantDeMenu getEnfant(int i) {
		return (ComposantDeMenu)composantsMenu.get(i);
	}
 
	public String getNom() {
		return nom;
	}
 
	public String getDescription() {
		return description;
	}

  
	public Iterator creerIterateur() {
		return new IterateurComposite(composantsMenu.iterator());
	}
 
 
	public void afficher() {
		System.out.print("\n" + getNom());
		System.out.println(", " + getDescription());
		System.out.println("---------------------");
  
		Iterator iterator = composantsMenu.iterator();
		while (iterator.hasNext()) {
			ComposantDeMenu menuComponent = 
				(ComposantDeMenu)iterator.next();
			menuComponent.afficher();
		}
	}
}
