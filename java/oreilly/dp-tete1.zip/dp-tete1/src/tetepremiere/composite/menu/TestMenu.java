package tetepremiere.composite.menu;

public class TestMenu {
	public static void main(String args[]) {
		ComposantDeMenu menuCreperie = 
			new Menu("MENU CREPERIE", "Brunch");
		ComposantDeMenu menuCafeteria = 
			new Menu("MENU CAFETERIA", "Déjeuner");
		ComposantDeMenu menuBrasserie = 
			new Menu("MENU BRASSERIE", "Dîner");
		ComposantDeMenu menuDesserts = 
			new Menu("MENU DESSERT", "Rien que des desserts !");
  
		ComposantDeMenu tousMenus = new Menu("TOUS LES MENUS", "Toutes nos offres");
  
		tousMenus.ajouter(menuCreperie);
		tousMenus.ajouter(menuCafeteria);
		tousMenus.ajouter(menuBrasserie);
  
		menuCreperie.ajouter(new Plat(
			"Crèpe à l'oeuf", 
			"Crèpe avec oeuf au plat ou brouillé", 
			true,
			2.99));
		menuCreperie.ajouter(new Plat(
			"Crèpe complète", 
			"Crèpe avec oeuf au plat et jambon", 
			false,
			2.99));
		menuCreperie.ajouter(new Plat(
			"Crèpe forestière",
			"Myrtilles fraîches et sirop de myrtille",
			true,
			3.49));
		menuCreperie.ajouter(new Plat(
			"Crèpe du chef",
			"Crème fraîche et fruits rouges au choix",
			true,
			3.59));

		menuCafeteria.ajouter(new Plat(
			"Salade printanière",
			"Salade verte, tomates, concombre, olives, pommes de terre", 
			true, 
			2.99));
		menuCafeteria.ajouter(new Plat(
			"Salade Parisienne",
			"Salade verte, tomates, poulet, emmental", 
			false, 
			2.99));
		menuCafeteria.ajouter(new Plat(
			"Soupe du jour",
			"Soupe du jour et croûtons grillés", 
			true, 
			3.29));
		menuCafeteria.ajouter(new Plat(
			"Quiche aux fruits de mer",
			"Pâte brisée, crevettes, moules, champignons",
			false, 
			3.05));
		menuCafeteria.ajouter(new Plat(
			"Quiche aux épinards",
			"Pâte feuilletée, pommes de terre, épinards, crème fraîche", 
			true, 
			3.99));
 
		menuCafeteria.ajouter(new Plat(
			"Pasta al pesto",
			"Spaghetti, ail, basilic, parmesan",
			true, 
			3.89));
   
		menuCafeteria.ajouter(menuDesserts);
  
		menuDesserts.ajouter(new Plat(
			"Tarte du chef",
			"Tarte aux pommes et boule de glace à la vanille",
			true,
			1.59));
  
		menuDesserts.ajouter(new Plat(
			"Charlotte maison",
			"Charlotte aux poires et sauce au chocolat",
			true,
			1.99));
		menuDesserts.ajouter(new Plat(
			"Duos de sorbets",
			"Une boule fraise et une boule citron vert",
			true,
			1.89));

		menuBrasserie.ajouter(new Plat(
			"Omelette sarladaise",
			"Omelette aux champignons et pommes sautées",
			true, 
			3.99));
		menuBrasserie.ajouter(new Plat(
			"Soupe de poissons",
			"Soupe de poissons, rouille et croûtons",
			false, 
			3.69));
		menuBrasserie.ajouter(new Plat(
			"Tagliatelles Primavera",
			"Pâtes fraîches, brocoli, petits pois, crème fraîche",
			true, 
			4.29));
 
		Serveuse serveuse = new Serveuse(tousMenus);
   
		serveuse.afficherMenu();
	}
}
