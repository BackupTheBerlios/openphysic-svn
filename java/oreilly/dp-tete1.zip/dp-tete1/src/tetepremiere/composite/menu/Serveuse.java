package tetepremiere.composite.menu;

public class Serveuse {
	ComposantDeMenu tousMenus;
 
	public Serveuse(ComposantDeMenu tousMenus) {
		this.tousMenus = tousMenus;
	}
 
	public void afficherMenu() {
		tousMenus.afficher();
	}
}
