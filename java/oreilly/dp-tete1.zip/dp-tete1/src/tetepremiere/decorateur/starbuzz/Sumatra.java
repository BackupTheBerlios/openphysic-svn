package tetepremiere.decorateur.starbuzz;

public class Sumatra extends Boisson {
	public Sumatra() {
		description = "Sumatra corsé";
	}
 
	public double cout() {
		return .99;
	}
}

