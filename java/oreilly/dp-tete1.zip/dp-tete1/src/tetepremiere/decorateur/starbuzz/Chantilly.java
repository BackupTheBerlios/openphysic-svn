package tetepremiere.decorateur.starbuzz;
 
public class Chantilly extends DecorateurIngredient {
	Boisson boisson;
 
	public Chantilly(Boisson boisson) {
		this.boisson = boisson;
	}
 
	public String getDescription() {
		return boisson.getDescription() + ", Chantilly";
	}
 
	public double cout() {
		return .10 + boisson.cout();
	}
}
