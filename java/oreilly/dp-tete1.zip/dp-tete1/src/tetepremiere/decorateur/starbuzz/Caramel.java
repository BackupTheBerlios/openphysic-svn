package tetepremiere.decorateur.starbuzz;

public class Caramel extends DecorateurIngredient {
	Boisson boisson;

	public Caramel(Boisson boisson) {
		this.boisson = boisson;
	}

	public String getDescription() {
		return boisson.getDescription() + ", Caramel";
	}

	public double cout() {
		return .15 + boisson.cout();
	}
}
