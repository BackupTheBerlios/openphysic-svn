package tetepremiere.decorateur.starbuzz;

public abstract class DecorateurIngredient extends Boisson {
	public abstract String getDescription();
}
