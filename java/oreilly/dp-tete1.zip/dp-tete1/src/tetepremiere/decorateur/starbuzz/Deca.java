package tetepremiere.decorateur.starbuzz;

public class Deca extends Boisson {
	public Deca() {
		description = "Café déca";
	}
 
	public double cout() {
		return 1.05;
	}
}

