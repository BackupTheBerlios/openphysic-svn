package tetepremiere.decorateur.starbuzz;

public class Lait extends DecorateurIngredient {
	Boisson boisson;

	public Lait(Boisson boisson) {
		this.boisson = boisson;
	}

	public String getDescription() {
		return boisson.getDescription() + ", Lait";
	}

	public double cout() {
		return .10 + boisson.cout();
	}
}
