package tetepremiere.decorateur.starbuzz;

public class StarBuzz {
 
	public static void main(String args[]) {
		Boisson beverage = new Espresso();
		System.out.println(beverage.getDescription() 
				+ " €" + beverage.cout());
 
		Boisson boisson2 = new Sumatra();
		boisson2 = new Chocolat(boisson2);
		boisson2 = new Chocolat(boisson2);
		boisson2 = new Chantilly(boisson2);
		System.out.println(boisson2.getDescription() 
				+ " €" + boisson2.cout());
 
		Boisson boisson3 = new Colombia();
		boisson3 = new Caramel(boisson3);
		boisson3 = new Chocolat(boisson3);
		boisson3 = new Chantilly(boisson3);
		System.out.println(boisson3.getDescription() 
				+ " €" + boisson3.cout());
	}
}
