package tetepremiere.decorateur.starbuzz;

public class Colombia extends Boisson {
	public Colombia() {
		description = "Pur Colombia";
	}
 
	public double cout() {
		return .89;
	}
}

