package tetepremiere.decorateur.starbuzz;

public class Chocolat extends DecorateurIngredient {
	Boisson boisson;
 
	public Chocolat(Boisson boisson) {
		this.boisson = boisson;
	}
 
	public String getDescription() {
		return boisson.getDescription() + ", Chocolat";
	}
 
	public double cout() {
		return .20 + boisson.cout();
	}
}
