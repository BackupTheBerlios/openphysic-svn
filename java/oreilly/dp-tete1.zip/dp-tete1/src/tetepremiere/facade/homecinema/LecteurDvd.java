package tetepremiere.facade.homecinema;

public class LecteurDvd {
	String description;

	int chapitreCourant;

	Amplificateur amplificateur;

	String film;

	public LecteurDvd(String description, Amplificateur amplifier) {
		this.description = description;
		this.amplificateur = amplifier;
	}

	public void marche() {
		System.out.println(description + " en marche");
	}

	public void arret() {
		System.out.println(description + " arrêté");
	}

	public void ejecter() {
		film = null;
		System.out.println(description + " éjection");
	}

	public void jouer(String film) {
		this.film = film;
		chapitreCourant = 0;
		System.out.println(description + " joue \"" + film + "\"");
	}

	public void jouer(int chapitre) {
		if (film == null) {
			System.out.println(description + " ne peut jouer le chapitre " + chapitre
					+ " aucun dvd n'est présent");
		} else {
			chapitreCourant = chapitre;
			System.out.println(description + " joue le chapitre " + chapitreCourant
					+ " de \"" + film + "\"");
		}
	}

	public void stop() {
		chapitreCourant = 0;
		System.out.println(description + " arrêté sur \"" + film + "\"");
	}

	public void pause() {
		System.out.println(description + " en pause sur \"" + film + "\"");
	}

	public void SetAudioStereo() {
		System.out.println(description + " réglé sur son stéréo");
	}

	public void setAudioSurround() {
		System.out.println(description + " réglé sur son surround");
	}

	public String toString() {
		return description;
	}
}
