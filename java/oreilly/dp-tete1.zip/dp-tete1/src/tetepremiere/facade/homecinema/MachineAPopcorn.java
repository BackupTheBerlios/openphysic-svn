package tetepremiere.facade.homecinema;

public class MachineAPopcorn {
	String description;

	public MachineAPopcorn(String description) {
		this.description = description;
	}

	public void marche() {
		System.out.println(description + " en marche");
	}

	public void arret() {
		System.out.println(description + " arrêtée");
	}

	public void eclater() {
		System.out.println(description + " fait éclater le pop-corn !");
	}

	public String toString() {
		return description;
	}
}
