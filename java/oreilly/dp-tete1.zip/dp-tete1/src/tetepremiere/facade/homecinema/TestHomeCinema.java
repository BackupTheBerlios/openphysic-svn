package tetepremiere.facade.homecinema;

public class TestHomeCinema {
	public static void main(String[] args) {
		Amplificateur amp = new Amplificateur("Magnifique Amplificateur");
		Tuner tuner = new Tuner("Super Tuner AM/FM", amp);
		LecteurDvd dvd = new LecteurDvd("Super Lecteur DVD", amp);
		LecteurCd cd = new LecteurCd("Lecteur CD grandiose", amp);
		Projecteur projecteur = new Projecteur("Projecteur", dvd);
		Lumieres lumieres = new Lumieres("Lumières du Home Cinéma");
		Ecran ecran = new Ecran("Ecran du Home Cinéma");
		MachineAPopcorn machineAPopCorn = new MachineAPopcorn("Machine à pop-corn");
 
		FacadeHomeCinema homeCinema = 
				new FacadeHomeCinema(amp, tuner, dvd, cd, 
						projecteur, ecran, lumieres, machineAPopCorn);
 
		homeCinema.regarderFilm("Hôtel du Nord");
		homeCinema.arreterFilm();
	}
}
