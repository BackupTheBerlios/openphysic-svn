package tetepremiere.facade.homecinema;

public class Amplificateur {
	String description;
	Tuner tuner;
	LecteurDvd dvd;
	LecteurCd cd;
	
	public Amplificateur(String description) {
		this.description = description;
	}
 
	public void marche() {
		System.out.println(description + " en marche");
	}
 
	public void arret() {
		System.out.println(description + " éteint");
	}
 
	public void setSonStereo() {
		System.out.println(description + " réglé sur son stéréo");
	}
 
	public void setSonSurround() {
		System.out.println(description + " réglé sur son surround (5 enceintes, 1 caisson de basses)");
	}
 
	public void setVolume(int volume) {
		System.out.println(description + " volume réglé sur " + volume);
	}

	public void setTuner(Tuner tuner) {
		System.out.println(description + " positionné sur le tuner sur " + dvd);
		this.tuner = tuner;
	}
  
	public void setDvd(LecteurDvd dvd) {
		System.out.println(description + " positionné sur le lecteur DVD " + dvd);
		this.dvd = dvd;
	}
 
	public void setCd(LecteurCd cd) {
		System.out.println(description + " positionné sur le lecteur CD " + cd);
		this.cd = cd;
	}
 
	public String toString() {
		return description;
	}
}
