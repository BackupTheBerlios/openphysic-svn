package tetepremiere.facade.homecinema;

public class LecteurCd {
	String description;
	int morceauCourant;
	Amplificateur amplificateur;
	String titre;
	
	public LecteurCd(String description, Amplificateur amplificateur) {
		this.description = description;
		this.amplificateur = amplificateur;
	}
 
	public void marche() {
		System.out.println(description + " en marche");
	}
 
	public void arret() {
		System.out.println(description + " arrêté");
	}

	public void ejecter() {
		titre = null;
		System.out.println(description + " éjection");
	}
 
	public void jouer(String titre) {
		this.titre = titre;
		morceauCourant = 0;
		System.out.println(description + " joue \"" + titre + "\"");
	}

	public void jouer(int track) {
		if (titre == null) {
			System.out.println(description + " ne peut joue le morceau " + morceauCourant + 
					", auncun cd inséré");
		} else {
			morceauCourant = track;
			System.out.println(description + " joue le morceau " + morceauCourant);
		}
	}

	public void stop() {
		morceauCourant = 0;
		System.out.println(description + " arrêté");
	}
 
	public void pause() {
		System.out.println(description + " en pause sur \"" + titre + "\"");
	}
 
	public String toString() {
		return description;
	}
}
