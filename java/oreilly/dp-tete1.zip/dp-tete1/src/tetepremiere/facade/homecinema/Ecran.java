package tetepremiere.facade.homecinema;

public class Ecran {
	String description;

	public Ecran(String description) {
		this.description = description;
	}

	public void monter() {
		System.out.println(description + " remonté");
	}

	public void baisser() {
		System.out.println(description + " descendu");
	}

	public String toString() {
		return description;
	}
}
