package tetepremiere.facade.homecinema;

public class Lumieres {
	String description;

	public Lumieres(String description) {
		this.description = description;
	}

	public void marche() {
		System.out.println(description + " allumées");
	}

	public void arret() {
		System.out.println(description + " arrêtées");
	}

	public void attenuer(int niveau) {
		System.out.println(description + " atténuées à " + niveau + "%");
	}

	public String toString() {
		return description;
	}
}
