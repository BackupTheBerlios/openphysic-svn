package tetepremiere.facade.homecinema;

public class Tuner {
	String description;

	Amplificateur amplificateur;

	double frequence;

	public Tuner(String description, Amplificateur amplificateur) {
		this.description = description;
	}

	public void marche() {
		System.out.println(description + " en marche");
	}

	public void arret() {
		System.out.println(description + " arrêté");
	}

	public void setFrequence(double frequence) {
		System.out.println(description + " positionné de la fréquence sur " + frequence);
		this.frequence = frequence;
	}

	public void setAm() {
		System.out.println(description + " positionné sur la bande AM");
	}

	public void setFm() {
		System.out.println(description + " positionné sur la bande FM");
	}

	public String toString() {
		return description;
	}
}
