package tetepremiere.facade.homecinema;

public class Projecteur {
	String description;
	LecteurDvd lecteurDVD;
	
	public Projecteur(String description, LecteurDvd lecteurDVD) {
		this.description = description;
		this.lecteurDVD = lecteurDVD;
	}
 
	public void marche() {
		System.out.println(description + " en marche");
	}
 
	public void arret() {
		System.out.println(description + " arrêté");
	}

	public void modeGrandEcran() {
		System.out.println(description + " en mode grand écran (aspect 16x9)");
	}

	public void modeTV() {
		System.out.println(description + " en mode grand TV (aspect 4x3)");
	}
  
        public String toString() {
                return description;
        }
}
