package tetepremiere.proxy.distributeurrmi;

import java.rmi.*;
 
public class ControleurDistrib {
	DistributeurDistant machine;
 
	public ControleurDistrib(DistributeurDistant machine) {
		this.machine = machine;
	}
 
	public void rapport() {
		try {
			System.out.println("Distributeur : " + machine.getEmplacement());
			System.out.println("Stock Courant : " + machine.getNombre() + " bonbons");
			System.out.println("Etat courant : " + machine.getEtat());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
}
