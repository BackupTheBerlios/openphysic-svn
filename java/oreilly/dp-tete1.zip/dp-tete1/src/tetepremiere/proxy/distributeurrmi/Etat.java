package tetepremiere.proxy.distributeurrmi;

import java.io.*;
  
public interface Etat extends Serializable {
	public void insererPiece();
	public void ejecterPiece();
	public void tournerPoignee();
	public void delivrer();
}
