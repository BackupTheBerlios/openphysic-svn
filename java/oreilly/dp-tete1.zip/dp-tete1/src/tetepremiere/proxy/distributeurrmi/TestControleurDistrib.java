package tetepremiere.proxy.distributeurrmi;

import java.rmi.*;
 
public class TestControleurDistrib {
 
	public static void main(String[] args) {
		String[] emplacement = {"rmi://rennes.distribon.com/distributeur",
		                     "rmi://lille.distribon.com/distributeur",
		                     "rmi://marseille.distribon.com/distributeur"}; 
 
		ControleurDistrib[] controleur = new ControleurDistrib[emplacement.length];
 
		for (int i=0;i < emplacement.length; i++) {
			try {
           		DistributeurDistant machine = 
						(DistributeurDistant) Naming.lookup(emplacement[i]);
           		controleur[i] = new ControleurDistrib(machine);
				System.out.println(controleur[i]);
        	} catch (Exception e) {
            	e.printStackTrace();
        	}
		}
 
		for(int i=0; i < controleur.length; i++) {
			controleur[i].rapport();
		}
	}
}
