package tetepremiere.proxy.distributeurrmi;

import java.rmi.*;
import java.rmi.server.*;
 
public class Distributeur
		extends UnicastRemoteObject implements DistributeurDistant 
{
	Etat etatEpuise;
	Etat etatSansPiece;
	Etat etatAPiece;
	Etat etatVendu;
	Etat etatGagnant;
 
	Etat etat = etatEpuise;
	int nombre = 0;
 	String emplacement;

	public Distributeur(String emplacement, int nombre) throws RemoteException {
		etatEpuise = new EtatEpuise(this);
		etatSansPiece = new EtatSansPiece(this);
		etatAPiece = new EtatAPiece(this);
		etatVendu = new EtatVendu(this);
		etatGagnant = new EtatGagnant(this);

		this.nombre = nombre;
 		if (nombre > 0) {
			etat = etatSansPiece;
		} 
		this.emplacement = emplacement;
	}
 
 
	public void insererPiece() {
		etat.insererPiece();
	}
 
	public void ejecterPiece() {
		etat.ejecterPiece();
	}
 
	public void tournerPoignee() {
		etat.tournerPoignee();
		etat.delivrer();
	}

	void setEtat(Etat etat) {
		this.etat = etat;
	}
 
	void liberer() {
		System.out.println("Un bonbon va sortir...");
		if (nombre != 0) {
			nombre = nombre - 1;
		}
	}

	public void remplir(int nombre) {
		this.nombre = nombre;
		etat = etatSansPiece;
	}
 
	public int getNombre() {
		return nombre;
	}
 
    public Etat getEtat() {
        return etat;
    }
 
    public String getEmplacement() {
        return emplacement;
    }
  
    public Etat getEtatEpuise() {
        return etatEpuise;
    }

    public Etat getEtatSansPiece() {
        return etatSansPiece;
    }

    public Etat getEtatAPiece() {
        return etatAPiece;
    }

    public Etat getEtatVendu() {
        return etatVendu;
    }

    public Etat getEtatGagnant() {
        return etatGagnant;
    }
 
	public String toString() {
		StringBuffer result = new StringBuffer();
		result.append("\nDistribon, SARL.");
		result.append("\nDistributeur compatible Java, modèle 2004");
		result.append("\nStock : " + nombre + " bonbon");
		if (nombre != 1) {
			result.append("s");
		}
		result.append("\n");
		result.append("L'appareil " + etat + "\n");
		return result.toString();
	}
}
