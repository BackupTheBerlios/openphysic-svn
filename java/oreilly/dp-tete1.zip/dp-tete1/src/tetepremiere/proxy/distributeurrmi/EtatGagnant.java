package tetepremiere.proxy.distributeurrmi;

public class EtatGagnant implements Etat {
    transient Distributeur distributeur;
 
    public EtatGagnant(Distributeur distributeur) {
        this.distributeur = distributeur;
    }
 
	public void insererPiece() {
		System.out.println("Patientez s'il vous plait, un bonbon est en train d'être délivré");
	}
 
	public void ejecterPiece() {
		System.out.println("Patientez s'il vous plait, un bonbon est en train d'être délivré");
	}
 
	public void tournerPoignee() {
		System.out.println("Tourner une nouvelle fois la poignée ne vous donnera pas un autre bonbon pour autant!");
	}
 
	public void delivrer() {
		System.out.println("VOUS AVEZ GAGNE ! Deux bonbons pour le prix d'un !");
		distributeur.liberer();
		if (distributeur.getNombre() == 0) {
			distributeur.setEtat(distributeur.getEtatEpuise());
		} else {
			distributeur.liberer();
			if (distributeur.getNombre() > 0) {
				distributeur.setEtat(distributeur.getEtatSansPiece());
			} else {
          		 	System.out.println("Aïe, plus de bonbons !");
				distributeur.setEtat(distributeur.getEtatEpuise());
			}
		}
	}
 
	public String toString() {
		return "délivre deux bonbons pour le prix d'un, car vous avez gagné !";
	}
}
