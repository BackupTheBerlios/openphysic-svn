package tetepremiere.proxy.distributeurrmi;

import java.rmi.*;
 
public interface DistributeurDistant extends Remote {
	public int getNombre() throws RemoteException;
	public String getEmplacement() throws RemoteException;
	public Etat getEtat() throws RemoteException;
}
