package tetepremiere.proxy.distributeurrmi;
import java.rmi.*;

public class TestDistributeur {
 
	public static void main(String[] args) {
		DistributeurDistant distributeur = null;
		int nombre;

		if (args.length < 2) {
			System.out.println("TestDistributeur <nom> <stock>");
 			System.exit(1);
		}

		try {
			nombre = Integer.parseInt(args[1]);

			distributeur = 
				new Distributeur(args[0], nombre);
			Naming.rebind("//" + args[0] + "/distributeur", distributeur);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
