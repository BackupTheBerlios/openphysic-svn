package tetepremiere.proxy.distributeurrmi;

import java.util.Random;

public class EtatAPiece implements Etat {
	Random hasard = new Random(System.currentTimeMillis());
	transient Distributeur distributeur;
 
	public EtatAPiece(Distributeur distributeur) {
		this.distributeur = distributeur;
	}
  
	public void insererPiece() {
		System.out.println("Vous ne pouvez pas insérer d'autre pièce");
	}
 
	public void ejecterPiece() {
		System.out.println("Pièce retournée");
		distributeur.setEtat(distributeur.getEtatSansPiece());
	}
 
	public void tournerPoignee() {
		System.out.println("Vous avez tourné...");
		int gagnant = hasard.nextInt(10);
		if (gagnant == 0) {
			distributeur.setEtat(distributeur.getEtatGagnant());
		} else {
			distributeur.setEtat(distributeur.getEtatVendu());
		}
	}

    public void delivrer() {
        System.out.println("Pas de bonbon délivré");
    }
 
	public String toString() {
		return "attend que la poignée soit tournée";
	}
}
