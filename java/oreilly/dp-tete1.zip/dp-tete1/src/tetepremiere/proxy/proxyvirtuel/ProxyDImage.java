package tetepremiere.proxy.proxyvirtuel;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ProxyDImage implements Icon {
 ImageIcon image;
 URL urlImage;
 Thread threadChargement;
 boolean chargement = false;

 public ProxyDImage(URL url) { urlImage = url; }

 public int getIconWidth() {
   if (image != null) {
       return image.getIconWidth();
   } else {
       return 800;
   }
 }

 public int getIconHeight() {
   if (image != null) {
       return image.getIconHeight();
   } else {
       return 600;
   }
 }

 public void paintIcon(final Component c, Graphics g, int x, int y) {
   if (image != null) {
       image.paintIcon(c, g, x, y);
   } else {
       g.drawString("Chargement en cours. Patientez...", x+300, y+190);
   if (!chargement) {
       chargement = true;

       threadChargement = new Thread(new Runnable() {
         public void run() {
           try {
               image = new ImageIcon(urlImage, "Pochette de CD");
               c.repaint();
           } catch (Exception e) {
               e.printStackTrace();
           }
         }
      });
      threadChargement.start();
     }
   }
 }
}
