package tetepremiere.proxy.proxyvirtuel;
import java.net.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class TestProxyDImage {
 ComposantDImage composant;
 JFrame cadre = new JFrame("Pochettes de CD");
 JMenuBar barreDeMenus;
 JMenu menu;
 Hashtable cd = new Hashtable();

 public static void main (String[] args) throws Exception {
   TestProxyDImage test = new TestProxyDImage();
 }

 public TestProxyDImage() throws Exception{
   cd.put("La marche de l'empereur"," http://images-eu.amazon.com/images/P/B00070FX3M.08.LZZZZZZZ.jpg");
   cd.put("Ferré : L'espoir"," http://images-eu.amazon.com/images/P/B00008ZPD3.08.LZZZZZZZ.jpg ");
   cd.put("Excalibur","http://images-eu.amazon.com/images/P/B00004VRKV.08.LZZZZZZZ.jpg");
   cd.put("Carlos Nunez","http://images-eu.amazon.com/images/P/B000063WSL.08.LZZZZZZZ.jpg");
   cd.put("Variations Goldberg","http://images-eu.amazon.com/images/P/B000025NYA.08.LZZZZZZZ.jpg");
   cd.put("Aubry : Signes"," http://images-eu.amazon.com/images/P/B0000085FR.08.LZZZZZZZ.jpg ");
   cd.put("Rokia Traoré","http://images-eu.amazon.com/images/P/B0002M5T9I.01.LZZZZZZZ.jpg");

   URL urlInitiale = new URL((String)cd.get("La marche de l'empereur"));
   barreDeMenus = new JMenuBar();
   menu = new JMenu("CD favoris");
   barreDeMenus.add(menu);
   cadre.setJMenuBar(barreDeMenus);
   for(Enumeration e = cd.keys(); e.hasMoreElements();) {
     String nom = (String)e.nextElement();
     JMenuItem menuItem = new JMenuItem(nom);
     menu.add(menuItem);
     menuItem.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent event) {
         composant.setIcon(new ProxyDImage(getUrlCD(event.getActionCommand())));
         cadre.repaint();
       }
     });
   }

   // installer le cadre et les menus

   Icon icone = new ProxyDImage(urlInitiale);
   composant = new ComposantDImage(icone);
   cadre.getContentPane().add(composant);
   cadre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   cadre.setSize(800,600);
   cadre.setVisible(true);

 }
 URL getUrlCD(String nom) {
     try {
         return new URL((String)cd.get(nom));
     } catch (MalformedURLException e) {
         e.printStackTrace();
         return null;
     }
 }
}
