
package tetepremiere.proxy.proxyvirtuel;

import java.awt.*;
import javax.swing.*;

class ComposantDImage extends JComponent {
	private Icon icone;

	public ComposantDImage(Icon icone) {
		this.icone = icone;
	}

	public void setIcon(Icon icone) {
		this.icone = icone;
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		int w = icone.getIconWidth();
		int h = icone.getIconHeight();
		int x = (800 - w)/2;
		int y = (600 - h)/2;
		icone.paintIcon(this, g, x, y);
	}
}
