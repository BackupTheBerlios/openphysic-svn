package tetepremiere.proxy.distributeur;

public class TestDistributeur {

	public static void main(String[] args) {
		int nombre = 0;

        if (args.length < 2) {
            System.out.println("TestDistributeur <nom> <stock>");
            System.exit(1);
        }

        try {
        	nombre = Integer.parseInt(args[1]);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		Distributeur distributeur = new Distributeur(args[0], nombre);

		ControleurDistrib controleur = new ControleurDistrib(distributeur);

 
		System.out.println(distributeur);

		distributeur.insererPiece();
		distributeur.tournerPoignee();
		distributeur.insererPiece();
		distributeur.tournerPoignee();

		System.out.println(distributeur);

		distributeur.insererPiece();
		distributeur.tournerPoignee();
		distributeur.insererPiece();
		distributeur.tournerPoignee();

		System.out.println(distributeur);

		distributeur.insererPiece();
		distributeur.tournerPoignee();
		distributeur.insererPiece();
		distributeur.tournerPoignee();

		System.out.println(distributeur);

		distributeur.insererPiece();
		distributeur.tournerPoignee();
		distributeur.insererPiece();
		distributeur.tournerPoignee();

		System.out.println(distributeur);

		distributeur.insererPiece();
		distributeur.tournerPoignee();
		distributeur.insererPiece();
		distributeur.tournerPoignee();

		System.out.println(distributeur);

		controleur.rapport();
	}
}
