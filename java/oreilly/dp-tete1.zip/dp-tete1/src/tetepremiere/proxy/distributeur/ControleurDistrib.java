package tetepremiere.proxy.distributeur;
 
public class ControleurDistrib {
	Distributeur machine;
 
	public ControleurDistrib(Distributeur machine) {
		this.machine = machine;
	}
 
	public void rapport() {
		System.out.println("Distributeur : " + machine.getEmplacement());
		System.out.println("Stock Courant : " + machine.getNombre() + " bonbons");
		System.out.println("Etat courant : " + machine.getEtat());
	}
}
