package tetepremiere.proxy.proxyjava;
 
import java.lang.reflect.*;
 
public class InvocationHandlerNonProprietaire implements InvocationHandler { 
	BeanPersonne personne;
 
	public InvocationHandlerNonProprietaire(BeanPersonne personne) {
		this.personne = personne;
	}
 
	public Object invoke(Object proxy, Method method, Object[] args) 
			throws IllegalAccessException {
  
		try {
			if (method.getName().startsWith("get")) {
				return method.invoke(personne, args);
   			} else if (method.getName().equals("setSexyOuNon")) {
				return method.invoke(personne, args);
			} else if (method.getName().startsWith("set")) {
				throw new IllegalAccessException();
			} 
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } 
		return null;
	}
}
