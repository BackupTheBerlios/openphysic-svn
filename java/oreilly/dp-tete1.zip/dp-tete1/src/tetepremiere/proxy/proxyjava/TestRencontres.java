package tetepremiere.proxy.proxyjava;

import java.lang.reflect.*;
import java.util.*;

public class TestRencontres {
	Hashtable basedonnees = new Hashtable();
 	
	public static void main(String[] args) {
		TestRencontres test = new TestRencontres();
		test.tester();
	}
 
	public TestRencontres() {
		initialiserBD();
	}

	public void tester() {
		BeanPersonne luc = getPersonneDepuisBD("Luc Javabine"); 
		BeanPersonne proxyProprietaire = getProxyProprietaire(luc);
		System.out.println("Nom = " + proxyProprietaire.getNom());
		proxyProprietaire.setInterets("tennis, jeu de go");
		System.out.println("Intérêts fixés par le proxy propriétaire");
		try {
			proxyProprietaire.setSexyOuNon(10);
		} catch (Exception e) {
			System.out.println("Le proxy propriétaire ne peut pas modifier la note");
		}
		System.out.println("Note = " + proxyProprietaire.getSexyOuNon());

		BeanPersonne proxyNonProprietaire = getProxyNonProprietaire(luc);
		System.out.println("Nom = " + proxyNonProprietaire.getNom());
		try {
			proxyNonProprietaire.setInterets("tennis, jeu de go");
		} catch (Exception e) {
			System.out.println("Le proxy non propriétaire ne peut pas modifier les intérêts");
		}
		proxyNonProprietaire.setSexyOuNon(3);
		System.out.println("Note modifiée par le proxy non propriétaire");
		System.out.println("Note = " + proxyNonProprietaire.getSexyOuNon());
	}

	BeanPersonne getProxyProprietaire(BeanPersonne personne) {
 		
        return (BeanPersonne) Proxy.newProxyInstance( 
            	personne.getClass().getClassLoader(),
            	personne.getClass().getInterfaces(),
                new InvocationHandlerProprietaire(personne));
	}

	BeanPersonne getProxyNonProprietaire(BeanPersonne personne) {
		
        return (BeanPersonne) Proxy.newProxyInstance(
            	personne.getClass().getClassLoader(),
            	personne.getClass().getInterfaces(),
                new InvocationHandlerNonProprietaire(personne));
	}

	BeanPersonne getPersonneDepuisBD(String nom) {
		return (BeanPersonne)basedonnees.get(nom);
	}

	void initialiserBD() {
		BeanPersonne luc = new BeanPersonneImpl();
		luc.setNom("Luc Javabine");
		luc.setInterets("voitures, informatique, musique");
		luc.setSexyOuNon(7);
		basedonnees.put(luc.getNom(), luc);

		BeanPersonne paula = new BeanPersonneImpl();
		paula.setNom("Paula Klosure");
		paula.setInterets("internet, film, musique");
		paula.setSexyOuNon(6);
		basedonnees.put(paula.getNom(), paula);
	}
}
