package tetepremiere.proxy.proxyjava;
 
import java.lang.reflect.*;
 
public class InvocationHandlerProprietaire implements InvocationHandler { 
	BeanPersonne personne;
 
	public InvocationHandlerProprietaire(BeanPersonne personne) {
		this.personne = personne;
	}
 
	public Object invoke(Object proxy, Method method, Object[] args) 
			throws IllegalAccessException {
  
		try {
			if (method.getName().startsWith("get")) {
				return method.invoke(personne, args);
   			} else if (method.getName().equals("setSexyOuNon")) {
				throw new IllegalAccessException();
			} else if (method.getName().startsWith("set")) {
				return method.invoke(personne, args);
			} 
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } 
		return null;
	}
}
