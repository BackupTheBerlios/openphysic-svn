package tetepremiere.proxy.proxyjava;

public interface BeanPersonne {
 
	String getNom();
	String getSexe();
	String getInterets();
	int getSexyOuNon();
 
    void setNom(String nom);
    void setSexe(String sexe);
    void setInterets(String interets);
    void setSexyOuNon(int note); 
 
}
