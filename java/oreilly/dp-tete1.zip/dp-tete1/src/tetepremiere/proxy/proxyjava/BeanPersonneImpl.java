package tetepremiere.proxy.proxyjava;

public class BeanPersonneImpl implements BeanPersonne {
	String nom;
	String sexe;
	String interets;
	int note;
	int nombreDeNotes = 0;
  
	public String getNom() {
		return nom;	
	} 
  
	public String getSexe() {
		return sexe;
	}
  
	public String getInterets() {
		return interets;
	}
   
	public int getSexyOuNon() {
		if (nombreDeNotes == 0) return 0;
		return (note/nombreDeNotes);
	}
  
 
	public void setNom(String nom) {
		this.nom = nom;
	}
 
	public void setSexe(String sexe) {
		this.sexe = sexe;
	} 
  
	public void setInterets(String interets) {
		this.interets = interets;
	} 
  
	public void setSexyOuNon(int note) {
		this.note += note;	
		nombreDeNotes++;
	}
}
