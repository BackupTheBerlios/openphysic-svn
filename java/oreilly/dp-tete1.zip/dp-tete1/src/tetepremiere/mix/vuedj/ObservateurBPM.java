package tetepremiere.mix.vuedj;

public interface ObservateurBPM {
  void majBPM();
}


