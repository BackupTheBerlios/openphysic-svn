package tetepremiere.mix.vuedj;

public class ControleurTempo implements InterfaceControleur {
  InterfaceModeleTempo modele;
  VueDJ vue;

  public ControleurTempo(InterfaceModeleTempo modele) {
    this.modele = modele;
    vue = new VueDJ(this, modele);
    vue.creerVue();
    vue.creerCommandes();
    vue.desactiverChoixStop();
    vue.activerChoixStart();
    modele.initialiser();
  }

  public void start() {
    modele.marche();
    vue.desactiverChoixStop();
    vue.activerChoixStart();
  }

  public void stop() {
    modele.arret();
    vue.desactiverChoixStop();
    vue.activerChoixStart();
  }

  public void augmenterBPM() {
    int bpm = modele.getBPM();
    modele.setBPM(bpm + 1);
  }

  public void diminuerBPM() {
   int bpm = modele.getBPM();
   modele.setBPM(bpm - 1);
  }

  public void setBPM(int bpm) {
  modele.setBPM(bpm);
  }
}

