package tetepremiere.mix.vuedj;

public class ControleurCoeur implements InterfaceControleur {
  InterfaceModeleCoeur modele;
  VueDJ vue;

  public ControleurCoeur(InterfaceModeleCoeur modele) {
    this.modele = modele;
    vue = new VueDJ(this, new AdaptateurCoeur(modele));
    vue.creerVue();
    vue.creerCommandes();
    vue.desactiverChoixStop();
    vue.desactiverChoixStart();
  }

  public void start() {}

  public void stop() {}

  public void augmenterBPM() {}

  public void diminuerBPM() {}

  public void setBPM(int bpm) {}
}

