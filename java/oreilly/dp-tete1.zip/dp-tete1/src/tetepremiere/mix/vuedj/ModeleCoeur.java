package tetepremiere.mix.vuedj;
import java.util.*;

public class ModeleCoeur implements InterfaceModeleCoeur, Runnable {
  ArrayList observateursBattements = new ArrayList();
  ArrayList observateursBPM = new ArrayList();
  int temps = 1000;
  int bpm = 90;
  Random random = new Random(System.currentTimeMillis());
  Thread thread;

  public ModeleCoeur() {
    thread = new Thread(this);
    thread.start();
  }

  public void run() {
  int dernierRythme = -1;

  for(;;) {
      int change = random.nextInt(10);
      if (random.nextInt(2) == 0) {
          change = 0 - change;
}
      int rythme = 60000/(temps + change);
      if (rythme < 120 && rythme > 50) {
          temps += change;
          notifierObservateursBattements();
          if (rythme != dernierRythme) {
              dernierRythme = rythme;
              notifierObservateursBPM();
          }
      }
      try {
          Thread.sleep(temps);
      } catch (Exception e) {}
    }
  }

  public int getRythmeCardiaque() {
    return 60000/temps;
  }

  public void registerObserver(ObservateurBattements o) {
    observateursBattements.add(o);
  }

  public void removeObserver(ObservateurBattements o) {
    int i = observateursBattements.indexOf(o);
    if (i >= 0) {
        observateursBattements.remove(i);
    }
  }

  public void notifierObservateursBattements() {
    for(int i = 0; i < observateursBattements.size(); i++) {
        ObservateurBattements observateur = (ObservateurBattements)observateursBattements.get(i);
        observateur.majTempo();
    }
  }

  public void registerObserver(ObservateurBPM o) {
    observateursBPM.add(o);
  }

  public void removeObserver(ObservateurBPM o) {
    int i = observateursBPM.indexOf(o);
    if (i >= 0) {
        observateursBPM.remove(i);
    }
  }

  public void notifierObservateursBPM() {
    for(int i = 0; i < observateursBPM.size(); i++) {
        ObservateurBPM observateur = (ObservateurBPM)observateursBPM.get(i);
        observateur.majBPM();
    }
  }
}

