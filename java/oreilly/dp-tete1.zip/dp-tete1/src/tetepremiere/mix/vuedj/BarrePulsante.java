package tetepremiere.mix.vuedj;

import javax.swing.*;

public class BarrePulsante extends JProgressBar implements Runnable {
  JProgressBar progression;
  Thread thread;

  public BarrePulsante() {
    thread = new Thread(this);
    setMaximum(100);
    thread.start();
  }

  public void run() {
    for(;;) {
      int valeur = getValue();
      valeur = (int)(valeur * .75);
      setValue(valeur);
      repaint();
      try {
        Thread.sleep(50);
      } catch (Exception e) {};
    }
  }
}

