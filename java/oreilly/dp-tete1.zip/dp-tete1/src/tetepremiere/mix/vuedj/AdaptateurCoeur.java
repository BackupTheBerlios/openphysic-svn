package tetepremiere.mix.vuedj;

public class AdaptateurCoeur implements InterfaceModeleTempo {
  InterfaceModeleCoeur coeur;

  public AdaptateurCoeur(InterfaceModeleCoeur coeur) {
    this.coeur = coeur;
  }

  public void initialiser() {}

  public void marche() {}

  public void arret() {}

  public int getBPM() {
    return coeur.getRythmeCardiaque();
  }

  public void setBPM(int bpm) {}

  public void registerObserver(ObservateurBattements o) {
    coeur.registerObserver(o);
  }

  public void removeObserver(ObservateurBattements o) {
    coeur.removeObserver(o);
  }

  public void registerObserver(ObservateurBPM o) {
    coeur.registerObserver(o);
  }

  public void removeObserver(ObservateurBPM o) {
    coeur.removeObserver(o);
  }
}

