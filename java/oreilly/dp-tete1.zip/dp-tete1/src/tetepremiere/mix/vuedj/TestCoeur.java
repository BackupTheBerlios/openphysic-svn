package tetepremiere.mix.vuedj;

public class TestCoeur {
  public static void main (String[] args) {
    ModeleCoeur modeleCoeur = new ModeleCoeur();
    InterfaceControleur modele = new ControleurCoeur(modeleCoeur);
  }
}

