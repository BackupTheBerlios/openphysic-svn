package tetepremiere.mix.vuedj;

public interface InterfaceModeleCoeur {
  int getRythmeCardiaque();
  void registerObserver(ObservateurBattements o);
  void removeObserver(ObservateurBattements o);
  void registerObserver(ObservateurBPM o);
  void removeObserver(ObservateurBPM o);
}

