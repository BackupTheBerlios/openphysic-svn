package tetepremiere.mix.vuedj;

public interface InterfaceControleur {
  void start();
  void stop();
  void augmenterBPM();
  void diminuerBPM();
  void setBPM(int bpm);
}
