package tetepremiere.mix.vuedj;

public class TestDJ {
  public static void main (String[] args) {
    InterfaceModeleTempo modele = new ModeleTempo();
    InterfaceControleur controleur = new ControleurTempo(modele);
  }
}

