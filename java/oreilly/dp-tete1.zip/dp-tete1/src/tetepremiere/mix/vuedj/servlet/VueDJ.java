package tetepremiere.mix.vuedj.servlet;

import tetepremiere.mix.vuedj.*;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VueDJ extends HttpServlet {

	public void init() throws ServletException {
		ModeleTempo modeleTempo = new ModeleTempo();
		modeleTempo.initialiser();
		getServletContext().setAttribute("modeleTempo", modeleTempo);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		this.doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		ModeleTempo modeleTempo = (ModeleTempo) getServletContext()
				.getAttribute("modeleTempo");

		String bpm = request.getParameter("bpm");
		if (bpm == null) {
			bpm = modeleTempo.getBPM() + "";
		}

		String set = request.getParameter("definir");
		if (set != null) {
			int bpmNumber = 90;
			try {
				bpmNumber = Integer.parseInt(bpm);
			} catch (NumberFormatException e) {
				throw new ServletException(
						"Erreur de conversion du BPM en un nombre : "
								+ e.getMessage());
			}
			modeleTempo.setBPM(bpmNumber);
		}

		String decrease = request.getParameter("diminuer");
		if (decrease != null) {
			modeleTempo.setBPM(modeleTempo.getBPM() - 1);
		}
		String increase = request.getParameter("augmenter");
		if (increase != null) {
			modeleTempo.setBPM(modeleTempo.getBPM() + 1);
		}
		String on = request.getParameter("on");
		if (on != null) {
			modeleTempo.marche();
		}
		String off = request.getParameter("off");
		if (off != null) {
			modeleTempo.arret();
		}

		request.setAttribute("modeleTempo", modeleTempo);

		RequestDispatcher dispatcher = request
				.getRequestDispatcher("/jsp/VueDJ.jsp");
		dispatcher.forward(request, response);
	}

}
