package tetepremiere.mix.vuedj;

public interface InterfaceModeleTempo {
  
  void initialiser();

  void marche();

  void arret();

  void setBPM(int bpm);

  int getBPM();

  void registerObserver(ObservateurBattements o);

  void removeObserver(ObservateurBattements o);

  void registerObserver(ObservateurBPM o);

  void removeObserver(ObservateurBPM o);

}

