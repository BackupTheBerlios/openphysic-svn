package tetepremiere.mix.vuedj;

public interface ObservateurBattements {
  void majTempo();
}





