package tetepremiere.mix.vuedj;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VueDJ implements ActionListener, ObservateurBattements, ObservateurBPM {
  InterfaceModeleTempo modele;
  InterfaceControleur controleur;
  JFrame cadreVue;
  JPanel panneauVue;
  BarrePulsante barre;
  JLabel affichageBPM;
  JFrame cadreControle;
  JPanel panneauControle;
  JLabel labelBPM;
  JTextField champTxtBPM;
  JButton definirBPM;
  JButton augmenterBPM;
  JButton diminuerBPM;
  JMenuBar barreMenus;
  JMenu menu;
  JMenuItem choixStart;
  JMenuItem choixStop;

  public VueDJ(InterfaceControleur controleur, InterfaceModeleTempo modele) {
    this.controleur = controleur;
    this.modele = modele;
    modele.registerObserver((ObservateurBattements)this);
    modele.registerObserver((ObservateurBPM)this);
  }

public void creerVue() { 
    // Création de tous les composants Swing
    panneauVue = new JPanel(new GridLayout(1, 2));
    cadreVue = new JFrame("Vue");
    cadreVue.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    cadreVue.setSize(new Dimension(100, 80));
    affichageBPM = new JLabel("hors ligne", SwingConstants.CENTER);
    barre = new BarrePulsante();
    barre.setValue(0);
    JPanel panneauBMP = new JPanel(new GridLayout(2, 1));
    panneauBMP.add(barre);
    panneauBMP.add(affichageBPM);
    panneauVue.add(panneauBMP);
    cadreVue.getContentPane().add(panneauVue, BorderLayout.CENTER);
    cadreVue.pack();
    cadreVue.setVisible(true);
  }

  public void creerCommandes() {
  // Création de tous les composants Swing
  JFrame.setDefaultLookAndFeelDecorated(true);
  cadreControle = new JFrame("Commandes");
  cadreControle.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  cadreControle.setSize(new Dimension(100, 80));

  panneauControle = new JPanel(new GridLayout(1, 2));

  barreMenus = new JMenuBar();
  menu = new JMenu("Commandes DJ");
  choixStart = new JMenuItem("Démarrer");
  menu.add(choixStart);
  choixStart.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent evenement) {
      controleur.start();
    }
  });
  choixStop = new JMenuItem("Arrêter");
  menu.add(choixStop);
  choixStop.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent evenement) {
      controleur.stop();
      //affichageBPM.setText("hors ligne");
    }
  });
  JMenuItem exit = new JMenuItem("Quitter");
  exit.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent evenement) {
      System.exit(0);
    }
  });

    menu.add(exit);
    barreMenus.add(menu);
    cadreControle.setJMenuBar(barreMenus);

    champTxtBPM = new JTextField(2);
    labelBPM = new JLabel("Entrer BPM:", SwingConstants.RIGHT);
    definirBPM = new JButton("Définir");
    definirBPM.setSize(new Dimension(10,40));
    augmenterBPM = new JButton(">>");
    diminuerBPM = new JButton("<<");
    definirBPM.addActionListener(this);
    augmenterBPM.addActionListener(this);
    diminuerBPM.addActionListener(this);

    JPanel panneauBoutons = new JPanel(new GridLayout(1, 2));


    panneauBoutons.add(diminuerBPM);
    panneauBoutons.add(augmenterBPM);

    JPanel panneauSaisie = new JPanel(new GridLayout(1, 2));

    panneauSaisie.add(labelBPM);
    panneauSaisie.add(champTxtBPM);

    JPanel panneauControleInterne = new JPanel(new GridLayout(3, 1));
    panneauControleInterne.add(panneauSaisie);
    panneauControleInterne.add(definirBPM);
    panneauControleInterne.add(panneauBoutons);
    panneauControle.add(panneauControleInterne);

    labelBPM.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
    affichageBPM.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));

    cadreControle.getRootPane().setDefaultButton(definirBPM);
    cadreControle.getContentPane().add(panneauControle, BorderLayout.CENTER);

    cadreControle.pack();
    cadreControle.setVisible(true);
  }

  public void activerChoixStop() {
    choixStop.setEnabled(true);
  }

  public void desactiverChoixStop() {
    choixStop.setEnabled(false);
  }

  public void activerChoixStart() {
    choixStart.setEnabled(true);
  }

  public void desactiverChoixStart() {
    choixStart.setEnabled(false);
  }

  public void actionPerformed(ActionEvent evenement) {
    if (evenement.getSource() == definirBPM) {
        int bpm = Integer.parseInt(champTxtBPM.getText());
        controleur.setBPM(bpm);
    } else if (evenement.getSource() == augmenterBPM) {
        controleur.augmenterBPM();
    } else if (evenement.getSource() == diminuerBPM) {
        controleur.diminuerBPM();
    }
  }

  public void majBPM() {
    int bpm = modele.getBPM();
    if (bpm == 0) {
        affichageBPM.setText("hors ligne");
    } else {
        affichageBPM.setText("Nombre de BPM : " + modele.getBPM());
    }
  }

  public void majTempo() {
    barre.setValue(100);
  }
}


