package tetepremiere.mix.vuedj;

import javax.sound.midi.*;
import java.util.*;

public class ModeleTempo implements InterfaceModeleTempo, MetaEventListener {
  Sequencer sequenceur;
  ArrayList observateursBattements = new ArrayList();
  ArrayList observateursBPM = new ArrayList();
  int bpm = 90;
  // autres variables d'instance
  Sequence sequence;
  Track piste;

  public void initialiser() {
    setUpMidi();
    construirePisteEtDemarrer();
  }

  public void marche() {
    sequenceur.start();
    setBPM(90);
  }

  public void arret() {
    setBPM(0);
    sequenceur.stop();
  }

  public void setBPM(int bpm) {
    this.bpm = bpm;
    sequenceur.setTempoInBPM(getBPM());
    notifierObservateursBPM();
  }

  public int getBPM() {
    return bpm;
  }

  void evenementBattement() {
    notifierObservateursBattements();
  }

  public void registerObserver(ObservateurBattements o) {
    observateursBattements.add(o);
  }

  public void notifierObservateursBattements() {
    for(int i = 0; i < observateursBattements.size(); i++) {
      ObservateurBattements observateur = (ObservateurBattements)observateursBattements.get(i);
      observateur.majTempo();
    }
  }

  public void registerObserver(ObservateurBPM o) {
    observateursBPM.add(o);
  }

  public void notifierObservateursBPM() {
    for(int i = 0; i < observateursBPM.size(); i++) {
      ObservateurBPM observateur = (ObservateurBPM) observateursBPM.get(i);
      observateur.majBPM();
    }
  }

  public void removeObserver(ObservateurBattements o) {
    int i = observateursBattements.indexOf(o);
    if (i >= 0) {
      observateursBattements.remove(i);
    }
  }

  public void removeObserver(ObservateurBPM o) {
    int i = observateursBPM.indexOf(o);
    if (i >= 0) {
      observateursBPM.remove(i);
    }
  }

  public void meta(MetaMessage message) {
    if (message.getType() == 47) {
        evenementBattement();
        sequenceur.start();
        setBPM(getBPM());
    }
  }

  public void setUpMidi() {
    try {
      sequenceur = MidiSystem.getSequencer();

        sequenceur.open();
        sequenceur.addMetaEventListener(this);
        sequence = new Sequence(Sequence.PPQ,4);
        piste = sequence.createTrack();
        sequenceur.setTempoInBPM(getBPM());
      } catch(Exception e) {
              e.printStackTrace();
    }
  }

  public void construirePisteEtDemarrer() {
    int[] listePistes = {35, 0, 46, 0};

    sequence.deleteTrack(null);
    piste = sequence.createTrack();

    makeTracks(listePistes);
    piste.add(makeEvent(192,9,1,0,4));

    try {
        sequenceur.setSequence(sequence);
    } catch(Exception e) {
            e.printStackTrace();
    }
  }

  public void makeTracks(int[] list) {
    for (int i = 0; i < list.length; i++) {
        int key = list[i];
    
        if (key != 0) {
            piste.add(makeEvent(144,9,key, 100, i));
            piste.add(makeEvent(128,9,key, 100, i+1));
        }
    }
  }

  public MidiEvent makeEvent(int comd, int chan, int one, int two, int tick) {
    MidiEvent evenement = null;
    try {
        ShortMessage a = new ShortMessage();
        a.setMessage(comd, chan, one, two);
        evenement = new MidiEvent(a, tick);
    } catch(Exception e) {
            e.printStackTrace();
    }
    return evenement;
  }
}

