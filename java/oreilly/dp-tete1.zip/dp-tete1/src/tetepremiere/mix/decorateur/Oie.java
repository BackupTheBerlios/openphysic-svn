package tetepremiere.mix.decorateur;

public class Oie {
	public void cacarder() {
		System.out.println("Ouinc");
	}

	public String toString() {
		return "Oie";
	}
}
