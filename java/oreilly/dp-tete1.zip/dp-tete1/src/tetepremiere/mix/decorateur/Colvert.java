package tetepremiere.mix.decorateur;

public class Colvert implements Cancaneur {
 
	public void cancaner() {
		System.out.println("Coincoin");
	}
 
	public String toString() {
		return "Colvert";
	}
}
