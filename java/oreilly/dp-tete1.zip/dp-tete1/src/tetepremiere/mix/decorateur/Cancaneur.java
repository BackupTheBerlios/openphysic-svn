package tetepremiere.mix.decorateur;

public interface Cancaneur {
	public void cancaner();
}
