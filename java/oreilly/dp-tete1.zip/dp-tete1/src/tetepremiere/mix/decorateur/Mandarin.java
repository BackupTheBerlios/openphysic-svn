package tetepremiere.mix.decorateur;

public class Mandarin implements Cancaneur {
	public void cancaner() {
		System.out.println("Coincoin");
	}
}
