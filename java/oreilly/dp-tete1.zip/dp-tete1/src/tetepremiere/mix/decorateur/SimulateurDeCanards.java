package tetepremiere.mix.decorateur;

public class SimulateurDeCanards {
	public static void main(String[] args) {
		SimulateurDeCanards simulateur = new SimulateurDeCanards();
		simulateur.simuler();
	}

	void simuler() {
		Cancaneur colvert = new CompteurDeCouacs(new Colvert());
		Cancaneur mandarin = new CompteurDeCouacs(new Mandarin());
		Cancaneur appelant = new CompteurDeCouacs(new Appelant());
		Cancaneur canardEnPlastique = new CompteurDeCouacs(new CanardEnPlastique());
		Cancaneur oie = new AdapteurDOie(new Oie());

		System.out.println("\nSimulateir de canard : avec Décorateur");

		simuler(colvert);
		simuler(mandarin);
		simuler(appelant);
		simuler(canardEnPlastique);
		simuler(oie);

		System.out.println("Nous avons compté " + 
		                   CompteurDeCouacs.getCouacs() + " couacs");
	}

	void simuler(Cancaneur canard) {
		canard.cancaner();
	}
}
