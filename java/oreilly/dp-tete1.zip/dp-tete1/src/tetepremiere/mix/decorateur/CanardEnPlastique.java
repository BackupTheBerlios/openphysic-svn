package tetepremiere.mix.decorateur;

public class CanardEnPlastique implements Cancaneur {
 
	public void cancaner() {
		System.out.println("Couic");
	}
  
	public String toString() {
		return "Canard en plastique";
	}
}
