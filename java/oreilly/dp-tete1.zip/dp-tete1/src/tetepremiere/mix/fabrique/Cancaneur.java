package tetepremiere.mix.fabrique;

public interface Cancaneur {
	public void cancaner();
}
