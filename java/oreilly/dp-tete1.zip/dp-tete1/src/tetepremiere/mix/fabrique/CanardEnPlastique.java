package tetepremiere.mix.fabrique;

public class CanardEnPlastique implements Cancaneur {
 
	public void cancaner() {
		System.out.println("Couic");
	}
  
	public String toString() {
		return "Canard en plastique";
	}
}
