package tetepremiere.mix.fabrique;

public class Leurre implements Cancaneur {
 
	public void cancaner() {
		System.out.println("<< Silence >>");
	}
 
	public String toString() {
		return "Leurre";
	}
}
