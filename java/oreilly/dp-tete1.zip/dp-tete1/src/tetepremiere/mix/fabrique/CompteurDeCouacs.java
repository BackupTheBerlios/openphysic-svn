package tetepremiere.mix.fabrique;

public class CompteurDeCouacs implements Cancaneur {
	Cancaneur canard;
	static int nombreDeCouacs;
  
	public CompteurDeCouacs(Cancaneur canard) {
		this.canard = canard;
	}
  
	public void cancaner() {
		canard.cancaner();
		nombreDeCouacs++;
	}
 
	public static int getCouacs() {
		return nombreDeCouacs;
	}
   
	public String toString() {
		return canard.toString();
	}
}
