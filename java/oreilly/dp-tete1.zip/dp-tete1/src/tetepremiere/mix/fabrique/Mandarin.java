package tetepremiere.mix.fabrique;

public class Mandarin implements Cancaneur {
	public void cancaner() {
		System.out.println("CoinCoin");
	}
}
