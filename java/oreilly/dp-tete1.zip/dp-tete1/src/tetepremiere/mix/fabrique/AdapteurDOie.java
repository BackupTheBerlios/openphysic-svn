package tetepremiere.mix.fabrique;

public class AdapteurDOie implements Cancaneur {
	Oie oie;
 
	public AdapteurDOie(Oie oie) {
		this.oie = oie;
	}
  
	public void cancaner() {
		oie.cacarder();
	}
 
	public String toString() {
		return "Une oie prétendant être un canard";
	}
}
