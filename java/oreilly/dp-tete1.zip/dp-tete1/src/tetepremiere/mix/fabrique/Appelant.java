package tetepremiere.mix.fabrique;

public class Appelant implements Cancaneur {
 
	public void cancaner() {
		System.out.println("Couincouin");
	}
 
	public String toString() {
		return "Appelant";
	}
}
