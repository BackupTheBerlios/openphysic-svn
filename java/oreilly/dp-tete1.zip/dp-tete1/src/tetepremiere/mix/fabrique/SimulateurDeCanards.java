package tetepremiere.mix.fabrique;

public class SimulateurDeCanards {
	public static void main(String[] args) {
		SimulateurDeCanards simulateur = new SimulateurDeCanards();
		FabriqueDeCanardsAbstraite fabriqueDeCanards = new FabriqueDeComptage();
 
		simulateur.simuler(fabriqueDeCanards);
	}
 
	void simuler(FabriqueDeCanardsAbstraite fabriqueDeCanards) {
		Cancaneur colvert = fabriqueDeCanards.creerColvert();
		Cancaneur mandarin = fabriqueDeCanards.creerMandarin();
		Cancaneur appelant = fabriqueDeCanards.creerAppelant();
		Cancaneur canardEnPlastique = fabriqueDeCanards.creerCanardEnPlastique();
		Cancaneur canardOie = new AdapteurDOie(new Oie());
 
		System.out.println("\nSimulateur de canards : avec Fabrique abstraite");
 
		simulate(colvert);
		simulate(mandarin);
		simulate(appelant);
		simulate(canardEnPlastique);
		simulate(canardOie);
 
		System.out.println("Nous avons compté " + 
		                   CompteurDeCouacs.getCouacs() + 
		                   " couacs");
	}
 
	void simulate(Cancaneur canard) {
		canard.cancaner();
	}
}
