package tetepremiere.mix.canards;

public class Appelant implements Cancaneur {
	public void cancaner() {
		System.out.println("Couincouin");
	}
}
