package tetepremiere.mix.canards;

public class Leurre implements Cancaneur {
	public void cancaner() {
		System.out.println("<< Silence >>");
	}
}
