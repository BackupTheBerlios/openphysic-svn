package tetepremiere.mix.canards;

public class Colvert implements Cancaneur {
	public void cancaner() {
		System.out.println("Coincoin");
	}
}
