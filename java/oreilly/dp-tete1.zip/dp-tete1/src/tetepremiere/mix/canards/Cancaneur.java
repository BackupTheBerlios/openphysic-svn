package tetepremiere.mix.canards;

public interface Cancaneur {
	public void cancaner();
}
