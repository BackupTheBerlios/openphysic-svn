package tetepremiere.mix.canards;

public class Mandarin implements Cancaneur {
	public void cancaner() {
		System.out.println("Coincoin");
	}
}
