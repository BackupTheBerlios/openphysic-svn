package tetepremiere.mix.canards;

public class CanardEnPlastique implements Cancaneur {
	public void cancaner() {
		System.out.println("Couic");
	}
}
