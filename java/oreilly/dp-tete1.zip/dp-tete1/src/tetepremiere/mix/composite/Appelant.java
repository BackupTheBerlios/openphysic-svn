package tetepremiere.mix.composite;

public class Appelant implements Cancaneur {
 
	public void cancaner() {
		System.out.println("Couic");
	}
 
	public String toString() {
		return "Appelant";
	}
}
