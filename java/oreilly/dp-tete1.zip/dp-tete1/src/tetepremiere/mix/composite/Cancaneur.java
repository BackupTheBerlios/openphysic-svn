package tetepremiere.mix.composite;

public interface Cancaneur {
	public void cancaner();
}
