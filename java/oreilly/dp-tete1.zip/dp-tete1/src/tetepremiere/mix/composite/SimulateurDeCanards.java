package tetepremiere.mix.composite;

public class SimulateurDeCanards {

	public static void main(String[] args) {
		SimulateurDeCanards simulateur = new SimulateurDeCanards();
		FabriqueDeCanardsAbstraite fabriqueDeCanards = new FabriqueDeComptage();
 
		simulateur.simuler(fabriqueDeCanards);
	}
 
	void simuler(FabriqueDeCanardsAbstraite fabriqueDeCanards) {
		Cancaneur mandarin = fabriqueDeCanards.creerMandarin();
		Cancaneur duckCall = fabriqueDeCanards.creerAppelant();
		Cancaneur canardEnPlastique = fabriqueDeCanards.creerCanardEnPlastique();
		Cancaneur canardOie = new AdapteurDOie(new Oie());

		System.out.println("\nSimulateur de canards : avec Composite - Troupes");

		Troupe troupeDeCanards = new Troupe();

		troupeDeCanards.add(mandarin);
		troupeDeCanards.add(duckCall);
		troupeDeCanards.add(canardEnPlastique);
		troupeDeCanards.add(canardOie);

		Troupe troupeDeColverts = new Troupe();

		Cancaneur colvertUn = fabriqueDeCanards.creerColvert();
		Cancaneur colvertDeux = fabriqueDeCanards.creerColvert();
		Cancaneur colvertTrois = fabriqueDeCanards.creerColvert();
		Cancaneur colvertQuatre = fabriqueDeCanards.creerColvert();

		troupeDeColverts.add(colvertUn);
		troupeDeColverts.add(colvertDeux);
		troupeDeColverts.add(colvertTrois);
		troupeDeColverts.add(colvertQuatre);

		troupeDeCanards.add(troupeDeColverts);

		System.out.println("\nSimulateur de canards : Toute la troupe");
		simulate(troupeDeCanards);

		System.out.println("\nSimulateur de canards : Troupe de colverts");
		simulate(troupeDeColverts);

		System.out.println("\nNous avons compté " + 
		                   CompteurDeCouacs.getCouacs() + 
		                   " couacs");
	}

	void simulate(Cancaneur canard) {
		canard.cancaner();
	}
}
