package tetepremiere.mix.composite;

public class AdapteurDOie implements Cancaneur {
	Oie oie;

	public AdapteurDOie(Oie goose) {
		this.oie = goose;
	}
 
	public void cancaner() {
		oie.cacarder();
	}

	public String toString() {
		return "Une oie prétendant être un canard";
	}
}
