package tetepremiere.mix.composite;

public class FabriqueDeCanards extends FabriqueDeCanardsAbstraite {
  
	public Cancaneur creerColvert() {
		return new Colvert();
	}
  
	public Cancaneur creerMandarin() {
		return new Mandarin();
	}
  
	public Cancaneur creerAppelant() {
		return new Appelant();
	}
   
	public Cancaneur creerCanardEnPlastique() {
		return new CanardEnPlastique();
	}
}
