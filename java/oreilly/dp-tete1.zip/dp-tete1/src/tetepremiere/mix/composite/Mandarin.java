package tetepremiere.mix.composite;

public class Mandarin implements Cancaneur {
	public void cancaner() {
		System.out.println("Cancan");
	}

	public String toString() {
		return "Mandarin";
	}
}
