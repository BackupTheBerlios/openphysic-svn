package tetepremiere.mix.composite;

public class Colvert implements Cancaneur {
 
	public void cancaner() {
		System.out.println("CoinCoin");
	}
 
	public String toString() {
		return "Colvert";
	}
}
