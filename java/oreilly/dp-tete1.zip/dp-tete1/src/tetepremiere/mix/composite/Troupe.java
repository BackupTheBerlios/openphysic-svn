package tetepremiere.mix.composite;

import java.util.Iterator;
import java.util.ArrayList;

public class Troupe implements Cancaneur {
	ArrayList canards = new ArrayList();
 
	public void add(Cancaneur canard) {
		canards.add(canard);
	}
 
	public void cancaner() {
		Iterator iterator = canards.iterator();
		while (iterator.hasNext()) {
			Cancaneur canard = (Cancaneur)iterator.next();
			canard.cancaner();
		}
	}
 
	public String toString() {
		return "Troupe de canards";
	}
}
