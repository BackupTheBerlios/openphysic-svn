package tetepremiere.mix.composite;

public class CanardEnPlastique implements Cancaneur {
 
	public void cancaner() {
		System.out.println("Coincoin");
	}
  
	public String toString() {
		return "Canard en plastique";
	}
}
