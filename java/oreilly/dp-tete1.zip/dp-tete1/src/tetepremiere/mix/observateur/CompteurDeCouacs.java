package tetepremiere.mix.observateur;

public class CompteurDeCouacs implements Cancaneur {
	Cancaneur canard;
	static int nombreDeCouacs;
  
	public CompteurDeCouacs(Cancaneur canard) {
		this.canard = canard;
	}
  
	public void cancaner() {
		canard.cancaner();
		nombreDeCouacs++;
	}
 
	public static int getCouacs() {
		return nombreDeCouacs;
	}

	public void enregistrerObservateur(Observateur observateur) {
		canard.enregistrerObservateur(observateur);
	}
 
	public void notifierObservateurs() {
		canard.notifierObservateurs();
	}
   
	public String toString() {
		return canard.toString();
	}
}
