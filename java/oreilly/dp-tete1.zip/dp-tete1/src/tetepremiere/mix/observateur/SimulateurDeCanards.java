package tetepremiere.mix.observateur;

public class SimulateurDeCanards {
	public static void main(String[] args) {
		SimulateurDeCanards simulateur = new SimulateurDeCanards();
		FabriqueDeCanardsAbstraite fabriqueDeCanards = new FabriqueDeComptage();
 
		simulateur.simuler(fabriqueDeCanards);
	}
  
	void simuler(FabriqueDeCanardsAbstraite fabriqueDeCanards) {
  
		Cancaneur mandarin = fabriqueDeCanards.creerMandarin();
		Cancaneur appelant = fabriqueDeCanards.creerAppelant();
		Cancaneur canardEnPlastique = fabriqueDeCanards.creerCanardEnPlastique();
		Cancaneur canardOie = new AdapteurDOie(new Oie());
 
		Troupe troupeDeCanards = new Troupe();
 
		troupeDeCanards.ajouter(mandarin);
		troupeDeCanards.ajouter(appelant);
		troupeDeCanards.ajouter(canardEnPlastique);
		troupeDeCanards.ajouter(canardOie);
 
		Troupe troupeDeColverts = new Troupe();
 
		Cancaneur colvertUn = fabriqueDeCanards.creerColvert();
		Cancaneur colvertDeux = fabriqueDeCanards.creerColvert();
		Cancaneur colvertTrois = fabriqueDeCanards.creerColvert();
		Cancaneur colvertQuatre = fabriqueDeCanards.creerColvert();

		troupeDeColverts.ajouter(colvertUn);
		troupeDeColverts.ajouter(colvertDeux);
		troupeDeColverts.ajouter(colvertTrois);
		troupeDeColverts.ajouter(colvertQuatre);

		troupeDeCanards.ajouter(troupeDeColverts);

		System.out.println("\nSimulateur de canards : Toute la troupe");

		Cancanologue cancanologue = new Cancanologue();
		troupeDeCanards.enregistrerObservateur(cancanologue);

		simuler(troupeDeCanards);

		System.out.println("\nNous avons compté " + 
		                   CompteurDeCouacs.getCouacs() + 
		                   " couacs");
	}
 
	void simuler(Cancaneur canard) {
		canard.cancaner();
	}
}
