package tetepremiere.mix.observateur;

public class Mandarin implements Cancaneur {
	Observable observable;

	public Mandarin() {
		observable = new Observable(this);
	}

	public void cancaner() {
		System.out.println("CoinCoin");
		notifierObservateurs();
	}

	public void enregistrerObservateur(Observateur observateur) {
		observable.enregistrerObservateur(observateur);
	}

	public void notifierObservateurs() {
		observable.notifierObservateurs();
	}

	public String toString() {
		return "Colvert";
	}
}
