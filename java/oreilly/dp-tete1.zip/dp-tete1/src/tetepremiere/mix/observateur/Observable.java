package tetepremiere.mix.observateur;

import java.util.Iterator;
import java.util.ArrayList;

public class Observable implements CouacObservable {
	ArrayList observeurs = new ArrayList();
	CouacObservable canard;
 
	public Observable(CouacObservable duck) {
		this.canard = duck;
	}
  
	public void enregistrerObservateur(Observateur observateur) {
		observeurs.add(observateur);
	}
  
	public void notifierObservateurs() {
		Iterator iterator = observeurs.iterator();
		while (iterator.hasNext()) {
			Observateur observer = (Observateur)iterator.next();
			observer.actualiser(canard);
		}
	}
 
	public Iterator getObserveurs() {
		return observeurs.iterator();
	}
}
