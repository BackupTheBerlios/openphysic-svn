package tetepremiere.mix.observateur;

public interface Cancaneur extends CouacObservable {
	public void cancaner();
}
