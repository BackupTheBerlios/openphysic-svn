package tetepremiere.mix.observateur;

public class Oie {

	public void cacarder() {
		System.out.println("Ouinc");
	}

	public String toString() {
		return "Oie";
	}
}
