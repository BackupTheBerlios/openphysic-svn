package tetepremiere.mix.observateur;

public interface Observateur {
	public void actualiser(CouacObservable canard);
}
