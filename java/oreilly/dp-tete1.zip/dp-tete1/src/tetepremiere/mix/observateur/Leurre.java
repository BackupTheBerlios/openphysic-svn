package tetepremiere.mix.observateur;

public class Leurre implements Cancaneur {
	Observable observable;

	public Leurre() {
		observable = new Observable(this);
	}
 
	public void cancaner() {
		System.out.println("<< Silence >>");
		notifierObservateurs();
	}
 
	public void enregistrerObservateur(Observateur observateur) {
		observable.enregistrerObservateur(observateur);
	}

	public void notifierObservateurs() {
		observable.notifierObservateurs();
	}
 
	public String toString() {
		return "Leurre";
	}
}
