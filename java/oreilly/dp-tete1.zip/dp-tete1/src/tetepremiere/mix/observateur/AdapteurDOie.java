package tetepremiere.mix.observateur;

public class AdapteurDOie implements Cancaneur {
	Oie oie;
	Observable observable;

	public AdapteurDOie(Oie oie) {
		this.oie = oie;
		observable = new Observable(this);
	}
 
	public void cancaner() {
		oie.cacarder();
		notifierObservateurs();
	}

	public void enregistrerObservateur(Observateur observateur) {
		observable.enregistrerObservateur(observateur);
	}

	public void notifierObservateurs() {
		observable.notifierObservateurs();
	}

	public String toString() {
		return "Une oie prétendant être un canard";
	}
}
