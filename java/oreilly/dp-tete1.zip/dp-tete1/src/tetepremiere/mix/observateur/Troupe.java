package tetepremiere.mix.observateur;

import java.util.Iterator;
import java.util.ArrayList;

public class Troupe implements Cancaneur {
	ArrayList canards = new ArrayList();
  
	public void ajouter(Cancaneur canard) {
		canards.add(canard);
	}
  
	public void cancaner() {
		Iterator iterateur = canards.iterator();
		while (iterateur.hasNext()) {
			Cancaneur canard = (Cancaneur)iterateur.next();
			canard.cancaner();
		}
	}
   
	public void enregistrerObservateur(Observateur observateur) {
		Iterator iterateur = canards.iterator();
		while (iterateur.hasNext()) {
			Cancaneur canard = (Cancaneur)iterateur.next();
			canard.enregistrerObservateur(observateur);
		}
	}
  
	public void notifierObservateurs() { }
  
	public String toString() {
		return "Troupe de canards";
	}
}
