package tetepremiere.mix.observateur;

public class CanardEnPlastique implements Cancaneur {
	Observable observable;

	public CanardEnPlastique() {
		observable = new Observable(this);
	}
 
	public void cancaner() {
		System.out.println("Couic");
		notifierObservateurs();
	}

	public void enregistrerObservateur(Observateur observateur) {
		observable.enregistrerObservateur(observateur);
	}

	public void notifierObservateurs() {
		observable.notifierObservateurs();
	}
  
	public String toString() {
		return "Canard en plastique";
	}
}
