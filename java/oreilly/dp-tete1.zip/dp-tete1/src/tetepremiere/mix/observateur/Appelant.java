package tetepremiere.mix.observateur;

public class Appelant implements Cancaneur {
	Observable observable;

	public Appelant() {
		observable = new Observable(this);
	}
 
	public void cancaner() {
		System.out.println("Couincouin");
		notifierObservateurs();
	}
 
	public void enregistrerObservateur(Observateur observateur) {
		observable.enregistrerObservateur(observateur);
	}

	public void notifierObservateurs() {
		observable.notifierObservateurs();
	}
 
	public String toString() {
		return "Appelant";
	}
}
