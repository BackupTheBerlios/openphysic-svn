package tetepremiere.mix.adapteur;

public class CanardEnPlastique implements Cancaneur {
	public void cancaner() {
		System.out.println("Couic");
	}
}
