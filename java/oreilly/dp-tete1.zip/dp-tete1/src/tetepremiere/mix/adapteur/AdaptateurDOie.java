package tetepremiere.mix.adapteur;

public class AdaptateurDOie implements Cancaneur {
	Oie oie;
 
	public AdaptateurDOie(Oie oie) {
		this.oie = oie;
	}
 
	public void cancaner() {
		oie.cacarder();
	}

	public String toString() {
		return "Une oie prétendant être un canard";
	}
}
