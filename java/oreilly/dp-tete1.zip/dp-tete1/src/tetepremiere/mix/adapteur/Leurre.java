package tetepremiere.mix.adapteur;

public class Leurre implements Cancaneur {
	public void cancaner() {
		System.out.println("<< Silence >>");
	}
}
