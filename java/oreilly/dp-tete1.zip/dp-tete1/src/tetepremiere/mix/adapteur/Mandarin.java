package tetepremiere.mix.adapteur;

public class Mandarin implements Cancaneur {
	public void cancaner() {
		System.out.println("Coincoin");
	}
}
