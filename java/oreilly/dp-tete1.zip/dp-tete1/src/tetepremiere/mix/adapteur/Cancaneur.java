package tetepremiere.mix.adapteur;

public interface Cancaneur {
	public void cancaner();
}
