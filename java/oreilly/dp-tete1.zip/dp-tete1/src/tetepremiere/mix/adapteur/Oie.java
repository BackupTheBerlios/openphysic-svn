package tetepremiere.mix.adapteur;

public class Oie {
	public void cacarder() {
		System.out.println("Ouinc");
	}
}
