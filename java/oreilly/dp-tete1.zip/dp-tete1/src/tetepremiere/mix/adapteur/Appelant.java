package tetepremiere.mix.adapteur;

public class Appelant implements Cancaneur {
	public void cancaner() {
		System.out.println("Couincouin");
	}
}
