package tetepremiere.commande.telecommandesimple;

public class TestTelecommande {
	public static void main(String[] args) {
		SimpleTelecommande telecommande = new SimpleTelecommande();
		Lampe lampe = new Lampe();
		PorteGarage porteGarage = new PorteGarage();
		CommandeAllumerLampe lampeAllumee = new CommandeAllumerLampe(lampe);
		CommandeOuvrirPorteGarage garageOuvert = 
		    new CommandeOuvrirPorteGarage(porteGarage);
 
		telecommande.setCommande(lampeAllumee);
		telecommande.boutonPresse();
		telecommande.setCommande(garageOuvert);
		telecommande.boutonPresse();
    }
}
