package tetepremiere.commande.telecommandesimple;

public class PorteGarage {

	public PorteGarage() {
	}

	public void monter() {
		System.out.println("La porte du garage est ouverte");
	}

	public void baisser() {
		System.out.println("La porte du garage est fermée");
	}

	public void arreter() {
		System.out.println("La porte du garage est arrêtée");
	}

	public void allumerLumiere() {
		System.out.println("La lumière du garage est allumée");
	}

	public void eteindreLumiere() {
		System.out.println("La lumière du garage est éteinte");
	}
}
