package tetepremiere.commande.telecommandesimple;

public class Lampe {

	public Lampe() {
	}

	public void marche() {
		System.out.println("lampe allumée");
	}

	public void arret() {
		System.out.println("lampe éteinte");
	}
}
