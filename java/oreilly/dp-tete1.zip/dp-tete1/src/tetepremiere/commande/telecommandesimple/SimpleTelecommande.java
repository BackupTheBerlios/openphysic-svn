package tetepremiere.commande.telecommandesimple;

//
// Voici l'invocateur
//
public class SimpleTelecommande {
	Commande emplacement;
 
	public SimpleTelecommande() {}
 
	public void setCommande(Commande commande) {
		emplacement = commande;
	}
 
	public void boutonPresse() {
		emplacement.executer();
	}
}
