package tetepremiere.commande.telecommandesimple;

public interface Commande {
	public void executer();
}
