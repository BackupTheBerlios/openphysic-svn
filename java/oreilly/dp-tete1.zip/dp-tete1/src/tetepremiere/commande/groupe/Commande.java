package tetepremiere.commande.groupe;

public interface Commande {
	public void executer();
	public void annuler();
}
