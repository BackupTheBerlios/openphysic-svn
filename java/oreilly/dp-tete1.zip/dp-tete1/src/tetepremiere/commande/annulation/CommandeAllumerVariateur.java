package tetepremiere.commande.annulation;

public class CommandeAllumerVariateur implements Commande {
	Lampe lampe;
	int dernierNiveau;

	public CommandeAllumerVariateur(Lampe lampe) {
		this.lampe = lampe;
		;
	}

	public void executer() {
		dernierNiveau = lampe.getNiveau();
		lampe.attenuer(75);
	}

	public void annuler() {
		lampe.attenuer(dernierNiveau);
	}
}
