package tetepremiere.commande.annulation;

public interface Commande {
	public void executer();
	public void annuler();
}
