package tetepremiere.commande.annulation;

public class Ventilateur {
	public static final int RAPIDE = 3;
	public static final int MOYEN = 2;
	public static final int LENT = 1;
	public static final int ARRET = 0;
	String localisation;
	int vitesse;
 
	public Ventilateur(String location) {
		this.localisation = location;
		vitesse = ARRET;
	}
  
	public void rapide() {
		vitesse = RAPIDE;
		System.out.println(localisation + ": ventilateur sur rapide");
	} 
 
	public void moyen() {
		vitesse = MOYEN;
		System.out.println(localisation + ": ventilateur sur moyen");
	}
 
	public void lent() {
		vitesse = LENT;
		System.out.println(localisation + ": ventilateur sur lent");
	}
  
	public void arret() {
		vitesse = ARRET;
		System.out.println(localisation + ": ventilateur éteint");
	}
  
	public int getVitesse() {
		return vitesse;
	}
}
