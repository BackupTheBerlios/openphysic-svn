package tetepremiere.commande.annulation;

public class CommandeEteindreVariateur implements Commande {
	Lampe lampe;
	int dernierNiveau;

	public CommandeEteindreVariateur(Lampe lampe) {
		this.lampe = lampe;
		dernierNiveau = 100;
	}

	public void executer() {
		dernierNiveau = lampe.getNiveau();
		lampe.arret();
	}

	public void annuler() {
		lampe.attenuer(dernierNiveau);
	}
}
