package tetepremiere.commande.annulation;

public class CommandeVentilateurLent implements Commande {
	Ventilateur ventilateur;
	int derniereVitesse;
  
	public CommandeVentilateurLent(Ventilateur ventilateur) {
		this.ventilateur = ventilateur;
	}
 
	public void executer() {
		derniereVitesse = ventilateur.getVitesse();
		ventilateur.lent();
	}
 
	public void annuler() {
		if (derniereVitesse == Ventilateur.RAPIDE) {
			ventilateur.rapide();
		} else if (derniereVitesse == Ventilateur.MOYEN) {
			ventilateur.moyen();
		} else if (derniereVitesse == Ventilateur.LENT) {
			ventilateur.lent();
		} else if (derniereVitesse == Ventilateur.ARRET) {
			ventilateur.arret();
		}
	}
}
