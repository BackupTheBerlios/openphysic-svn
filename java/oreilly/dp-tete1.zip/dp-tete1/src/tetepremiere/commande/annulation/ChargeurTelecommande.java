package tetepremiere.commande.annulation;

public class ChargeurTelecommande {
 
	public static void main(String[] args) {
		TelecommandeAvecAnnul teleCommande = new TelecommandeAvecAnnul();
 
		Lampe lampeSejour = new Lampe("Séjour");
 
		CommandeAllumerLampe lampeSejourAllumee = 
				new CommandeAllumerLampe(lampeSejour);
		CommandeEteindreLampe lampeSejourEteinte = 
				new CommandeEteindreLampe(lampeSejour);
 
		teleCommande.setCommande(0, lampeSejourAllumee, lampeSejourEteinte);
 
		teleCommande.boutonMarchePresse(0);
		teleCommande.boutonArretPresse(0);
		System.out.println(teleCommande);
		teleCommande.boutonAnnulPresse();
		teleCommande.boutonArretPresse(0);
		teleCommande.boutonMarchePresse(0);
		System.out.println(teleCommande);
		teleCommande.boutonAnnulPresse();

		Ventilateur ventilateur = new Ventilateur("Séjour");
   
		CommandeVentilateurMoyen ventilMoyen = 
				new CommandeVentilateurMoyen(ventilateur);
		CommandeVentilateurRapide ventilRapide = 
				new CommandeVentilateurRapide(ventilateur);
		CommandeEteindreVentilateur ventilEteint = 
				new CommandeEteindreVentilateur(ventilateur);
  
		teleCommande.setCommande(0, ventilMoyen, ventilEteint);
		teleCommande.setCommande(1, ventilRapide, ventilEteint);
   
		teleCommande.boutonMarchePresse(0);
		teleCommande.boutonArretPresse(0);
		System.out.println(teleCommande);
		teleCommande.boutonAnnulPresse();
  
		teleCommande.boutonMarchePresse(1);
		System.out.println(teleCommande);
		teleCommande.boutonAnnulPresse();
	}
}
