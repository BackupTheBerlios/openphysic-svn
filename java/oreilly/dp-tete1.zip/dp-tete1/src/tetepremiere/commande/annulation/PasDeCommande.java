package tetepremiere.commande.annulation;

public class PasDeCommande implements Commande {
	public void executer() { }
	public void annuler() { }
}
