package tetepremiere.commande.annulation;

public class Lampe {
	String localisation;
	int niveau;

	public Lampe(String location) {
		this.localisation = location;
	}

	public void marche() {
		niveau = 100;
		System.out.println("Lumière allumée");
	}

	public void arret() {
		niveau = 0;
		System.out.println("Lumière éteinte");
	}

	public void attenuer(int niveau) {
		this.niveau = niveau;
		if (niveau == 0) {
			arret();
		}
		else {
			System.out.println("Le niveau de la lampe est positionné sur " + niveau + "%");
		}
	}

	public int getNiveau() {
		return niveau;
	}
}
