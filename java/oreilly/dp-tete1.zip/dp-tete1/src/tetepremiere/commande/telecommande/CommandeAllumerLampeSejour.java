package tetepremiere.commande.telecommande;

public class CommandeAllumerLampeSejour implements Commande {
	Lampe lampe;

	public CommandeAllumerLampeSejour(Lampe lampe) {
		this.lampe = lampe;
	}

	public void executer() {
		lampe.marche();
	}
}
