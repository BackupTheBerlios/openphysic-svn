package tetepremiere.commande.telecommande;

public class CommandeEteindreLampeSejour implements Commande {
	Lampe lampe;

	public CommandeEteindreLampeSejour(Lampe lampe) {
		this.lampe = lampe;
	}

	public void executer() {
		lampe.arret();
	}
}
