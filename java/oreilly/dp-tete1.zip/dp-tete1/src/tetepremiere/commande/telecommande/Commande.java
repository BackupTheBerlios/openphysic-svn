package tetepremiere.commande.telecommande;

public interface Commande {
	public void executer();
}
