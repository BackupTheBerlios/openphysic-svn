package tetepremiere.commande.telecommande;

public class Jacuzzi {
	boolean allume;
	int temperature;

	public Jacuzzi() {
	}

	public void allumer() {
		allume = true;
	}

	public void eteindre() {
		allume = false;
	}

	public void bouillonner() {
		if (allume) {
			System.out.println("Le jaccuzi bouillonne !");
		}
	}

	public void arreterBouillonner() {
		if (allume) {
			System.out.println("Le jaccuzi ne bouillonne pas");
		}
	}

	public void marche() {
		if (allume) {
			System.out.println("Le jaccuzi est en marche");
		}
	}

	public void arret() {
		if (allume) {
			System.out.println("Le jaccuzi est arrêté");
		}
	}

	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}

	public void chauffer() {
		temperature = 40;
		System.out.println("Le jaccuzi chauffe à 40°");
	}

	public void refroidir() {
		temperature = 36;
		System.out.println("Le jaccuzi refroidit à 36°");
	}

}
