package tetepremiere.commande.telecommande;

public class CommandeEteindreStereo implements Commande {
	Stereo stereo;
 
	public CommandeEteindreStereo(Stereo stereo) {
		this.stereo = stereo;
	}
 
	public void executer() {
		stereo.arreter();
	}
}
