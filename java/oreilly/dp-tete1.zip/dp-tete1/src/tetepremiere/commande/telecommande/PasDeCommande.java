package tetepremiere.commande.telecommande;

public class PasDeCommande implements Commande {
	public void executer() { }
}
