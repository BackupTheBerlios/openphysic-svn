package tetepremiere.commande.telecommande;

public class Lampe {
	String localisation = "";

	public Lampe(String localisation) {
		this.localisation = localisation;
	}

	public void marche() {
		System.out.println(localisation + ": lampe allumée");
	}

	public void arret() {
		System.out.println(localisation + ": lampe éteinte");
	}
}
