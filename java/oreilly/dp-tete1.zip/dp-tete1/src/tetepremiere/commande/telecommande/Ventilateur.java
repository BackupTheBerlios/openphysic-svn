package tetepremiere.commande.telecommande;

public class Ventilateur {
	String localisation = "";
	int vitesse;
	public static final int RAPIDE = 2;
	public static final int MOYEN = 1;
	public static final int LENT = 0;
 
	public Ventilateur(String localisation) {
		this.localisation = localisation;
	}
  
	public void rapide() {
		// regler le ventilateur sur rapide
		vitesse = RAPIDE;
		System.out.println(localisation + ": ventilateur sur rapide");
 
	} 

	public void moyen() {
		// regler le ventilateur sur moyen
		vitesse = MOYEN;
		System.out.println(localisation + ": ventilateur sur moyen");
	}

	public void lent() {
		// regler le ventilateur sur lent
		vitesse = LENT;
		System.out.println(localisation + ": ventilateur sur lent");
	}
 
	public void arreter() {
		// arrete le ventilateur
		vitesse = 0;
		System.out.println(localisation + ": ventilateur arrêté");
	}
 
	public int getVitesse() {
		return vitesse;
	}
}
