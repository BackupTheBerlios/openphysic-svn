package tetepremiere.commande.telecommande;

public class TV {
	String localisation;
	int canal;

	public TV(String localisation) {
		this.localisation = localisation;
	}

	public void marche() {
		System.out.println("La télé est allumée");
	}

	public void arret() {
		System.out.println("La télé est éteinte");
	}

	public void selectionnerCanal() {
		this.canal = 3;
		System.out.println("Le canal est positionné sur VCR");
	}
}
