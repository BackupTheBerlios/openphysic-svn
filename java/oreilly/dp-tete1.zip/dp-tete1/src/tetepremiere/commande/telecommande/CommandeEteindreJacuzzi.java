package tetepremiere.commande.telecommande;

public class CommandeEteindreJacuzzi implements Commande {
	Jacuzzi jacuzzi;

	public CommandeEteindreJacuzzi(Jacuzzi jacuzzi) {
		this.jacuzzi = jacuzzi;
	}

	public void executer() {
		jacuzzi.refroidir();
		jacuzzi.eteindre();
	}
}
