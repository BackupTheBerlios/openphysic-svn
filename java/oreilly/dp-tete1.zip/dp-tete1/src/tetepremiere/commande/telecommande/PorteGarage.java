package tetepremiere.commande.telecommande;

public class PorteGarage {
	String localisation;

	public PorteGarage(String localisation) {
		this.localisation = localisation;
	}

	public void monter() {
		System.out.println(localisation + ": la porte du garage est ouverte");
	}

	public void baisser() {
		System.out.println(localisation + ": la porte du garage est fermée");
	}

	public void arreter() {
		System.out.println(localisation + ": la porte du garage est arrêtée");
	}

	public void allumerLumiere() {
		System.out.println(localisation + ": la lumière du garage est allumée");
	}

	public void eteindreLumiere() {
		System.out.println(localisation + ": la lumière du garage est éteinte");
	}
}
