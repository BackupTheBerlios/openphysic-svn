package tetepremiere.fabrique.pizzaaf;

public class Champignon implements Legume {

	public String toString() {
		return "Champignon";
	}
}
