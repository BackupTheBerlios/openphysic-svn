package tetepremiere.fabrique.pizzaaf;

public class PateSoufflee implements Pate {
	public String toString() {
		return "Pâte soufflée";
	}
}
