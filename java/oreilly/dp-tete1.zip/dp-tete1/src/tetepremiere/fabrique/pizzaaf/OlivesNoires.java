package tetepremiere.fabrique.pizzaaf;

public class OlivesNoires implements Legume {

	public String toString() {
		return "Olives noires";
	}
}
