package tetepremiere.fabrique.pizzaaf;

public class Mozzarella implements Fromage {

	public String toString() {
		return "Mozzarella";
	}
}
