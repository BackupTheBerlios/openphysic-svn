package tetepremiere.fabrique.pizzaaf;

public class MoulesSurgelees implements Moules {

	public String toString() {
		return "Moules surgelées";
	}
}
