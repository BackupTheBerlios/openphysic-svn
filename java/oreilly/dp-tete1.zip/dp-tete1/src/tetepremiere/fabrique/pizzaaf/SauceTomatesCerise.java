package tetepremiere.fabrique.pizzaaf;

public class SauceTomatesCerise implements Sauce {
	public String toString() {
		return "Sauce tomates cerise";
	}
}
