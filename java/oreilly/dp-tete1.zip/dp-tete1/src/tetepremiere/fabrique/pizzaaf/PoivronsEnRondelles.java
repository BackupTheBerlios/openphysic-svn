package tetepremiere.fabrique.pizzaaf;

public class PoivronsEnRondelles implements Poivrons {

	public String toString() {
		return "Poivrons en rondelles";
	}
}
