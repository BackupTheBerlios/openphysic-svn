package tetepremiere.fabrique.pizzaaf;

public class PoivronRouge implements Legume {

	public String toString() {
		return "Poivron rouge";
	}
}
