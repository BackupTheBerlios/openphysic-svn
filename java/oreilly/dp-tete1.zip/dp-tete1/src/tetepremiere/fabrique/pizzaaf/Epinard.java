package tetepremiere.fabrique.pizzaaf;

public class Epinard implements Legume {

	public String toString() {
		return "Epinard";
	}
}
