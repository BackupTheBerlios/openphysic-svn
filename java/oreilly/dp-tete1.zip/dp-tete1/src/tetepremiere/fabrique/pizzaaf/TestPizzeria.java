package tetepremiere.fabrique.pizzaaf;

public class TestPizzeria {
 
	public static void main(String[] args) {
		Pizzeria pizzeriaBrest = new PizzeriaBrest();
		Pizzeria pizzeriaStrasbourg = new PizzeriaStrasbourg();
 
		Pizza pizza = pizzeriaBrest.commanderPizza("fromage");
		System.out.println("Luc a commandé une " + pizza + "\n");
 
		pizza = pizzeriaStrasbourg.commanderPizza("fromage");
		System.out.println("Michel a commandé une " + pizza + "\n");

		pizza = pizzeriaBrest.commanderPizza("fruitsDeMer");
		System.out.println("Luc a commandé une  " + pizza + "\n");
 
		pizza = pizzeriaStrasbourg.commanderPizza("fruitsDeMer");
		System.out.println("Michel a commandé une " + pizza + "\n");

		pizza = pizzeriaBrest.commanderPizza("poivrons");
		System.out.println("Luc a commandé une " + pizza + "\n");
 
		pizza = pizzeriaStrasbourg.commanderPizza("poivrons");
		System.out.println("Michel a commandé une " + pizza + "\n");

		pizza = pizzeriaBrest.commanderPizza("vegetarienne");
		System.out.println("Luc a commandé une " + pizza + "\n");
 
		pizza = pizzeriaStrasbourg.commanderPizza("vegetarienne");
		System.out.println("Michel a commandé une " + pizza + "\n");
	}
}
