package tetepremiere.fabrique.pizzaaf;

public class FabriqueIngredientsPizzaStrasbourg 
	implements FabriqueIngredientsPizza 
{

	public Pate creerPate() {
		return new PateSoufflee();
	}

	public Sauce creerSauce() {
		return new SauceTomatesCerise();
	}

	public Fromage creerFromage() {
		return new Mozzarella();
	}

	public Legume[] creerLegumes() {
		Legume legumes[] = { new OlivesNoires(), 
		                      new Epinard(), 
		                      new Aubergine() };
		return legumes;
	}

	public Poivrons creerPoivrons() {
		return new PoivronsEnRondelles();
	}

	public Moules creerMoules() {
		return new MoulesSurgelees();
	}
}
