package tetepremiere.fabrique.pizzaaf;

public interface Pate {
	public String toString();
}
