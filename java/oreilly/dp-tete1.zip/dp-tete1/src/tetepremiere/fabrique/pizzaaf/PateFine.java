package tetepremiere.fabrique.pizzaaf;

public class PateFine implements Pate {
	public String toString() {
		return "Pâte fine";
	}
}
