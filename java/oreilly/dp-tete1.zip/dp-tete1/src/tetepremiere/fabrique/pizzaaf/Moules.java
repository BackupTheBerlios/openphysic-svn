package tetepremiere.fabrique.pizzaaf;

public interface Moules {
	public String toString();
}
