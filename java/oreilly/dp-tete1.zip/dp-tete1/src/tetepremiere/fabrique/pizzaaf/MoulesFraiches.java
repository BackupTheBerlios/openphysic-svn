package tetepremiere.fabrique.pizzaaf;

public class MoulesFraiches implements Moules {

	public String toString() {
		return "Moules fraiches";
	}
}
