package tetepremiere.fabrique.pizzaaf;

public class Aubergine implements Legume {

	public String toString() {
		return "Aubergine";
	}
}
