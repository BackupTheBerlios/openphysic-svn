package tetepremiere.fabrique.pizzaaf;

public interface Sauce {
	public String toString();
}
