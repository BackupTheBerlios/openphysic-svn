package tetepremiere.fabrique.pizzaaf;

public class Oignon implements Legume {

	public String toString() {
		return "Oignon";
	}
}
