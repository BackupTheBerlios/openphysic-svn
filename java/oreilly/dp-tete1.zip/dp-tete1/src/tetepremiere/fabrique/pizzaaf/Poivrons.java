package tetepremiere.fabrique.pizzaaf;

public interface Poivrons {
	public String toString();
}
