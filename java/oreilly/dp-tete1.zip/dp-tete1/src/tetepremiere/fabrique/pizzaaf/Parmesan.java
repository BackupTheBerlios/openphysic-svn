package tetepremiere.fabrique.pizzaaf;

public class Parmesan implements Fromage {

	public String toString() {
		return "Parmesan";
	}
}
