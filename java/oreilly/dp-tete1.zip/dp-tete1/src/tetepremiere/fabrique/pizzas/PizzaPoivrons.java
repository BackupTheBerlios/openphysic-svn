package tetepremiere.fabrique.pizzas;

public class PizzaPoivrons extends Pizza {
	public PizzaPoivrons() {
		nom = "Pizza aux poivrons";
		pate = "normale";
		sauce = "Sauce Marinara";
		garnitures.add("Poivrons rouges");
		garnitures.add("Oignons");
		garnitures.add("Parmesan");
	}
}
