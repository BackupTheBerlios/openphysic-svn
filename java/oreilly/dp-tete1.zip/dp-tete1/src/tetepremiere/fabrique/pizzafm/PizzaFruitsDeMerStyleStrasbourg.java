package tetepremiere.fabrique.pizzafm;

public class PizzaFruitsDeMerStyleStrasbourg extends Pizza {
	public PizzaFruitsDeMerStyleStrasbourg() {
		nom = "Pizza pâte style Strasbourg et fruits de mer";
		pate = "Extra épaisse";
		sauce = "Sauce aux tomates cerise";
 
		garnitures.add("Mozzarella");
		garnitures.add("Parmesan");
		garnitures.add("Moules");
	}
 
	void couper() {
		System.out.println("Découpage en parts carrées");
	}
}
