package tetepremiere.fabrique.pizzafm;

public class PizzaVegetarienneStyleStrasbourg extends Pizza {
	public PizzaVegetarienneStyleStrasbourg() {
		nom = "Pizza végétarienne pâte style Strasbourg";
		pate = "Extra épaisse";
		sauce = "Sauce aux tomates cerise";
		
		garnitures.add("Mozzarella");
		garnitures.add("Parmesan");
		garnitures.add("Aubergines");
		garnitures.add("Epinards");
		garnitures.add("Olives noires");
	}
 
	void couper() {
		System.out.println("Découpage en parts carrées");
	}
}
