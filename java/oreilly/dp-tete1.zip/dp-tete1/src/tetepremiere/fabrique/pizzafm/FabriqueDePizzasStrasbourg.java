package tetepremiere.fabrique.pizzafm;

public class FabriqueDePizzasStrasbourg extends Pizzeria {

	Pizza creerPizza(String item) {
		if (item.equals("fromage")) {
			return new PizzaFromageStyleStrasbourg();
		} else if (item.equals("vegetarienne")) {
			return new PizzaVegetarienneStyleStrasbourg();
		} else if (item.equals("fruitsDeMer")) {
			return new PizzaFruitsDeMerStyleStrasbourg();
		} else if (item.equals("poivrons")) {
			return new PizzaPoivronsStyleStrasbourg();
		} else
			return null;
	}
}
