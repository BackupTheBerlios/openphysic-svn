package tetepremiere.fabrique.pizzafm;

public class PizzaFromageStyleStrasbourg extends Pizza {

	public PizzaFromageStyleStrasbourg() { 
		nom = "Pizza pâte style Strasbourg et fromage";
		pate = "Extra épaisse";
		sauce = "Sauce aux tomates cerise";
 
		garnitures.add("Mozzarella");
		garnitures.add("Parmesan");
		garnitures.add("Origan");
	}
 
	void couper() {
		System.out.println("Découpage en parts carrées");
	}
}
