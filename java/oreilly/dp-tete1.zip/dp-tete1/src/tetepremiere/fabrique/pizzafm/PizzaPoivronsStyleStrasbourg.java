package tetepremiere.fabrique.pizzafm;

public class PizzaPoivronsStyleStrasbourg extends Pizza {
	public PizzaPoivronsStyleStrasbourg() {
		nom = "Pizza pâte style Strasbourg et poivrons";
		pate = "Extra épaisse";
		sauce = "Sauce aux tomates cerise";
 
		garnitures.add("Mozzarella");
		garnitures.add("Parmesan");
		garnitures.add("Aubergines");
		garnitures.add("Epinards");
		garnitures.add("Olives noires");
		garnitures.add("Poivrons");
	}
 
	void couper() {
		System.out.println("Découpage en parts carrées");
	}
}
