package tetepremiere.fabrique.pizzafm;

public class PizzaFruitsDeMerStyleBrest extends Pizza {

	public PizzaFruitsDeMerStyleBrest() {
		nom = "Pizza style Brest et fruits de mer";
		pate = "Pâte fine";
		sauce = "Sauce Marinara";
 
		garnitures.add("Reggiano");
		garnitures.add("Moules fraîches");
	}
}
