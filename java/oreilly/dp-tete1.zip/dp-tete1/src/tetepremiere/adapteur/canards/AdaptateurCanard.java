package tetepremiere.adapteur.canards;
import java.util.Random;

public class AdaptateurCanard implements Dindon {
	Canard canard;
	Random rand;
 
	public AdaptateurCanard(Canard canard) {
		this.canard = canard;
		rand = new Random();
	}
    
	public void glouglouter() {
		canard.cancaner();
	}
  
	public void voler() {
		if (rand.nextInt(5)  == 0) {
		     canard.voler();
		}
	}
}
