package tetepremiere.adapteur.canards;

public class Colvert implements Canard {
	public void cancaner() {
		System.out.println("Coincoin");
	}
 
	public void voler() {
		System.out.println("Je vole");
	}
}
