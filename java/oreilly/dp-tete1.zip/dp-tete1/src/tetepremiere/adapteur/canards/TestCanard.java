package tetepremiere.adapteur.canards;

public class TestCanard {
	public static void main(String[] args) {
		Colvert canard = new Colvert();
 
		DindonSauvage dindon = new DindonSauvage();
		Canard adaptateurDindon = new AdaptateurDindon(dindon);
   
		System.out.println("Dindon dit...");
		dindon.glouglouter();
		dindon.voler();
 
		System.out.println("\nCanard dit...");
		testerCanard(canard);
  
		System.out.println("\nAdaptateurDindon dit...");
		testerCanard(adaptateurDindon);
	}
 
	static void testerCanard(Canard canard) {
		canard.cancaner();
		canard.voler();
	}
}
