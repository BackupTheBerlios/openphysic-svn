package tetepremiere.adapteur.canards;

public class DindonSauvage implements Dindon {
	public void glouglouter() {
		System.out.println("Glouglou");
	}
 
	public void voler() {
		System.out.println("Je ne vole pas loin");
	}
}
