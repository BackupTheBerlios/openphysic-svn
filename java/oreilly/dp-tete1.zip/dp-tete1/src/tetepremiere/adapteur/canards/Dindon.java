package tetepremiere.adapteur.canards;

public interface Dindon {
	public void glouglouter();
	public void voler();
}
