package tetepremiere.adapteur.canards;

public interface Canard {
	public void cancaner();
	public void voler();
}
