package tetepremiere.adapteur.canards;

public class AdaptateurDindon implements Canard {
	Dindon dindon;
 
	public AdaptateurDindon(Dindon dindon) {
		this.dindon = dindon;
	}
    
	public void cancaner() {
		dindon.glouglouter();
	}
  
	public void voler() {
		for(int i=0; i < 5; i++) {
			dindon.voler();
		}
	}
}
