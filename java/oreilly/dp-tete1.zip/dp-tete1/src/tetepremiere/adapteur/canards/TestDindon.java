package tetepremiere.adapteur.canards;

public class TestDindon {
	public static void main(String[] args) {
		Colvert canard = new Colvert();
		Dindon adapatateurCanard = new AdaptateurCanard(canard);
 
		for(int i=0;i<10;i++) {
			System.out.println("AdaptateurCanard dit...");
			adapatateurCanard.glouglouter();
			adapatateurCanard.voler();
		}
	}
}
