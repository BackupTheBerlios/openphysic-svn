package tetepremiere.adapteur.iterenum;

import java.util.*;

public class TestIteratorEnumeration {
	public static void main (String args[]) {
		ArrayList l = new ArrayList(Arrays.asList(args));
		Enumeration enumeration = new EnumerationIterateur(l.iterator());
		while (enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
		}
	}
}
