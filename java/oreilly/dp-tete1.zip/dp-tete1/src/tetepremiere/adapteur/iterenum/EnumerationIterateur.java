package tetepremiere.adapteur.iterenum;

import java.util.*;

public class EnumerationIterateur implements Enumeration {
	Iterator iterator;
 
	public EnumerationIterateur(Iterator iterator) {
		this.iterator = iterator;
	}
 
	public boolean hasMoreElements() {
		return iterator.hasNext();
	}
 
	public Object nextElement() {
		return iterator.next();
	}
}
