package tetepremiere.adapteur.iterenum;

import java.util.*;

public class IterateurEnumeration implements Iterator {
	Enumeration enumeration;
 
	public IterateurEnumeration(Enumeration enumeration) {
		this.enumeration = enumeration;
	}
 
	public boolean hasNext() {
		return enumeration.hasMoreElements();
	}
 
	public Object next() {
		return enumeration.nextElement();
	}
 
	public void remove() {
		throw new UnsupportedOperationException();
	}
}
