package tetepremiere.adapteur.iterenum;

import java.util.*;

public class TestEnumerationIterator {
	public static void main (String args[]) {
		Vector v = new Vector(Arrays.asList(args));
		Iterator iterator = new IterateurEnumeration(v.elements());
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}
