//fichier : MonObservateur.java
import java.awt.*;
import java.awt.image.*;

class MonObservateur implements ImageObserver {

    public boolean imageUpdate( 
       Image image, int flags, int x, int y, int largeur, int hauteur) 
    {
	if ( (flags & HEIGHT) !=0 )
	    System.out.println("Hauteur de l'image = " + hauteur );
	if ( (flags & WIDTH ) !=0 )
	    System.out.println("Largeur de l'image = " + largeur );
	if ( (flags & FRAMEBITS) != 0 )
	    System.out.println("Fin d'une nouvelle image vid�o.");
	if ( (flags & SOMEBITS) != 0 )
	    System.out.println("Portion d'image :"
			       + new Rectangle( x, y, largeur, hauteur ) );
	if ( (flags & ALLBITS) != 0 )
	    System.out.println("Image charg�e !");
	if ( (flags & ABORT) != 0 ) 
	    System.out.println("Chargement interrompu...");
	return true;
    }
}
