//fichier : Hypnose.java
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.GeneralPath;
import javax.swing.*;

public class Hypnose extends JComponent implements Runnable {
  private int[] coordonn�es;
  private int[] deltas;
  private Paint paint;

  public Hypnose(int nombreDeSegments) {
    int nombreDeCoordonn�es = nombreDeSegments * 4 + 2;
    coordonn�es = new int[nombreDeCoordonn�es];
    deltas = new int[nombreDeCoordonn�es];
    for (int i = 0 ; i < nombreDeCoordonn�es; i++) {
      coordonn�es[i] = (int)(Math.random(  ) * 300);
      deltas[i] = (int)(Math.random(  ) * 4 + 3);
      if (deltas[i] > 4) deltas[i] = -(deltas[i] - 3);
    }
    paint = new GradientPaint(0, 0, Color.blue,
        20, 10, Color.red, true);

    Thread t = new Thread(this);
    t.start(  );
  }

  public void run(  ) {
    try {
      while (true) {
        �tapeSuivante(  );
        repaint(  );
        Thread.sleep(1000 / 24);
      }
    }
    catch (InterruptedException ie) {}
  }

  public void paint(Graphics g) {
    Graphics2D g2 = (Graphics2D)g;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
    Shape s = cr�eForme(  );
    g2.setPaint(paint);
    g2.fill(s);
    g2.setPaint(Color.white);
    g2.draw(s);
  }

  private void �tapeSuivante(  ) {
    Dimension d = getSize(  );
    if (d.width == 0 || d.height == 0) return;
    for (int i = 0; i < coordonn�es.length; i++) {
      coordonn�es[i] += deltas[i];
      int limit = (i % 2 == 0) ? d.width : d.height;
      if (coordonn�es[i] < 0) {
        coordonn�es[i] = 0;
        deltas[i] = -deltas[i];
      }
      else if (coordonn�es[i] > limit) {
        coordonn�es[i] = limit - 1;
        deltas[i] = -deltas[i];
      }
    }
  }

  private Shape cr�eForme(  ) {
    GeneralPath chemin = new GeneralPath(  );
    chemin.moveTo(coordonn�es[0], coordonn�es[1]);
    for (int i = 2; i < coordonn�es.length; i += 4)
      chemin.quadTo(coordonn�es[i], coordonn�es[i + 1],
          coordonn�es[i + 2], coordonn�es[i + 3]);
    chemin.closePath(  );
    return chemin;
  }

  public static void main(String[] args) {
    JFrame frame = new JFrame("Hypnose");
    frame.getContentPane().add( new Hypnose(4) );
    frame.setSize(300, 300);
	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setVisible(true);
  }
}
