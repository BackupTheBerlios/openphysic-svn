//fichier : PaletteDeCouleurs.java
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

public class PaletteDeCouleurs extends JComponent {
  BufferedImage image;

  public void initialize(  ) {
    int largeur = getSize().width;
    int hauteur = getSize().height;
    int[] donn�es = new int [largeur * hauteur];
    int i = 0;
    for (int y = 0; y < hauteur; y++) {
      int red = (y * 255) / (hauteur - 1);
      for (int x = 0; x < largeur; x++) {
        int green = (x * 255) / (largeur - 1);
        int blue = 128;
        donn�es[i++] = (red << 16) | (green << 8 ) | blue;
      }
    }
    image = new BufferedImage(largeur, hauteur,
        BufferedImage.TYPE_INT_RGB);
    image.setRGB(0, 0, largeur, hauteur, donn�es, 0, largeur);
  }

  public void paint(Graphics g) {
    if (image == null) 
        initialize();
    g.drawImage(image, 0, 0, this);
  }

  public void setBounds(int x, int y, int width, int height) {
	super.setBounds(x,y,width,height);
	initialize();
  }

  public static void main(String[] args) {
    JFrame frame = new JFrame("PaletteDeCouleurs");
    frame.getContentPane().add(new PaletteDeCouleurs(  ));
    frame.setSize(300, 300);
	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setVisible(true);
  }
}
