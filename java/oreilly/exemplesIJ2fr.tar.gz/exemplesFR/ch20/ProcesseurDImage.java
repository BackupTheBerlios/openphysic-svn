//fichier : ProcesseurDImage.java
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import javax.swing.*;

public class ProcesseurDImage extends JComponent {
  private BufferedImage source, destination;
  private JComboBox options;

  public ProcesseurDImage( BufferedImage image ) {
    source = destination = image;
    setBackground(Color.white);
    setLayout(new BorderLayout());
    // on cr�e un panel pour h�berger la combo
    JPanel controls = new JPanel();
    // Cr�ation de la combo contenant le nom des op�rateurs
    options = new JComboBox(
      new String[] { "[source]", "�claircir", "assombrir", 
		     "rotation", "redimensionner" } 
    );
    // On met en place le traitement sur changement de s�lection
    options.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent ie) {
        // On r�cup�re la s�lection dans la combo
        String option = (String)options.getSelectedItem();
        // On applique l'op�ration s�lectionn�e � l'image
        BufferedImageOp op = null;
        if (option.equals("[source]"))
          destination = source;
        else if (option.equals("�claircir"))
          op = new RescaleOp(1.5f, 0, null);
        else if (option.equals("assombrir"))
          op = new RescaleOp(.5f, 0, null);
        else if (option.equals("rotation"))
          op = new AffineTransformOp(
              AffineTransform.getRotateInstance(Math.PI / 6), null);
        else if (option.equals("redimensionner"))
          op = new AffineTransformOp(
              AffineTransform.getScaleInstance(.5, .5), null);
        if (op != null) destination = op.filter(source, null);
        repaint();
      }
    });
    controls.add(options);
    add(controls, BorderLayout.SOUTH);
  }

  public void paintComponent(Graphics g) {
    int largeurimage = destination.getWidth();
    int hauteurImage = destination.getHeight();
    int largeur = getSize().width;
    int hauteur = getSize().height;
    g.drawImage(destination,
        (largeur - largeurimage) / 2, (hauteur - hauteurImage) / 2, null);
  }

  public static void main(String[] args) {
    String filename = args[0];

	ImageIcon icon = new ImageIcon(filename);
	Image i = icon.getImage();

    // afficher l'image dans un composant BufferedImage
    int w = i.getWidth(null), h = i.getHeight(null);
    BufferedImage buffImage = new BufferedImage(w, h,
        BufferedImage.TYPE_INT_RGB);
    Graphics2D imageGraphics = buffImage.createGraphics();
    imageGraphics.drawImage(i, 0, 0, null);

    JFrame frame = new JFrame("ProcesseurDImage");
    frame.getContentPane().add(new ProcesseurDImage(buffImage));
    frame.setSize(buffImage.getWidth(), buffImage.getHeight());
	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setVisible(true);
  }
}
