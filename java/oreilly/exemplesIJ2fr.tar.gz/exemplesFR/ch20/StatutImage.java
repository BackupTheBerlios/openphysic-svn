//fichier : StatutImage.java
import java.awt.*;
import javax.swing.*;

public class StatutImage extends JComponent
{
  boolean charg� = false;
  String message = "Loading...";
  Image image;

  public StatutImage( Image image ) { this.image = image; }

  public void paint(Graphics g) {
    if (charg�) 
		g.drawImage(image, 0, 0, this);
    else {
      g.drawRect(0, 0, getSize().width - 1, getSize(  ).height - 1);
      g.drawString(message, 20, 20);
    }
  }
  public void charg�() {
	charg� = true;
	repaint();
  }
  public void setMessage( String msg ) {
	message = msg;
	repaint();
  }

  public static void main( String [] args ) { 
	JFrame frame = new JFrame("SuiviChargement");
    Image image = Toolkit.getDefaultToolkit().getImage( args[0] );
	StatutImage statusImage = new StatutImage( image );
	frame.getContentPane().add( statusImage );
	frame.setSize(300,300);
	frame.setVisible(true);

    MediaTracker pisteur = new MediaTracker( statusImage );
	int IMAGE_PRINCIPALE = 0;
    pisteur.addImage(image, IMAGE_PRINCIPALE);
    try { 
		pisteur.waitForID(IMAGE_PRINCIPALE); }
    catch (InterruptedException e) {}
    if ( pisteur.isErrorID(IMAGE_PRINCIPALE) ) 
		statusImage.setMessage("Erreur");
    else 
		statusImage.charg�();
  }
}
