//fichier : CryptURLConnection.java
class CryptURLConnection extends URLConnection {
    static int defaultPort = 80;
    CryptInputStream cis;

    public String getContentType(  ) {
        return guessContentTypeFromName( url.getFile(  ) );
    }

    CryptURLConnection ( URL url, String crypType )
      throws IOException {
        super( url );
        try {
            String classname = "learningjava.protocolhandlers.crypt."
                + crypType + "CryptInputStream";
            cis = (CryptInputStream)
                   Class.forName(classname).newInstance(  );
        } catch ( Exception e ) {
            throw new IOException("Classe Crypt introuvable: "+e);
        }
    }

    public void connect(  ) throws IOException {
        int port = ( url.getPort(  ) == -1 ) ?
                     defaultPort : url.getPort(  );
        Socket s = new Socket( url.getHost(  ), port );

        // Envoie le nom de fichier en texte pur
        OutputStream server = s.getOutputStream(  );
        new PrintWriter( new OutputStreamWriter( server, "8859_1" ),
                         true).println( "GET " + url.getFile(  ) );

        // Initialise CryptInputStream
        cis.set( s.getInputStream(  ), server );
        connected = true;
    }

    public InputStream getInputStream(  ) throws IOException {
        if (!connected)
            connect(  );
        return ( cis );
    }
}
