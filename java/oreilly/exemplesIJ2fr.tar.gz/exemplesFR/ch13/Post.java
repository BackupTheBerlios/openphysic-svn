//fichier : Post.java
import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Post extends JPanel implements ActionListener {
  JTextField champNom, champMotDePasse;
  String postURL;

  GridBagConstraints contraintes = new GridBagConstraints(  );
  void addGB( Component composant, int x, int y ) {
    contraintes.gridx = x;  contraintes.gridy = y;
    add ( composant, contraintes );
  }

  public Post( String postURL ) {
    this.postURL = postURL;
    JButton postBouton = new JButton("Poster");
    postBouton.addActionListener( this );
    setLayout( new GridBagLayout(  ) );
    addGB( new JLabel("Nom :"), 0,0 );
    addGB( champNom = new JTextField(20), 1,0 );
    addGB( new JLabel("Mot de passe :"), 0,1 );
    addGB( champMotDePasse = new JPasswordField(20),1,1 );
    contraintes.gridwidth = 2;
    addGB( postBouton, 0,2 );
  }

  public void actionPerformed(ActionEvent e) {
    postData(  );
  }

  protected void postData(  ) {
    StringBuffer sb = new StringBuffer(  );
    sb.append( URLEncoder.encode("Name") + "=" );
    sb.append( URLEncoder.encode(champNom.getText(  )) );
    sb.append( "&" + URLEncoder.encode("Password") + "=" );
    sb.append( URLEncoder.encode(champMotDePasse.getText(  )) );
    String formData = sb.toString(  );

    try {
      URL url = new URL( postURL );
      HttpURLConnection urlcon =
          (HttpURLConnection) url.openConnection(  );
      urlcon.setRequestMethod("POST");
      urlcon.setRequestProperty("Content-type",
          "application/x-www-form-urlencoded");
      urlcon.setDoOutput(true);
      urlcon.setDoInput(true);
      PrintWriter pout = new PrintWriter( new OutputStreamWriter(
          urlcon.getOutputStream(  ), "8859_1"), true );
      pout.print( formData );
      pout.flush(  );

      // lit le r�sultat...
      if ( urlcon.getResponseCode(  ) != HttpURLConnection.HTTP_OK )
        System.out.println("Postage OK !");
      else {
        System.out.println("Mauvais postage...");
        return;
      }
      //InputStream in = urlcon.getInputStream(  );
      // ...

    } catch (MalformedURLException e) {
      System.out.println(e);     // Mauvais postURL
    } catch (IOException e2) {
      System.out.println(e2);    // Erreur d'E/S
    }
  }

  public static void main( String [] args ) {
    JFrame frame = new JFrame("SimplePost");
    frame.getContentPane(  ).add( new Post( args[0] ), "Center" );
    frame.pack(  );
    frame.setVisible(true);
  }
}
