//fichier : Invoke.java
import java.lang.reflect.*;

class Invoke {
  public static void main( String [] args ) {
    try {
      Class c = Class.forName( args[0] );
      Method m = c.getMethod( args[1], new Class [] { } );
      Object ret =  m.invoke( null, null );
      System.out.println(
          "M�thode statique invoqu�e : " + args[1]
          + " de la classe : " + args[0]
          + " sans args\nResults: " + ret );
    } catch ( ClassNotFoundException e ) {
      // Class.forName() ne trouve pas la classe
    } catch ( NoSuchMethodException e2 ) {
      // cette m�thode n'existe pas
    } catch ( IllegalAccessException e3 ) {
     // nous n'avons pas le droit d'invoquer cette m�thode
    } catch ( InvocationTargetException e4 ) {
      // une exception a �t� lev�e pendant 
     // que nous invoquions cette m�thode
      System.out.println(
          "La m�thode a lev� une :  " + e4.getTargetException(  ) );
    }
  }
}
