public class Animal extends SimpleElement { 
    public final static int MAMMIFERE = 1;
    int animalClasse;
    String nom, espece, habitat, nourriture, caractere;
    RegimeAlimentaire regimeAlimentaire;
    
    public void setNom( String nom ) { this.nom = nom ; }
    public String getNom() { return nom; }
    public void setEspece( String espece ) { this.espece = espece ; }
    public String getEspece() { return espece; }
    public void setHabitat( String habitat ) { this.habitat = habitat ; }
    public String getHabitat() { return habitat; }
    public void setNourriture( String nourriture ) { this.nourriture = nourriture ; }
    public String getNourriture() { return nourriture; }
    public void setRegimeAlimentaire( RegimeAlimentaire regime ) { this.regimeAlimentaire = regime; }
    public RegimeAlimentaire getRegimeAlimentaire() { return regimeAlimentaire; }
    public void setCaractere( String caractere ) { 
	this.caractere = caractere ; }
    public String getCaractere() { return caractere; }
    
    public void setAnimalClasse( int animalClasse ) { 
		this.animalClasse = animalClasse; }
    public int getAnimalClasse() { return animalClasse; }
    public void setAttributeValue( String nom, String value ) { 
	if ( nom.equals("classe") && value.equals("mammif�re") )
	    setAnimalClasse( MAMMIFERE );
	else
	    throw new Error("Attribut invalide : "+nom);
    }
    public String toString() { return nom +"("+espece+")"; }
}
