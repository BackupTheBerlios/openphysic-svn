import org.xml.sax.*;
import org.xml.sax.helpers.*;
import java.util.*;
import java.lang.reflect.*;

public class SAXModelBuilder extends DefaultHandler
{
    Stack stack = new Stack();
    SimpleElement element;

    public void startElement(
        String namespace, String localname, String qname, Attributes atts ) 
	throws SAXException
    {
	SimpleElement element = null;
        try {
            element = (SimpleElement)Class.forName(qname).newInstance();
        } catch ( Exception e ) {/* Pas de classe */}
        if ( element == null ) 
	    element = new SimpleElement();
	for(int i=0; i<atts.getLength(); i++)
	    element.setAttributeValue( atts.getQName(i), atts.getValue(i) );
        stack.push( element );
    }
    public void endElement( String namespace, String localname, String qname ) 
	throws SAXException
    {
	element = (SimpleElement)stack.pop();
	if ( !stack.empty() )
	    try {
		setProperty( qname, stack.peek(), element );
	    } catch ( Exception e ) { throw new SAXException( "Erreur : "+e ); }
	}
	public void characters(char[] ch, int start, int len ) {
		String text = new String( ch, start, len );
		((SimpleElement)(stack.peek())).setText( text );
	}

    void setProperty( String name, Object target, Object value ) 
		throws SAXException 
	{
		Method method = null;
		try { 
			method = target.getClass().getMethod( 
				"add"+name, new Class[] { value.getClass() } );
		} catch ( NoSuchMethodException e ) { }
		if ( method == null ) try { 
			method = target.getClass().getMethod( 
				"set"+name, new Class[] { value.getClass() } );
		} catch ( NoSuchMethodException e ) { }
		if ( method == null ) try { 
			value = ((SimpleElement)value).getText();
			method = target.getClass().getMethod( 
				"add"+name, new Class[] { String.class } );
		} catch ( NoSuchMethodException e ) { }
		try {
			if ( method == null )
				method = target.getClass().getMethod( 
					"set"+name, new Class[] { String.class } );
			method.invoke( target, new Object [] { value } );
		} catch ( Exception e ) { throw new SAXException( e.toString() ); }
	}
	public SimpleElement getModel() { return element; }
}

