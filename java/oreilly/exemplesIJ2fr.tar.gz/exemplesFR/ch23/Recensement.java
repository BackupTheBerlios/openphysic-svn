import java.util.*;

public class Recensement extends SimpleElement {
	List animaux = new ArrayList();
	public void addAnimal( Animal animal ) { animaux.add( animal ); }
	public List getAnimaux() { return animaux; }
	public void setAnimaux( List animaux ) { this.animaux = animaux; }
}
