import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import java.util.*;

public class TestJDOM {
    public static void main( String[] args ) throws Exception {
	Document doc = new SAXBuilder().build("recensementzoo.xml");
	List animaux = doc.getRootElement().getChildren("Animal");
	System.out.println("Animaux = ");
	for( int i=0; i<animaux.size(); i++ ) {
	    String name = ((Element)animaux.get(i)).getChildText("Nom");
	    String espece = ((Element)animaux.get(i)).getChildText("Espece");
	    System.out.println( "  "+ name +" ("+espece+")" );
	}
	Element regimeAlimentaire = ((Element)animaux.get(1)).getChild("RegimeAlimentaire");
	String name = regimeAlimentaire.getChildText("Nom");
	System.out.println("Nourriture = " + name );
	List ingredients = regimeAlimentaire.getChildren("Ingredient");
	for(int i=0; i<ingredients.size(); i++) 
	    System.out.println( "  "+((Element)ingredients.get(i)).getText() );
    }
}
