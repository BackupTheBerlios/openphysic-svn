import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;

public class Test {
}
