
public class SimpleElement {
	String text;
	public void setText( String text ) { this.text = text; }
	public String getText() { return text; }
	public void setAttributeValue( String name, String value ) { 
		throw new Error( getClass()+": Attributs interdits");
	}
}
