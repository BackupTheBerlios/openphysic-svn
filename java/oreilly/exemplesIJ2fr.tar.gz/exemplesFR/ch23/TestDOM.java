import javax.xml.parsers.*;
import org.xml.sax.InputSource;
import org.w3c.dom.*;

public class TestDOM
{
    public static void main( String [] args ) throws Exception
    {
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	DocumentBuilder parser = factory.newDocumentBuilder();
	Document document = parser.parse( new InputSource("recensementzoo.xml") );
	Element inventory = document.getDocumentElement();
	NodeList animaux = inventory.getElementsByTagName("Animal");

		System.out.println("Animaux = ");
		for( int i=0; i<animaux.getLength(); i++ ) {
			String nom = DOMUtil.getSimpleElementText( 
				(Element)animaux.item(i),"Nom" );
			String espece = DOMUtil.getSimpleElementText( 
				(Element)animaux.item(i), "Espece" );
			System.out.println( "  "+ nom +" ("+espece+")" );
		}

		Element regimeAlimentaire = DOMUtil.getFirstElement( 
			(Element)animaux.item(1), "RegimeAlimentaire" );
		String nom = DOMUtil.getSimpleElementText( regimeAlimentaire, "Nom" );
		System.out.println("Nourriture = " + nom );
		NodeList ingredients = regimeAlimentaire.getElementsByTagName("Ingredient");
		for(int i=0; i<ingredients.getLength(); i++) 
			System.out.println( 
				"  "+ingredients.item(i).getFirstChild().getNodeValue() );
	}
}

