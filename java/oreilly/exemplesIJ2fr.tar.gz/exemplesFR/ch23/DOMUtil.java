import org.w3c.dom.*;

public class DOMUtil
{
    public static Element getFirstElement( Element element, String nom ) {
	NodeList nl = element.getElementsByTagName( nom );
	if ( nl.getLength() < 1 )
	    throw new RuntimeException(
             "L'�l�ment : "+element+" ne contient pas : "+nom);
	return (Element)nl.item(0);
    }

    public static String getSimpleElementText( Element noeud, String nom ) 
	{
	    Element nameEl = getFirstElement( noeud, nom );
	    Node textNode = nameEl.getFirstChild();
	    if ( textNode instanceof Text )
		return textNode.getNodeValue();
	    else
		throw new RuntimeException(nom+" n'est pas un noeud texte: ");
	}
}

