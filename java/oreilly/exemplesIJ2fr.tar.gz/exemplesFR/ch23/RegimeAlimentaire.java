import java.util.*;
public class RegimeAlimentaire extends SimpleElement {
	String nom;
	List ingredients = new ArrayList();
	public void setNom( String nom ) { this.nom = nom ; }
	public String getNom() { return nom; }
	public void addIngredient( String ingredient ) { 
		ingredients.add( ingredient ); }
	public void setIngredients( List ingredients ) { 
		this.ingredients = ingredients; }
	public List getIngredients() { return ingredients; }
	public String toString() { return nom + ": "+ ingredients.toString(); }
}
