import java.io.*;
import java.nio.*;
import java.nio.channels.*;

public class CopieFichier3 {
	public static void main( String [] args ) throws Exception
	{
		String fichierSource = args[0];
		String fichierDest = args[1];
		FileChannel in = new FileInputStream( fichierSource ).getChannel();
		FileChannel out = new FileOutputStream( fichierDest ).getChannel();
		in.transferTo( 0, (int)in.size(), out );
		in.close();
		out.close();
	}
}
