import java.io.*;

public class CopieStream {
	public static void main( String [] args ) throws Exception
	{
		String fichierSource = args[0];
		String fichierDest = args[1];
		BufferedInputStream in = new BufferedInputStream(
			new FileInputStream( fichierSource ) );
		BufferedOutputStream out = new BufferedOutputStream(
			new FileOutputStream( fichierDest ) );
		byte [] buff = new byte [ 32*1024 ];
		int len;
		while ( (len = in.read( buff )) > 0 )
			out.write( buff, 0, len );
		in.close();
		out.close();
	}
}
