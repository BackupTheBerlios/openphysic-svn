//fichier : ListIt.java
import java.io.*;

class ListIt {
    public static void main ( String args[] ) throws Exception {
        File fichier =  new File( args[0] );

        if ( !fichier.exists() || !fichier.canRead(  ) ) {
            System.out.println( "Impossible de lire " + fichier );
            return;
        }

        if ( fichier.isDirectory(  ) ) {
            String [] fichiers = fichier.list(  );
            for (int i=0; i< fichiers.length; i++)
                System.out.println( fichiers[i] );
        }
        else
            try {
                FileReader fr = new FileReader ( fichier );
                BufferedReader in = new BufferedReader( fr );
                String line;
                while ((line = in.readLine(  )) != null)
                System.out.println(line);
            }
            catch ( FileNotFoundException e ) {
                System.out.println( "Le fichier a disparu !" );
            }
    }
}
