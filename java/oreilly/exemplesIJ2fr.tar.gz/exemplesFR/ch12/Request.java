//fichier : Request.java
public class Request implements java.io.Serializable {}
