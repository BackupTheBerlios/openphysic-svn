//fichier : MyServer.java
import java.rmi.*;
import java.util.*;

public class MyServer
    extends java.rmi.server.UnicastRemoteObject
    implements ServerRemote {

    public MyServer(  ) throws RemoteException { }

    // impl�mentation de l'interface ServerRemote
    public Date getDate(  ) throws RemoteException {
        return new Date(  );
    }

    public Object execute( WorkRequest work )
      throws RemoteException {
        return work.execute(  );
    }

    public static void main(String args[]) {
        try {
            ServerRemote server = new MyServer(  );
            Naming.rebind("NiftyServer", serveur);
        } catch (java.io.IOException e) {
            // probl�me d'enregistrement du serveur
        }
    }
}
