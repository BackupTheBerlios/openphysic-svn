//fichier : MyCalculation.java
public class MyCalculation extends WorkRequest {
    int n;

    public MyCalculation( int n ) {
        this.n = n;
    }
    public Object execute(  ) {
        return new Integer( n * n );
    }
}
