//fichier : BattementCoeur.java
import java.net.*;
import java.io.*;

public class BattementCoeur extends java.applet.Applet {
    String maMachine;
    int num�roPort;

    public void init(  ) {
        maMachine = getCodeBase().getHost(  );
        num�roPort = Integer.parseInt( getParameter("num�roPort") );
    }

    private void sendMessage( String message ) {
        try {
            byte [] donn�es = message.getBytes(  );
            InetAddress addr = InetAddress.getByName( maMachine );
            DatagramPacket pack =
              new DatagramPacket(donn�es, donn�es.length, addr, num�roPort );
            DatagramSocket ds = new DatagramSocket(  );
            ds.send( pack );
            ds.close(  );
        } catch ( IOException e ) {
            System.out.println( e );  // Erreur de cr�ation de socket
        }
    }

    public void start(  ) {
        sendMessage("Arriv�e");
    }
    public void stop(  ) {
        sendMessage("D�part");
    }
}
