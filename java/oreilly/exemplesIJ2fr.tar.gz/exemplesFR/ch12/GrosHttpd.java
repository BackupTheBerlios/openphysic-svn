import java.io.*;
import java.util.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.nio.charset.*;
import java.util.regex.*;

public class GrosHttpd {
	Selector selectionneurClient;
	FileDAttenteClient clientsPrets = new FileDAttenteClient();

	public void run( int port, int threads ) throws IOException {
		selectionneurClient = Selector.open();
		ServerSocketChannel ssc = ServerSocketChannel.open();
		ssc.configureBlocking(false);
		InetSocketAddress sa = 
			new InetSocketAddress( InetAddress.getLocalHost(), port );
		ssc.socket().bind( sa );
		ssc.register( selectionneurClient, SelectionKey.OP_ACCEPT );
	
		for (int i=0; i<threads; i++) // Cr�ation du groupe de threads
			new Thread() { public void run() { 
				while (true) try { gereClient(); } catch (IOException e ) { } 
			} }.start();

		while ( true ) try { // boucle de s�lection principale
			while ( selectionneurClient.select(50) == 0 );
			Set grpDispo = selectionneurClient.selectedKeys();
			for( Iterator it = grpDispo.iterator(); it.hasNext(); ) {
				SelectionKey key = (SelectionKey)it.next();
				it.remove();
				if ( key.isAcceptable() ) 
					accepteClient( ssc );
				else {
					key.interestOps( 0 );
					clientsPrets.add( key );
				}
			}
		} catch ( IOException e ) { System.out.println(e); }
	}

	void accepteClient( ServerSocketChannel ssc ) throws IOException {
		SocketChannel clientSocket = ssc.accept();
		clientSocket.configureBlocking(false);
		SelectionKey key = 
		    clientSocket.register( selectionneurClient, SelectionKey.OP_READ );
		ConnexionHttpd client = new ConnexionHttpd( clientSocket );
		key.attach( client );
	}

	void gereClient() throws IOException {
		SelectionKey key = (SelectionKey)clientsPrets.next();
		ConnexionHttpd client = (ConnexionHttpd)key.attachment();
		if ( key.isReadable() )
			client.read( key );
		else 
			client.write( key );
	}

	public static void main( String argv[] ) throws IOException {
		new GrosHttpd().run( Integer.parseInt(argv[0]), 3 );
	}
}

class ConnexionHttpd {
	static Charset charset = Charset.forName("8859_1");
	static Pattern httpGetPattern = Pattern.compile("(?s)GET /?(\\S*).*");
	SocketChannel clientSocket;
	ByteBuffer tampon = ByteBuffer.allocateDirect( 64*1024 );
	String requete;
	String reponse;
	FileChannel fichier;
	int positionFichier;

	ConnexionHttpd ( SocketChannel clientSocket ) {
		this.clientSocket = clientSocket;
	}

	void read( SelectionKey key ) throws IOException {
		if ( requete == null && (clientSocket.read( tampon ) == -1 
				|| tampon.get( tampon.position()-1 ) == '\n' ) )
			traiteRequete( key );
		else
			key.interestOps( SelectionKey.OP_READ );
	}

	void traiteRequete( SelectionKey key ) {
		tampon.flip();
		requete = charset.decode( tampon ).toString();
		Matcher get = httpGetPattern.matcher( requete );
		if ( get.matches() ) {
			requete = get.group(1);
			if ( requete.endsWith("/") || requete.equals("") )
				requete = requete + "index.html";
			//System.out.println( "Requ�te : "+requete);
			try {
				fichier = new FileInputStream ( requete ).getChannel();
			} catch ( FileNotFoundException e ) {
				reponse = "404 Object Not Found";
			}
		} else
			reponse = "400 Bad Request" ;

		if ( reponse != null ) {
			tampon.clear();
			charset.newEncoder().encode( 
				CharBuffer.wrap( reponse ), tampon, true );
			tampon.flip();
		}
		key.interestOps( SelectionKey.OP_WRITE );
	}

	void write( SelectionKey key ) throws IOException {
		if ( reponse != null ) {
			clientSocket.write( tampon );
			if ( tampon.remaining() == 0 ) 
				reponse = null;
		} else if ( fichier != null ) {
			int restant = (int)fichier.size()-positionFichier;
			long recu = fichier.transferTo( positionFichier, restant, clientSocket );
			if ( recu == -1 || restant <= 0 ) {
				fichier.close();
				fichier = null;
			} else
				positionFichier += recu;
		} 
		if ( reponse == null && fichier == null ) {
			clientSocket.close();
			key.cancel();		
		} else 
			key.interestOps( SelectionKey.OP_WRITE );
	}
}

class FileDAttenteClient extends ArrayList {
	synchronized void add( SelectionKey key ) { 
		super.add(key); 
		notify();
	}
	synchronized SelectionKey next() {
		while ( isEmpty() )
			try { wait(); } catch ( InterruptedException e ) { }
		return (SelectionKey)remove(0);
	}
}
