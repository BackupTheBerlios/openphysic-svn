//fichier PetitHttpd.java
import java.net.*;
import java.io.*;
import java.util.regex.*;

public class PetitHttpd {
  public static void main( String argv[] ) throws IOException {
    ServerSocket ss =
        new ServerSocket( Integer.parseInt(argv[0]) );
    while ( true )
      new Thread( new PetitHttpdConnexion( ss.accept() ) ).start();
  }
}

class PetitHttpdConnexion implements Runnable {
  Socket client;
  PetitHttpdConnexion ( Socket client ) throws SocketException {
    this.client = client;
  }
  public void run() {
    try {
      BufferedReader in = new BufferedReader(
        new InputStreamReader(client.getInputStream(), "8859_1" ) );
      OutputStream out = client.getOutputStream();
      PrintWriter pout = new PrintWriter(
        new OutputStreamWriter(out, "8859_1"), true );
      String requ�te = in.readLine();
      System.out.println( "Requ�te : "+requ�te);

	  Matcher get = Pattern.compile("GET /?(\\S*).*").matcher( requ�te );
	  if ( get.matches() ) {
		requ�te = get.group(1);
        if ( requ�te.endsWith("/") || requ�te.equals("") )
          requ�te = requ�te + "index.html";
        try {
          FileInputStream fis = new FileInputStream ( requ�te );
          byte [] data = new byte [ 64*1024 ];
		  for(int read; (read = fis.read( data )) > -1; )
			  out.write( data, 0, read );
          out.flush();
        } catch ( FileNotFoundException e ) {
          pout.println( "404 Object Not Found" ); }
      } else
        pout.println( "400 Bad Request" );
      client.close();
    } catch ( IOException e ) {
      System.out.println( "Erreur E/S " + e ); }
  }
}
