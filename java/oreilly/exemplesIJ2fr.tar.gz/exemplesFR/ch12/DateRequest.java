//fichier : DateRequest.java
public class DateRequest extends Request {}
