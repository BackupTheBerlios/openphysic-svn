//fichier : Borders.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class Borders {
  public static void main(String[] args) {
    // Cr�ation d'un JFrame contenant tout l'ensemble
    JFrame frame = new JFrame("Bordures");

    // Cr�ation de labels avec bordures
    int center = SwingConstants.CENTER;
    JLabel labelOne = new JLabel("BevelBorder en relief", center);
    labelOne.setBorder(
        BorderFactory.createBevelBorder(BevelBorder.RAISED));
    JLabel labelTwo = new JLabel("EtchedBorder", center);
    labelTwo.setBorder(BorderFactory.createEtchedBorder(  ));
    JLabel labelThree = new JLabel("MatteBorder", center);
    labelThree.setBorder(
        BorderFactory.createMatteBorder(10, 10, 10, 10, Color.pink));
    JLabel labelFour = new JLabel("TitledBorder", center);
    Border etch = BorderFactory.createEtchedBorder(  );
    labelFour.setBorder(
        BorderFactory.createTitledBorder(etch, "Titre"));
    JLabel labelFive = new JLabel("TitledBorder", center);
    Border low = BorderFactory.createLoweredBevelBorder(  );
    labelFive.setBorder(
        BorderFactory.createTitledBorder(low, "Titre",
        TitledBorder.RIGHT, TitledBorder.BOTTOM));
    JLabel labelSix = new JLabel("CompoundBorder", center);
    Border one = BorderFactory.createEtchedBorder(  );
    Border two =
        BorderFactory.createMatteBorder(4, 4, 4, 4, Color.blue);
    labelSix.setBorder(BorderFactory.createCompoundBorder(one, two));

    // ajout des composants au panneau de contenu
    Container c = f.getContentPane(  );
    c.setLayout(new GridLayout(3, 2));
    c.add(labelOne);
    c.add(labelTwo);
    c.add(labelThree);
    c.add(labelFour);
    c.add(labelFive);
    c.add(labelSix);

	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	frame.pack();
    frame.setVisible(true);
  }
}
