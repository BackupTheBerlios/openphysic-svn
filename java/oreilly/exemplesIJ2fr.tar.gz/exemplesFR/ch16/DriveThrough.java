//file: DriveThrough.java
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class DriveThrough 
{
  public static void main(String[] args) {
    JFrame frame = new JFrame("Lister v1.0");

    JPanel entreePanel = new JPanel(  );
    final ButtonGroup entreeGroup = new ButtonGroup(  );
    JRadioButton radioButton;
    entreePanel.add(radioButton = new JRadioButton("Boeuf"));
    radioButton.setActionCommand("Beef");
    entreeGroup.add(radioButton);
    entreePanel.add(radioButton = new JRadioButton("Poulet"));
    radioButton.setActionCommand("Chicken");
    entreeGroup.add(radioButton);
    entreePanel.add(radioButton = new JRadioButton("L�gumes", true));
    radioButton.setActionCommand("Veggie");
    entreeGroup.add(radioButton);

    final JPanel condimentsPanel = new JPanel(  );
    condimentsPanel.add(new JCheckBox("Ketchup"));
    condimentsPanel.add(new JCheckBox("Moutarde"));
    condimentsPanel.add(new JCheckBox("Vinaigrette"));

    JPanel orderPanel = new JPanel(  );
    JButton orderButton = new JButton("Commander");
    orderPanel.add(orderButton);

    Container content = frame.getContentPane(  );
    content.setLayout(new GridLayout(3, 1));
    content.add(entreePanel);
    content.add(condimentsPanel);
    content.add(orderPanel);

    orderButton.addActionListener(new ActionListener(  ) {
      public void actionPerformed(ActionEvent ae) {
        String entree =
          entreeGroup.getSelection().getActionCommand(  );
        System.out.println("Sandwich " + entree);
        Component[] components = condimentsPanel.getComponents(  );
        for (int i = 0; i < components.length; i++) {
          JCheckBox cb = (JCheckBox)components[i];
          if (cb.isSelected(  ))
            System.out.println("Avec " + cb.getText(  ));
        }
      }
    });

	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
