//fichier : TabbedPaneFrame.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class TabbedPaneFrame {
  public static void main(String[] args) 
  {
    JFrame frame = new JFrame("TabbedPaneFrame");
    JTabbedPane tabby = new JTabbedPane();

    // Cr�ation du panneau de contr�le
    JPanel controls = new JPanel(  );
    controls.add(new JLabel("Service:"));
    JList list = new JList(
        new String[] { "Serveur Web", "Serveur FTP" });
    list.setBorder(BorderFactory.createEtchedBorder(  ));
    controls.add(list);
    controls.add(new JButton("Lancer"));

    // Cr�ation d'un panneau d'image
    String filename = "Piazza di Spagna.jpg";
	JLabel image = new JLabel( new ImageIcon(filename) );
    JComponent picture = new JScrollPane(image);
    tabby.addTab("Contr�les", controls);
    tabby.addTab("Image", picture);

    frame.getContentPane().add(tabby);

    frame.setSize(200, 200);
	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setVisible(true);
  }
}
