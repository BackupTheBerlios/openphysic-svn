//fichier : Lister.java
import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;

public class Lister {
  public static void main(String[] args) {
    JFrame frame = new JFrame("Lister v1.0");
    
    // cr�ation d'une bo�te combo
    String [] items = { "uno", "due", "tre", "quattro", "cinque",
                        "sei", "sette", "otto", "nove", "deici",
                        "undici", "dodici" };
    JComboBox comboBox = new JComboBox(items);
    comboBox.setEditable(true);

    // cr�ation d'une liste avec le m�me mod�le de donn�es
    final JList list = new JList(comboBox.getModel( ));
    
    // cr�ation d'un bouton ; quand il est press�, affichage
    // de la s�lection dans la liste
    JButton button = new JButton("Per favore");
    button.addActionListener(new ActionListener( ) {
      public void actionPerformed(ActionEvent ae) {
        Object[] selection = list.getSelectedValues( );
        System.out.println("-----");
        for (int i = 0; i < selection.length; i++)
          System.out.println(selection[i]);
      }
    });
    
    // Ajout de contr�les au contenu
    Container c = frame.getContentPane();
    JPanel comboPanel = new JPanel();
    comboPanel.add(comboBox);
    c.add(comboPanel, BorderLayout.NORTH);
    c.add(new JScrollPane(list), BorderLayout.CENTER);
    c.add(button, BorderLayout.SOUTH);

    frame.setSize(200, 200);
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setVisible(true);
  }    
}

