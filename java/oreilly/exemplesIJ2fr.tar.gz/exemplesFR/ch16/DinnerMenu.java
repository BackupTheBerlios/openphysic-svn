//fichier : DinnerMenu.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DinnerMenu 
{
  public static void main(String[] args) {
    JFrame frame = new JFrame("Menu");

    // Cr�ation des ustensiles
    JMenu utensils = new JMenu("Utensils");
    utensils.setMnemonic(KeyEvent.VK_U);
    utensils.add(new JMenuItem("Fourchette"));
    utensils.add(new JMenuItem("Couteau"));
    utensils.add(new JMenuItem("Cuiller"));
    JMenu hybrid = new JMenu("Hybride");
    hybrid.add(new JMenuItem("Cuichette"));
    hybrid.add(new JMenuItem("Cuiteau"));
    hybrid.add(new JMenuItem("Courchette"));
    utensils.add(hybrid);
    utensils.addSeparator(  );

    // Configuration de l'�l�ment Quitter
    JMenuItem quitItem = new JMenuItem("Quitter");
    quitItem.setMnemonic(KeyEvent.VK_Q);
    quitItem.setAccelerator(
        KeyStroke.getKeyStroke(KeyEvent.VK_Q, Event.CTRL_MASK));
    quitItem.addActionListener(new ActionListener(  ) {
      public void actionPerformed(ActionEvent e) { System.exit(0); }
    });
    utensils.add(quitItem);

    // Cr�ation du menu �pices
    JMenu spices = new JMenu("�pices");
    spices.setMnemonic(KeyEvent.VK_S);
    spices.add(new JCheckBoxMenuItem("Thym"));
    spices.add(new JCheckBoxMenuItem("Romarin"));
    spices.add(new JCheckBoxMenuItem("Origan", true));
    spices.add(new JCheckBoxMenuItem("Fenouil"));

    // Cr�ation du menu Fromages
    JMenu cheese = new JMenu("Fromages");
    cheese.setMnemonic(KeyEvent.VK_C);
    ButtonGroup group = new ButtonGroup(  );
    JRadioButtonMenuItem rbmi;
    rbmi = new JRadioButtonMenuItem("Normal", true);
    group.add(rbmi);
    cheese.add(rbmi);
    rbmi = new JRadioButtonMenuItem("Extra");
    group.add(rbmi);
    cheese.add(rbmi);
    rbmi = new JRadioButtonMenuItem("Bleu");
    group.add(rbmi);
    cheese.add(rbmi);

    // Cr�ation d'une barre de menu pour utilisation dans ce JFrame
    JMenuBar menuBar = new JMenuBar(  );
    menuBar.add(utensils);
    menuBar.add(spices);
    menuBar.add(cheese);
    frame.setJMenuBar(menuBar);

	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	frame.setSize(200,200);
    frame.setVisible(true);
  }
}
