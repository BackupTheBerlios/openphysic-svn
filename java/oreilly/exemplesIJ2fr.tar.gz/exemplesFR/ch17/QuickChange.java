//fichier : QuickChange.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class QuickChange extends JFrame {

  public QuickChange() {
    super("QuickChange v1.0");
    createGUI();
  }

  protected void createGUI(  ) {
    setSize(300, 200);

    // Cr�ation d'un simple menu Fichier
    JMenu file = new JMenu("Fichier", true);
    JMenuItem quit = new JMenuItem("Quitter");
    file.add(quit);
    quit.addActionListener(new ActionListener(  ) {
      public void actionPerformed(ActionEvent e) { System.exit(0); }
    });

    // Cr�ation du menu Look & Feel
    JMenu lnf = new JMenu("Look & Feel", true);
    ButtonGroup buttonGroup = new ButtonGroup(  );
    final UIManager.LookAndFeelInfo[] info =
        UIManager.getInstalledLookAndFeels(  );
    for (int i = 0; i < info.length; i++) {
      JRadioButtonMenuItem item = new
          JRadioButtonMenuItem(info[i].getName(  ), i == 0);
      final String className = info[i].getClassName(  );
      item.addActionListener(new ActionListener(  ) {
        public void actionPerformed(ActionEvent ae) {
          try { UIManager.setLookAndFeel(className); }
          catch (Exception e) { System.out.println(e); }
          SwingUtilities.updateComponentTreeUI(QuickChange.this);
        }
      });
      buttonGroup.add(item);
      lnf.add(item);
    }

    // ajout de la barre de menu
    JMenuBar mb = new JMenuBar(  );
    mb.add(file);
    mb.add(lnf);
    setJMenuBar(mb);

    // ajout de quelques composants
    JPanel jp = new JPanel(  );
    jp.add(new JCheckBox("JCheckBox"));
    String[] names =
      new String[] { "Tosca", "Cavaradossi", "Scarpia",
                     "Angelotti", "Spoletta", "Sciarrone",
                     "Carceriere", "Il sagrestano", "Un pastore" };
    jp.add(new JComboBox(names));
    jp.add(new JButton("JButton"));
    jp.add(new JLabel("JLabel"));
    jp.add(new JTextField("JTextField"));
    JPanel main = new JPanel(new GridLayout(1, 2));
    main.add(jp);
    main.add(new JScrollPane(new JList(names)));
    setContentPane(main);
	setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }

  public static void main(String[] args) {
    new QuickChange().setVisible(true);
  }
}
