import java.util.*;
import java.util.regex.*;

public class Template 
{
	Properties values = new Properties();
	Pattern templateComment = 
		Pattern.compile("(?si)<!--\\s*TEMPLATE:(\\w+).*?-->");

	public void set( String nom, String valeur ) {
		values.setProperty( nom, valeur );
	}

	public String fillIn( String texte ) {
		Matcher matcher = templateComment.matcher( texte );

		StringBuffer buffer = new StringBuffer();
		while( matcher.find() ) {
			String nom = matcher.group(1);
			String valeur = values.getProperty( nom );
			matcher.appendReplacement( buffer, valeur );
		}
		matcher.appendTail( buffer );
		return buffer.toString();
	}

	public static void main( String	[] args	) 
	{
		String templateText = 
			"<html><head>\n"+
			"<body>\n"+
			"Un peu de texte.\n"+
			"<!-- TEMPLATE:toto  -->\n"+
			"Encore du texte.\n"+
			"\n"+
			"<!--template:titi C'est du texte -->\n"+
			"Plus de texte.\n"+
			"<!-- TEMPLATE:titi \n"+
			"-->\n"+
			"</body></html>\n";
			
		Template template = new Template();
		template.set( "toto", "Template toto");
		template.set( "titi", "Template titi");
		System.out.println( templateText );
		System.out.println( template.fillIn(templateText) );
	}

}


