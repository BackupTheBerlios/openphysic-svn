//fichier: Flow.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Flow extends JPanel {

  public Flow() {
    // FlowLayout est le gestionnaire de placement par d�faut d'un JPanel
    add(new JButton("Un"));
    add(new JButton("Deux"));
    add(new JButton("Trois"));
    add(new JButton("Quatre"));
    add(new JButton("Cinq"));
  }

  public static	void main(String[] args) {
    JFrame frame = new JFrame("Flot");
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

    frame.setSize(400, 75);
    frame.setLocation(200, 200);
    Flow flow =	new Flow();
    frame.setContentPane(flow);
    frame.setVisible(true);
  }
}
