//fichier: Border1.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Border1 extends JPanel {

  public Border1() {
    setLayout(new BorderLayout(	));
    add(new JButton("Nord"), BorderLayout.NORTH);
    add(new JButton("Sud"), BorderLayout.SOUTH);
    add(new JButton("Est"), BorderLayout.EAST);
    add(new JButton("Ouest"), BorderLayout.WEST);
    add(new JButton("Centre"), BorderLayout.CENTER);
  }

  public static	void main(String[] args) {
    JFrame frame = new JFrame("Border1");
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setSize(300, 300);
    frame.setLocation(200, 200);
    frame.setContentPane(new Border1());
    frame.setVisible(true);
  }
}
