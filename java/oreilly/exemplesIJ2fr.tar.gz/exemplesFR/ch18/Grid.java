//fichier: Grid.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Grid extends JPanel {

  public Grid() {
    setLayout(new GridLayout(3,	2));
    add(new JButton("Un"));
    add(new JButton("Deux"));
    add(new JButton("Trois"));
    add(new JButton("Quatre"));
    add(new JButton("Cinq"));
  }

  public static	void main(String[] args) {
    JFrame frame = new JFrame("Grille");
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setSize(200, 200);
    frame.setLocation(200, 200);
    frame.setContentPane(new Grid());
    frame.setVisible(true);
  }
}
