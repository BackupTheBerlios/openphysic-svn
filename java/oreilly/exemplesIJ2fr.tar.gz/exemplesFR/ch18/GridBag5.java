//fichier : GridBag5.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GridBag5 extends JPanel {
  GridBagConstraints constraints = new GridBagConstraints();

  public GridBag5() {
    setLayout(new GridBagLayout());
    int	x, y;  // pour des raisons de clart�
    addGB(new JButton("Nord"),	 x = 1,	y = 0);
    constraints.ipadx =	25;  //	ajout d'un remplissage
    constraints.ipady =	25;
    addGB(new JButton("Ouest"),	 x = 0,	y = 1);
    constraints.ipadx =	0;   //	suppression du remplissage
    constraints.ipady =	0;
    addGB(new JButton("Centre"), x = 1,	y = 1);
    addGB(new JButton("Est"),	 x = 2,	y = 1);
    addGB(new JButton("Sud"),	 x = 1,	y = 2);
  }

  void addGB(Component component, int x, int y)	{
    constraints.gridx =	x;
    constraints.gridy =	y;
    add(component, constraints);
  }

  public static	void main(String[] args) {
    JFrame frame = new JFrame("GridBag5");
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

    frame.setSize(250, 250);
    frame.setLocation(200, 200);
    frame.setContentPane(new GridBag5());
    frame.setVisible(true);
  }
}
