//fichier: Card.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Card extends JPanel {
  CardLayout cards = new CardLayout();

  public Card() {
    setLayout(cards);
    ActionListener listener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	cards.next(Card.this);
      }
    };
    JButton button;
    button = new JButton("un");
    button.addActionListener(listener);
    add(button,	"un");
    button = new JButton("deux");
    button.addActionListener(listener);
    add(button,	"deux");
    button = new JButton("trois");
    button.addActionListener(listener);
    add(button,	"trois");
  }

  public static	void main(String[] args) {
    JFrame frame = new JFrame("Carte");
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setSize(200, 200);
    frame.setLocation(200, 200);
    frame.setContentPane(new Card());
    frame.setVisible(true);
  }
}
