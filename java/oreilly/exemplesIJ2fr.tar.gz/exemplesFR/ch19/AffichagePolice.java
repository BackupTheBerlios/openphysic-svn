//fichier : AffichagePolice.java
import java.awt.*;
import java.awt.event.*;
import java.awt.font.*;
import javax.swing.*;

public class AffichagePolice extends JComponent 
{
  private static final int PAD = 25;   // espacement entre les lignes
  private boolean grossePolice = true;
  private String message;

  public AffichagePolice(String message) {
    this.message = message;
    addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        grossePolice = !grossePolice;
        repaint();
      }
    });
  }

  public void paint(Graphics g) 
  {
    Graphics2D g2 = (Graphics2D)g;

    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);

    int size = grossePolice ? 96 : 64;
    Font font = new Font("Dialog", Font.PLAIN, size);
    g2.setFont(font);
    int width = getSize().width;
    int height = getSize().height;

    FontRenderContext frc = g2.getFontRenderContext();
    LineMetrics metrics = font.getLineMetrics(message, frc);
    float messageWidth =
        (float)font.getStringBounds(message, frc).getWidth();

    // centre le texte
    float ascent = metrics.getAscent();
    float descent = metrics.getDescent();
    float x = (width - messageWidth) / 2;
    float y = (height + metrics.getHeight()) / 2 - descent;

    g2.setPaint(getBackground());
    g2.fillRect(0, 0, width, height);

    g2.setPaint(getForeground());
    g2.drawString(message, x, y);

    g2.setPaint(Color.white);  // Lignes de base
    drawLine(g2, x - PAD, y, x + messageWidth + PAD, y);
    drawLine(g2, x, y + PAD, x, y - ascent - PAD);
    g2.setPaint(Color.green);  // Ligne d'ascendante
    drawLine(g2, x - PAD, y - ascent,
             x + messageWidth + PAD, y - ascent);
    g2.setPaint(Color.red);    // Ligne de descendante
    drawLine(g2, x - PAD, y + descent,
             x + messageWidth + PAD, y + descent);
  }

  private void drawLine(Graphics2D g2,
      double x0, double y0, double x1, double y1) {
    Shape line = new java.awt.geom.Line2D.Double(x0, y0, x1, y1);
    g2.draw(line);
  }

  public static void main(String args[]) {
    String message = "Lemming";
    if (args.length > 0) message = args[0];

    JFrame frame = new JFrame("AffichagePolice");
    frame.setSize(420, 300);
	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.getContentPane().add(new AffichagePolice(message));
    frame.setVisible(true);
  }
}
