import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DeplacerImage extends JComponent 
	implements MouseMotionListener 
{
  static int largeurImage=60, hauteurImage=60;
  int grille = 10;
  int imageX, imageY;
  Image image;

  public DeplacerImage(Image i) {
    image = i;
    addMouseMotionListener(this);
  }

  public void mouseDragged(MouseEvent e) {
    imageX = e.getX();
    imageY = e.getY();
    repaint();
  }

  public void mouseMoved(MouseEvent e) {}

  public void paint(Graphics g) {
    Graphics2D g2 = (Graphics2D)g;

    int w = getSize().width / grille;
    int h = getSize().height / grille;
    boolean black = false;
    for (int y = 0; y <= grille; y++)
      for (int x = 0; x <= grille; x++) {
        g2.setPaint(black ? Color.black : Color.white);
        black = !black;
        g2.fillRect(x * w, y * h, w, h);
      }
    g2.drawImage(image, imageX, imageY, this);
  }

  public static void main(String[] args) {
    String fichierImage = "L1-Light.jpg";
    if (args.length > 0)
      fichierImage = args[0];

    // D�sactivation du double buffering
    //RepaintManager.currentManager(null).setDoubleBufferingEnabled(false);

    Image image = Toolkit.getDefaultToolkit().getImage(
        DeplacerImage.class.getResource(fichierImage));
	image = image.getScaledInstance(largeurImage,hauteurImage,Image.SCALE_DEFAULT);
    JFrame frame = new JFrame("DeplacerImage");
    frame.getContentPane().add( new DeplacerImage(image) );
    frame.setSize(300, 300);
	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setVisible(true);
  }
}
