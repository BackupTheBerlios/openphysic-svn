//fichier : MessageBoard.java
import java.util.*;

public class MessageBoard extends Observable {
    private String message;

    public String getMessage(  ) {
        return message;
    }
    public void changeMessage( String message ) {
        this.message = message;
        setChanged(  );
        notifyObservers( message );
    }
    public static void main( String [] args ) {
        MessageBoard board = new MessageBoard(  );
        Student bob = new Student(  );
        Student joe = new Student(  );
        board.addObserver( bob );
        board.addObserver( joe );
        board.changeMessage("Travaillez plus � la maison !");
    }
} // fin de la classe MessageBoard

class Student implements Observer {
    public void update(Observable o, Object arg) {
        System.out.println( "Le tableau des messages � chang� : " + arg );
    }
}
