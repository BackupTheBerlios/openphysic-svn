//fichier : WordSort.java
import java.io.*;
import java.util.*;

public class WordSort {
  public static void main(String[] args) throws IOException {
    // Lit les arguments sur la ligne de commande
    if (args.length < 2) {
      System.out.println("Utilisation : 
                          WordSort fichierEntr�e fichierSortie");
      return;
    }
    String inputfile = args[0];
    String outputfile = args[1];


/* Cr�e la carte des mots. Chaque cl� est un mot et chaque valeur un
 * Integer qui repr�sente le nombre de fois qu'un mot appara�t dans le
 * fichier d'entr�e.
 */

    Map map = new TreeMap(  );

    // lit chaque ligne du fichier d'entr�e
    BufferedReader in =
        new BufferedReader(new FileReader(inputfile));
    String line;

    while ((line = in.readLine(  )) != null) {
      // examine chaque mot de la ligne
      StringTokenizer st = new StringTokenizer(line);
      while (st.hasMoreTokens(  )) {
        String word = st.nextToken(  );
        Object o = map.get(word);
        // si aucune entr�e n'existe pour ce mot, on en ajoute une
        if (o == null) map.put(word, new Integer(1));
        // sinon, on incr�mente le compteur pour ce mot
        else {
          Integer count = (Integer)o;
          map.put(word, new Integer(count.intValue(  ) + 1));
        }
      }
    }
    in.close(  );

    // R�cup�re les cl�s de la carte
    List keys = new ArrayList(map.keySet(  ));
    //Collections.sort(keys);

    // �crit le r�sultat dans le fichier de sortie
    PrintWriter out = new PrintWriter(new FileWriter(outputfile));
    Iterator iterator = keys.iterator(  );
    while (iterator.hasNext(  )) {
      Object key = iterator.next(  );
      out.println(key + " : " + map.get(key));
    }
    out.close(  );
  }
}
