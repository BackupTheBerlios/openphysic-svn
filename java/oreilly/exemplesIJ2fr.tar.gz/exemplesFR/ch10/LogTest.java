
import java.util.logging.*;

public class TestConsignation {
    public static void main(String argv[]) {
        Logger logger = Logger.getLogger("com.oreilly.TestConsignation");

        logger.severe("Coupure de courant - passage sur onduleur !");
        logger.warning("Perte de connexion � la base de donn�es, 
                        tentative de reconnexion en cours...");
        logger.info("D�marrage effectu�.");
        logger.config("Configuration serveur: isol�, MVJ version 1.4");
        logger.fine("Chargement du paquetage graphique.");
        logger.finer("Dessin de l'histogramme");
        logger.finest("D�marrage tri � bulles: valeur ="+42);
    }
}

