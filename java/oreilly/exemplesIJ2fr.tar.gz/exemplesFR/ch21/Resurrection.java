//fichier : Resurrection.java
import java.awt.Component;
import javax.swing.*; 
import java.beans.*; 
 
public class Resurrection extends JFrame
{ 
    public Resurrection( String name ) 
    { 
	super("Le retour des beans !"); 
	try { 
	    Object bean = Beans.instantiate(  
			getClass().getClassLoader( ), name ); 

	    if ( Beans.isInstanceOf(bean, Component.class) ) { 
		Component comp = (Component)
		    Beans.getInstanceOf(bean, Component.class); 
		getContentPane( ).add("Center", comp); 
	    } else {
		System.out.println("Le bean n'est pas un Component..."); 
	    }
	} catch ( java.io.IOException e1 ) { 
	    System.out.println("Erreur lors du chargement de l'objet s�rialis�");
	} catch ( ClassNotFoundException e2 ) { 
	    System.out.println(
                "Impossible de trouver la classe apparent�e � cet objet");
		} 
	 } 
 
	public static void main(String [] args) { 
		JFrame frame = new Resurrection( args[0] );
		frame.pack( );
		frame.setVisible(true);
	} 
}

