//fichier: DynamicHookup.java
import javax.swing.*;
import java.awt.event.*;
import java.beans.EventHandler;

public class DynamicHookup extends JFrame {
  JLabel label = new JLabel( "Pr�t...", JLabel.CENTER );
  int count;

  public DynamicHookup() {
    JButton launchButton = new JButton("Feu !");
    getContentPane().add( launchButton, "South" );
    getContentPane().add( label, "Center" );
	launchButton.addActionListener( 
		(ActionListener)EventHandler.create(
			ActionListener.class, this, "lancementDesMissiles"));
  }

  public void LancementDesMissiles() {
    label.setText("Lanc� : "+ count++ );
  }

  public static void main(String[] args) {
    JFrame frame = new DynamicHookup();
	frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setSize(150, 150);
    frame.setVisible( true );
  }
}
