import javax.swing.*;
import java.awt.event.*;

public class AfficheApplet extends JApplet {
	JTextArea text = new JTextArea();
	int startCount;

	public void init() 
	{
		JButton button = new JButton("Pressez-moi");
		button.addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e ) {
				text.append("Bouton Press� !\n"); 
			}
		} );
		getContentPane().add( "Center", new JScrollPane( text ) );
		JPanel panel = new JPanel();
		panel.add( button );
		getContentPane().add( "South", panel );
		text.append( "Version de Java : "+System.getProperty("java.version")+"\n" );
		text.append( "Applet init()\n" );
	}
	public void start() {
		text.append( "Applet d�marr�e : "+ startCount++ +"\n" );
	}
	public void stop() {
		text.append( "Applet arr�t�e.\n" );
	}
}

