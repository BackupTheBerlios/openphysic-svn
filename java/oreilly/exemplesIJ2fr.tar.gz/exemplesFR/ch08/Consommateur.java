//fichier : Consommateur.java
import java.util.Vector;

public class Consommateur implements Runnable 
{
    Producteur producteur;

    Consommateur( Producteur producteur ) {
        this.producteur = producteur;
    }

    public void run() {
        while ( true ) {
            String message = producteur.recupereMessage();
            System.out.println("Message re�u : " + message);
			try { 
				Thread.sleep( 2000 ); 
			} catch ( InterruptedException e ) { }
        }
    }

    public static void main(String args[]) {
        Producteur producteur = new Producteur();
        new Thread( producteur ).start();
        Consommateur consommateur = new Consommateur( producteur );
        new Thread( consommateur ).start();
    }
}
