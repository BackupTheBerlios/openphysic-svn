//fichier : RafraichirApplet.java
public class RafraichirApplet extends java.applet.Applet
    implements Runnable {

    private Thread rafraichirThread;
    int intervalRafraichi = 1000;

    public void run(  ) {
        while ( rafraichirThread != null ) {
            try {
                Thread.sleep( intervalRafraichi );
            }
            catch (InterruptedException e ) {
                return;
            }
            repaint(  );
        }
    }

    public void start(  ) {
        if ( rafraichirThread == null ) {
            rafraichirThread = new Thread(this);
            rafraichirThread.start(  );
        }
    }

    public void stop(  ) {
        if ( rafraichirThread != null ) {
            Thread messager = rafraichiThread;
            rafraichirThread = null;  // drapeau pour quitter
            messager.interrupt(  );   // r�veill� si endormi
        }
    }
}
