public class Thready {
    public static void main( String args [] ) {
        new AfficherThread("Zorglub").start(  );
        new AfficherThread("Truc").start(  );
    }

	static class AfficherThread extends Thread {
		String message;

		AfficherThread( String message ) {
			this.message = message;
		}
		public void run(  ) {
			while ( true )
				System.out.println( message );
		}
	}
}
