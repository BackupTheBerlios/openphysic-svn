//fichier : ConsommateurNomme.java

public class ConsommateurNomme implements Runnable 
{
    Producteur producteur;
    String name;

    ConsommateurNomme(String name, Producteur producteur) {
        this.producteur = producteur;
        this.nom = nom;
    }

    public void run() {
        while ( true ) {
            String message = producteur.recupererMessage();
            System.out.println(nom + " message re�u: " + message);
			try { 
				Thread.sleep( 2000 ); 
			} catch ( InterruptedException e ) { }
        }
    }

    public static void main(String args[]) {
        Producteur producteur = new Producteur();
        new Thread( producteur ).start();

        ConsommateurNomme consommateur = new ConsommateurNomme( "Un", producteur );
        new Thread( consommateur ).start();
        consumer = new ConsommateurNomme( "Deux", producteur );
        new Thread( consommateur ).start();
    }
}
