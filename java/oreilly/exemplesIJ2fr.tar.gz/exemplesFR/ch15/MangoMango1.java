//fichier : MangoMango1.java
import java.awt.*;
import javax.swing.*;

public class MangoMango1 {
  public static void main(String[] args) {
    JFrame f = new JFrame("frame");
    f.setLocation(100, 100);

    Container content = f.getContentPane(  );
    content.setLayout(new FlowLayout(  ));
    content.add(new JLabel("Mango"));
    content.add(new JButton("Mango"));

    f.pack(  );
    f.setVisible(true);
  }
}
