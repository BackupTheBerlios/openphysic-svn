//fichier : MangoMango2.java
import java.awt.*;
import javax.swing.*;

public class MangoMango2 {
  public static void main(String[] args) {
    JFrame f = new JFrame("frame");
    f.setLocation(100, 100);

    Container content = new JPanel(  );
    content.add(new JLabel("Mango"));
    content.add(new JButton("Mango"));
    f.setContentPane(content);

    f.pack(  );
    f.setVisible(true);
  }
}
