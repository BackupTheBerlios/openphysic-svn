//fichier : Caddie.java
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.util.Enumeration;

public class Caddie extends HttpServlet {
    String [] articles = new String [] {
        "Grillons enrob�s de chocolat", "Cafards � la framboise",
        "Papillons cr�meux", "Chicklets(tm) au poulet" };

    public void doPost( 
		HttpServletRequest request, HttpServletResponse response) 
		throws IOException, ServletException 
	{
        doGet( request, response );
    }

    public void doGet( 
		HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException 
	{
        response.setContentType("text/html");
        PrintWriter out = response.getWriter(  );

        // get or create the session information
        HttpSession session = request.getSession(  );
        int [] achats = (int [])session.getAttribute("achats");
        if ( achats == null ) {
            achats = new int [ articles.length ];
            session.setAttribute( "achats", achats );
        }

        out.println( "<html><head><title>Caddie</title>"
                     + "</title></head><body><p>" );

        if ( request.getParameter("valider") != null )
            out.println("<h1>Votre commande a �t� enregistr�e !</h1>");
        else  {
            if ( request.getParameter("ajouter") != null ) {
                ajouterAchats( request, achats );
                out.println(
                    "<h1>Achat ajout�. Vous pouvez continuer</h1>");
            } else {
                if ( request.getParameter("vider") != null )
                    for (int i=0; i<achats.length; i++)
                         achats[i] = 0;
                out.println("<h1>S�lectionnez vos articles !</h1>");
            }
            doForm( out, request.getRequestURI(  ) );
        }
        afficherAchats( out, achats );
        out.close(  );
    }

    void ajouterAchats( HttpServletRequest request, int [] achats ) {
        for (int i=0; i<articles.length; i++) {
            String added = request.getParameter( articles[i] );
            if ( added !=null && !added.equals("") )
                achats[i] += Integer.parseInt( added );
        }
    }

    void doForm( PrintWriter out, String requestURI ) {
        out.println( "<form method=POST action="+ requestURI +">" );

        for(int i=0; i< articles.length; i++)
            out.println( "Quantit� <input name=\"" + articles[i]
              + "\" value=0 size=3> of: " + articles[i] + "<br>");
        out.println(
          "<p><input type=submit name=ajouter value=\"Ajouter\">"
          + "<input type=submit name=valider value=\"Valider\">"
          + "<input type=submit name=vider value=\"Vider\">"
          + "</form>" );
    }

    void afficherAchats( PrintWriter out, int [] achats )
        throws IOException {

        out.println("<hr><h2>Votre panier</h2>");
        for (int i=0; i<articles.length; i++)
            if ( achats[i] != 0 )
                out.println( achats[i] +"  "+ articles[i] +"<br>" );
    }
}
