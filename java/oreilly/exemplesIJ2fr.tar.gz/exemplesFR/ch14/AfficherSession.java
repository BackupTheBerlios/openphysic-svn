//fichier : AfficherSession.java
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.util.Enumeration;

public class AfficherSession extends HttpServlet {

    public void doPost( 
		HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException
	{ 
        doGet( request, response );
    }

    public void doGet(
		HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException 
	{
        HttpSession session = request.getSession(  );
        boolean clear = request.getParameter("clear") != null;
		if ( clear )
			session.invalidate();
		else {
			String name = request.getParameter("Nom");
			String value = request.getParameter("Valeur");
			if ( name != null && value != null )
				session.setAttribute( name, value );
		}

        response.setContentType("text/html");
        PrintWriter out = response.getWriter(  );
        out.println(
          "<html><head><title>Afficher session</title></head><body>");

		if ( clear )
        	out.println("<h1>Session supprim�e :</h1>");
		else {
			out.println("<h1>Dans cette session :</h1><ul>");
			Enumeration names = session.getAttributeNames();
			while ( names.hasMoreElements() ) {
				String name = (String)names.nextElement();
				out.println( "<li>"+name+" = " +session.getAttribute( name ) );
			}
		}

        out.println(
          "</ul><p><hr><h1>Add String</h1>"
          + "<form method=\"POST\" action=\""
          + request.getRequestURI(  ) +"\">"
          + "Nom : <input name=\"name\" size=20><br>"
          + "Valeur : <input name=\"value\" size=20><br>"
          + "<br><input type=\"submit\" value=\"Submit\">"
          + "<input type=\"submit\" name=\"clear\" value=\"Clear\"></form>"
        );
    }
}
