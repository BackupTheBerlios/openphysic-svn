Ce fichier a été téléchargé depuis
http://www.phpcs.com/code.aspx?ID=28089
Retrouvez d'autres CodeS-SourceS sur http://www.phpcs.com/

Vous cherchez une source ? Une aide en programmation ?
VBFrance          : http://www.vbfrance.com/
ASMFr.com         : http://www.asmfr.com/
ASPFr.com         : http://www.aspfr.com/
CFMFrance         : http://www.cfmfrance.com/
CPPFrance.com     : http://www.cppfrance.com/
CSharpFR.com      : http://www.cppfrance.com/
DelphiFr.com      : http://www.delphifr.com/
FlashKoD.com      : http://www.flashkod.com/
GraphFR.com       : http://www.GraphFR.com/
IRCFr.com         : http://www.ircfr.com/
PHPCS.com         : http://www.phpcs.com/
JavaFR.com        : http://www.javafr.com/
JavascriptFR.com  : http://www.javascriptfr.com/
CodeS-SourceS.com : http://www.codes-sources.com/

