# Copyright (C) 1998-06  Stephane Galland <galland@arakhne.org>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA.

=pod

=head1 NAME

Bib2HTML::Generator::Lang::Italian - Italian support for the generators

=head1 SYNOPSYS

use Bib2HTML::Generator::Lang::Italian ;

my $gen = Bib2HTML::Generator::Lang::Italian->new() ;

=head1 DESCRIPTION

Bib2HTML::Generator::Lang::Italian is a Perl module, which proposes
a Italian support for all the generators.

=head1 GETTING STARTED

=head2 Initialization

To start a generator script, say something like this:

    use Bib2HTML::Generator::Lang::Italian;

    my $gen = Bib2HTML::Generator::Lang::Italian->new() ;

...or something similar.

=head1 METHOD DESCRIPTIONS

This section contains only the methods in Italian.pm itself.

=over

=cut

package Bib2HTML::Generator::Lang::Italian;

@ISA = ('Bib2HTML::Generator::Lang');
@EXPORT = qw();
@EXPORT_OK = qw();

use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK $VERSION);
use Exporter;

use Carp ;

use Bib2HTML::Generator::Lang ;
use Bib2HTML::General::Error ;

#------------------------------------------------------
#
# Global vars
#
#------------------------------------------------------

# Version number of language support
my $VERSION = "2.0" ;

# Language definitions
my %LANG_DEFS = (
		 'I18N_LANG_ALL_ELEMENTS' => "Tutti i documenti",
		 'I18N_LANG_ARTICLESINSAMEDOMAINS' => "Documenti negli stessi domini",
		 'I18N_LANG_BIB2HTML_COPYRIGHT' => ( "Documento generato da #1.<BR>\n".
						     "Copyright &copy; 1998-05 #2 (sotto la #3)" ),
		 'I18N_LANG_FIELD_BIBTEX_VERBATIM' => "Codice BibTeX",
		 'I18N_LANG_FIELD_XML_VERBATIM' => "Codice XML",
		 'I18N_LANG_DEFAULT_TITLE' => "Bibliografia",
		 'I18N_LANG_DOMAIN_TREE' => "Albero dei domini",
		 'I18N_LANG_DOMAINS' => "Domini",
		 'I18N_LANG_ENTRY_TYPE_TREE' => "Elenco gerarchico per tipo di documento",
		 'I18N_LANG_FIELD_ADDRESS' => "Indirizzo",
		 'I18N_LANG_FIELD_ADSURL' => "Collegamento al ADS",
		 'I18N_LANG_FIELD_ABSTRACT' => "Abstract",
		 'I18N_LANG_FIELD_ABSTRACT_KEYWORDS' => "Abstract &amp; Parole chiave",
		 'I18N_LANG_FIELD_ANNOTATION' => "Annotazione",
		 'I18N_LANG_FIELD_AUTHORS' => "Autore",
		 'I18N_LANG_FIELD_CHAPTER' => "Capitolo di",
		 'I18N_LANG_FIELD_DATE' => "Data",
		 'I18N_LANG_FIELD_DOWNLOAD' => "Scarica articolo completo: #1",
		 'I18N_LANG_FIELD_EDITION' => "Edizione",
		 'I18N_LANG_FIELD_EDITORS' => "Curatore",
		 'I18N_LANG_FIELD_HOWPUBLISHED' => "Modalit� di pubblicazione",
		 'I18N_LANG_FIELD_IN' => "In",
		 'I18N_LANG_FIELD_INSTITUTION' => "Istituzione",
		 'I18N_LANG_FIELD_ISBN' => "Numero ISBN",
		 'I18N_LANG_FIELD_ISSN' => "Numero ISSN",
		 'I18N_LANG_FIELD_JOURNAL' => "Rivista",
		 'I18N_LANG_FIELD_KEYWORDS' => "<strong>Parole chiave</strong>: #1",
		 'I18N_LANG_FIELD_KEYWORDS_TITLE' => "Parole chiave",
		 'I18N_LANG_FIELD_NOTE' => "Nota",
		 'I18N_LANG_FIELD_NUMBER' => "Numero",
		 'I18N_LANG_FIELD_ORGANIZATION' => "Organizzazione",
		 'I18N_LANG_FIELD_PAGES' => "Pagine",
		 'I18N_LANG_FIELD_PDFFILE' => "PDF",
		 'I18N_LANG_FIELD_PUBLISHER' => "Editore",
		 'I18N_LANG_FIELD_READERS' => "Lettori",
		 'I18N_LANG_FIELD_SCHOOL' => "Scuola",
		 'I18N_LANG_FIELD_SERIES' => "Serie",
		 'I18N_LANG_FIELD_TITLE' => "Titolo",
		 'I18N_LANG_FIELD_TYPE' => "Tipo",
		 'I18N_LANG_FIELD_URL' => "URL",
		 'I18N_LANG_FIELD_VOLUME' => "Volume",
		 'I18N_LANG_FIELD_YEAR' => "Anno",
		 'I18N_LANG_FORMAT_NAME' => "l{ (v)}{ f.}{, j}",
		 'I18N_LANG_FORMAT_NAMES' => "{ e }{, }",
		 'I18N_LANG_FRAME_TITLE_AUTHORS' => "Autori",
		 'I18N_LANG_FRAME_TITLE_TYPES' => "Tipi",
		 'I18N_LANG_FRAMES' => "Frame",
		 'I18N_LANG_INDEX' => "Indice",
		 'I18N_LANG_INDEX_COMMENT_ARTICLE' => "Articolo",
		 'I18N_LANG_INDEX_COMMENT_AUTHOR' => "Autore",
		 'I18N_LANG_INDEX_COMMENT_BOOKTITLE' => "Titolo",
		 'I18N_LANG_INDEX_COMMENT_EDITOR' => "Curatore",
		 'I18N_LANG_INDEX_COMMENT_HOWPUBLISHED' => "Modalit� di pubblicazione",
		 'I18N_LANG_INDEX_COMMENT_INSTITUTION' => "Istituzione",
		 'I18N_LANG_INDEX_COMMENT_PUBLISHER' => "Editore",
		 'I18N_LANG_INDEX_COMMENT_SCHOOL' => "Scuola",
		 'I18N_LANG_INDEX_COMMENT_TITLE' => "Titolo",
		 'I18N_LANG_NEXT' => "Successivo",
		 'I18N_LANG_NO_DATE' => "Non datati",
		 'I18N_LANG_NO_FRAME' => "Pagina unica",
		 'I18N_LANG_NO_FRAME_ALERT' => ( "<H2>Attenzione</H2>\n".
						 "<P>Questo documento � destinato ad ".
						 "essere visualizzato usando i frame. ".
						 "Se visualizzate questo messaggio ".
						 "state utilizzando un client che non ".
						 "supporta i frame.<BR>\n".
						 "Si veda la <A HREF=\"#1\">".
						 "Versione senza frame.</A>.<BR>\n#2" ),
		 'I18N_LANG_OVERVIEW' => "Per anno",
		 'I18N_LANG_P_ARTICLE' => "Articoli",
		 'I18N_LANG_P_BOOK' => "Libri",
		 'I18N_LANG_P_BOOKLET' => "Libretti",
		 'I18N_LANG_P_INBOOK' => "Parte di libro",
		 'I18N_LANG_P_INCOLLECTION' => "In raccolte",
		 'I18N_LANG_P_INPROCEEDINGS' => "In atti",
		 'I18N_LANG_P_MANUAL' => "Manuali tecnici",
		 'I18N_LANG_P_MASTERTHESIS' => "Tesi di master",
		 'I18N_LANG_P_MISC' => 'Documenti vari',
		 'I18N_LANG_P_PHDTHESIS' => "Tesi di dottorato",
		 'I18N_LANG_P_PROCEEDINGS' => "Atti di conferenze",
		 'I18N_LANG_P_TECHREPORT' => "Rapporti tecnici",
		 'I18N_LANG_P_UNPUBLISHED' => "Non pubblicati",
		 'I18N_LANG_PREV' => "Precedente",
		 'I18N_LANG_TREE' => "Per tipo",
		 'I18N_LANG_S_ARTICLE' => "articolo",
		 'I18N_LANG_S_BOOK' => "libro",
		 'I18N_LANG_S_BOOKLET' => "libretto",
		 'I18N_LANG_S_INBOOK' => "parte di libro",
		 'I18N_LANG_S_INCOLLECTION' => "parte di una raccolta",
		 'I18N_LANG_S_INPROCEEDINGS' => "parte di atti",
		 'I18N_LANG_S_MANUAL' => "manuale tecnico",
		 'I18N_LANG_S_MASTERTHESIS' => "tesi di master",
		 'I18N_LANG_S_MISC' => 'documenti vari',
		 'I18N_LANG_S_PHDTHESIS' => "tesi di dottorato",
		 'I18N_LANG_S_PROCEEDINGS' => "atti di conferenze",
		 'I18N_LANG_S_TECHREPORT' => "rapporto tecnico",
		 'I18N_LANG_S_UNPUBLISHED' => "non pubblicato",
		 'I18N_LANG_SMALL_IN' => "in:&nbsp;#1",
		 'I18N_LANG_SUBMIT_BUG' => "Segnalazione bug",
		) ;

#------------------------------------------------------
#
# Constructor
#
#------------------------------------------------------

sub new($$) : method {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = $class->SUPER::new("Italian",\%LANG_DEFS) ;
  bless( $self, $class );
  return $self;
}

1;
__END__

=back

=head1 COPYRIGHT

(c) Copyright 1998-06 St�phane Galland <galland@arakhne.org>, under GPL.

=head1 AUTHORS

=over

=item *

Conceived and initially developed by St�phane Galland E<lt>galland@arakhne.orgE<gt>.
Italian translation by Cristian Rigamonti E<lt>cri@linux.itE<gt>.

=back

=head1 SEE ALSO

bib2html.pl
