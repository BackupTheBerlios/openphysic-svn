# Copyright (C) 1998-06  Stephane Galland <galland@arakhne.org>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA.

=pod

=head1 NAME

Bib2HTML::Generator::Lang::French - French support for the generators

=head1 SYNOPSYS

use Bib2HTML::Generator::Lang::French ;

my $gen = Bib2HTML::Generator::Lang::French->new() ;

=head1 DESCRIPTION

Bib2HTML::Generator::Lang::French is a Perl module, which proposes
a French support for all the generators.

=head1 GETTING STARTED

=head2 Initialization

To start a generator script, say something like this:

    use Bib2HTML::Generator::Lang::French;

    my $gen = Bib2HTML::Generator::Lang::French->new() ;

...or something similar.

=head1 METHOD DESCRIPTIONS

This section contains only the methods in French.pm itself.

=over

=cut

package Bib2HTML::Generator::Lang::French;

@ISA = ('Bib2HTML::Generator::Lang');
@EXPORT = qw();
@EXPORT_OK = qw();

use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK $VERSION);
use Exporter;

use Carp ;

use Bib2HTML::Generator::Lang ;
use Bib2HTML::General::Error ;

#------------------------------------------------------
#
# Global vars
#
#------------------------------------------------------

# Version number of language support
my $VERSION = "2.0" ;

# Language definitions
my %LANG_DEFS = (
		 'I18N_LANG_ALL_ELEMENTS' => "Tous les &eacute;l&eacute;ments",
		 'I18N_LANG_ARTICLESINSAMEDOMAINS' => "Documents dans le m&ecirc;me domaine",
		 'I18N_LANG_BIB2HTML_COPYRIGHT' => ( "Ce document a &eacute;t&eacute; g&eacute;n&eacute;r&eacute; ".
						     "par #1.<BR>\n".
						     "Copyright &copy; 1998-05 #2 (licence #3)" ),
		 'I18N_LANG_FIELD_BIBTEX_VERBATIM' => "Code BibTeX",
		 'I18N_LANG_FIELD_XML_VERBATIM' => "Code XML",
		 'I18N_LANG_DEFAULT_TITLE' => "Bibliographie",
		 'I18N_LANG_DOMAIN_TREE' => "Arbre des domaines",
		 'I18N_LANG_DOMAINS' => "Domaines",
		 'I18N_LANG_ENTRY_TYPE_TREE' => "Liste hi&eacute;rarchique par type d'entr&eacute;e",
		 'I18N_LANG_FIELD_ADDRESS' => "Adresse",
		 'I18N_LANG_FIELD_ADSURL' => "Lien vers ADS",
		 'I18N_LANG_FIELD_ABSTRACT' => "R&eacute;sum&eacute;",
		 'I18N_LANG_FIELD_ABSTRACT_KEYWORDS' => "R&eacute;sum&eacute; &amp; Mots-cl&eacute;s",
		 'I18N_LANG_FIELD_ANNOTATION' => "Annotation",
		 'I18N_LANG_FIELD_AUTHORS' => "Auteur(s)",
		 'I18N_LANG_FIELD_CHAPTER' => "Chapitre de",
		 'I18N_LANG_FIELD_DATE' => "Date",
		 'I18N_LANG_FIELD_DOWNLOAD' => "T&eacute;l&eacute;charger une version compl&egrave;te de ce document&nbsp;: #1",
		 'I18N_LANG_FIELD_EDITION' => "&Eacute;dition",
		 'I18N_LANG_FIELD_EDITORS' => "R&eacute;dacteur(s) en chef",
		 'I18N_LANG_FIELD_HOWPUBLISHED' => "Moyen de publication",
		 'I18N_LANG_FIELD_IN' => "In",
		 'I18N_LANG_FIELD_INSTITUTION' => "Institution",
		 'I18N_LANG_FIELD_ISBN' => "Num&eacute;ro ISBN",
		 'I18N_LANG_FIELD_ISSN' => "Num&eacute;ro ISSN",
		 'I18N_LANG_FIELD_JOURNAL' => "Journal",
		 'I18N_LANG_FIELD_KEYWORDS' => "<strong>Mots-cl&eacute;s</strong>: #1",
		 'I18N_LANG_FIELD_KEYWORDS_TITLE' => "Mots-cl&eacute;s",
		 'I18N_LANG_FIELD_NOTE' => "Note",
		 'I18N_LANG_FIELD_NUMBER' => "Num&eacute;ro",
		 'I18N_LANG_FIELD_ORGANIZATION' => "Organisation",
		 'I18N_LANG_FIELD_PAGES' => "Page(s)",
		 'I18N_LANG_FIELD_PDFFILE' => "PDF",
		 'I18N_LANG_FIELD_PUBLISHER' => "&Eacute;diteur",
		 'I18N_LANG_FIELD_READERS' => "Lecteur(s)",
		 'I18N_LANG_FIELD_SCHOOL' => "&Eacute;cole",
		 'I18N_LANG_FIELD_SERIES' => "S&eacute;rie(s)",
		 'I18N_LANG_FIELD_TITLE' => "Titre",
		 'I18N_LANG_FIELD_TYPE' => "Type",
		 'I18N_LANG_FIELD_URL' => "URL",
		 'I18N_LANG_FIELD_VOLUME' => "Volume",
		 'I18N_LANG_FIELD_YEAR' => "Ann&eacute;e",
		 'I18N_LANG_FORMAT_NAME' => "l{ (v)}{ f.}{, j}",
		 'I18N_LANG_FORMAT_NAMES' => "{ et }{, }",
		 'I18N_LANG_FRAME_TITLE_AUTHORS' => "Auteurs",
		 'I18N_LANG_FRAME_TITLE_TYPES' => "Types",
		 'I18N_LANG_FRAMES' => "Frames",
		 'I18N_LANG_INDEX' => "Index",
		 'I18N_LANG_INDEX_COMMENT_ARTICLE' => "article",
		 'I18N_LANG_INDEX_COMMENT_AUTHOR' => "auteur",
		 'I18N_LANG_INDEX_COMMENT_BOOKTITLE' => "title de livre",
		 'I18N_LANG_INDEX_COMMENT_EDITOR' => "r&eacute;dacteur en chef",
		 'I18N_LANG_INDEX_COMMENT_HOWPUBLISHED' => "moyen de publication",
		 'I18N_LANG_INDEX_COMMENT_INSTITUTION' => "institution",
		 'I18N_LANG_INDEX_COMMENT_PUBLISHER' => "&eacute;diteur",
		 'I18N_LANG_INDEX_COMMENT_SCHOOL' => "&eacute;cole",
		 'I18N_LANG_INDEX_COMMENT_TITLE' => "titre",
		 'I18N_LANG_NEXT' => "Suivant",
		 'I18N_LANG_NO_DATE' => "Non dat&eacute;",
		 'I18N_LANG_NO_FRAME' => "Pas de Frame",
		 'I18N_LANG_NO_FRAME_ALERT' => ( "<H2>Support des cadres</H2>\n".
						 "<P>Ce document est con&ccedil; pour &ecirc;tre ".
						 "visualis&eacute; avec des cadres (frames). ".
						 "Le fait de lire ce message indique que vous ".
						 "utilis&eacute; un navigateur ne supportant ".
						 "pas les frames.<BR>\n".
						 "Lien vers la <A HREF=\"#1\">".
						 "version sans frame.</A>.<BR>\n#2" ),
		 'I18N_LANG_OVERVIEW' => "Page principale",
		 'I18N_LANG_P_ARTICLE' => "Articles",
		 'I18N_LANG_P_BOOK' => "Livres",
		 'I18N_LANG_P_BOOKLET' => "Livres sans �diteur",
		 'I18N_LANG_P_INBOOK' => "Parties de livre",
		 'I18N_LANG_P_INCOLLECTION' => "Articles dans des collections",
		 'I18N_LANG_P_INPROCEEDINGS' => "Articles dans des actes de conf&eacute;rences",
		 'I18N_LANG_P_MANUAL' => "Manuels techniques",
		 'I18N_LANG_P_MASTERTHESIS' => "M&eacute;moire d'ing&eacute;nieur",
		 'I18N_LANG_P_MISC' => 'Documents divers',
		 'I18N_LANG_P_PHDTHESIS' => "M&eacute;moires de recherche",
		 'I18N_LANG_P_PROCEEDINGS' => "Actes de conf�rences",
		 'I18N_LANG_P_TECHREPORT' => "Documentations techniques",
		 'I18N_LANG_P_UNPUBLISHED' => "Non publi&eacute;s",
		 'I18N_LANG_PREV' => "Pr&eacute;d",
		 'I18N_LANG_TREE' => "Arbre",
		 'I18N_LANG_S_ARTICLE' => "Article",
		 'I18N_LANG_S_BOOK' => "Livre",
		 'I18N_LANG_S_BOOKLET' => "Livre sans �diteur",
		 'I18N_LANG_S_INBOOK' => "Partie de livre",
		 'I18N_LANG_S_INCOLLECTION' => "Article dans une collection",
		 'I18N_LANG_S_INPROCEEDINGS' => "Article dans des actes de conf&eacute;rence",
		 'I18N_LANG_S_MANUAL' => "Manuel technique",
		 'I18N_LANG_S_MASTERTHESIS' => "M&eacute;moire d'ing�nieur",
		 'I18N_LANG_S_MISC' => 'Document divers',
		 'I18N_LANG_S_PHDTHESIS' => "M&eacute;moire de recherche",
		 'I18N_LANG_S_PROCEEDINGS' => "Actes de confi&eacute;rence",
		 'I18N_LANG_S_TECHREPORT' => "Rapport technique",
		 'I18N_LANG_S_UNPUBLISHED' => "Non publi&eacute;",
		 'I18N_LANG_SMALL_IN' => "in:&nbsp;#1",
		 'I18N_LANG_SUBMIT_BUG' => "Soumettre un bug",
		) ;

#------------------------------------------------------
#
# Constructor
#
#------------------------------------------------------

sub new($$) : method {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = $class->SUPER::new("French",\%LANG_DEFS) ;
  bless( $self, $class );
  return $self;
}

1;
__END__

=back

=head1 COPYRIGHT

(c) Copyright 1998-06 St�phane Galland <galland@arakhne.org>, under GPL.

=head1 AUTHORS

=over

=item *

Conceived and initially developed by St�phane Galland E<lt>galland@arakhne.orgE<gt>.

=back

=head1 SEE ALSO

bib2html.pl
