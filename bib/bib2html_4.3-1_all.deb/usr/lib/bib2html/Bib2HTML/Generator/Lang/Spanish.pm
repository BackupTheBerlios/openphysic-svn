# Copyright (C) 1998-06  Stephane Galland <galland@arakhne.org>
#                        Sebastian Rodriguez <sebastian.rodriguez@utbm.fr>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA.

=pod

=head1 NAME

Bib2HTML::Generator::Lang::Spanish - Spanish support for the generators

=head1 SYNOPSYS

use Bib2HTML::Generator::Lang::Spanish ;

my $gen = Bib2HTML::Generator::Lang::Spanish->new() ;

=head1 DESCRIPTION

Bib2HTML::Generator::Lang::Spanish is a Perl module, which proposes
a Spanish support for all the generators. It was initially written
by Sebastian Rodriguez.

=head1 GETTING STARTED

=head2 Initialization

To start a generator script, say something like this:

    use Bib2HTML::Generator::Lang::Spanish;

    my $gen = Bib2HTML::Generator::Lang::Spanish->new() ;

...or something similar.

=head1 METHOD DESCRIPTIONS

This section contains only the methods in Spanish.pm itself.

=over

=cut

package Bib2HTML::Generator::Lang::Spanish;

@ISA = ('Bib2HTML::Generator::Lang');
@EXPORT = qw();
@EXPORT_OK = qw();

use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK $VERSION);
use Exporter;

use Carp ;

use Bib2HTML::Generator::Lang ;
use Bib2HTML::General::Error ;

#------------------------------------------------------
#
# Global vars
#
#------------------------------------------------------

# Version number of language support
my $VERSION = "2.0" ;

# Language definitions
my %LANG_DEFS = (
		 'I18N_LANG_ALL_ELEMENTS' => "Todos los Elemnetos",
		 'I18N_LANG_ARTICLESINSAMEDOMAINS' => "Documentos en el mismo dominio",
		 'I18N_LANG_BIB2HTML_COPYRIGHT' => ( "Este documento fue generado por #1.<BR>\n".
						     "Copyright &copy; 1998-05 #2 (Bajo #3)" ),
		 'I18N_LANG_FIELD_BIBTEX_VERBATIM' => "BibTeX",
		 'I18N_LANG_FIELD_XML_VERBATIM' => "XML",
		 'I18N_LANG_DEFAULT_TITLE' => "Bibliograf&iacute;a",
		 'I18N_LANG_DOMAIN_TREE' => "Domain Tree",
		 'I18N_LANG_DOMAINS' => "Dominios",
		 'I18N_LANG_ENTRY_TYPE_TREE' => "Lista por tipos de Entada",
		 'I18N_LANG_FIELD_ADDRESS' => "Direcci&oacute;n",
		 'I18N_LANG_FIELD_ADSURL' => "Acoplamiento al ADS",
		 'I18N_LANG_FIELD_ABSTRACT' => "Resumen",
		 'I18N_LANG_FIELD_ABSTRACT_KEYWORDS' => "Resumen y Palabras Claves",
		 'I18N_LANG_FIELD_ANNOTATION' => "Comentario",
		 'I18N_LANG_FIELD_AUTHORS' => "Autor(es)",
		 'I18N_LANG_FIELD_CHAPTER' => "Capitulo de",
		 'I18N_LANG_FIELD_DATE' => "Fecha",
		 'I18N_LANG_FIELD_DOWNLOAD' => "Descargar el articulo completo: #1",
		 'I18N_LANG_FIELD_EDITION' => "Edici&oacute;n",
		 'I18N_LANG_FIELD_EDITORS' => "Redactor en Jefe",
		 'I18N_LANG_FIELD_HOWPUBLISHED' => "How published",
		 'I18N_LANG_FIELD_IN' => "En",
		 'I18N_LANG_FIELD_INSTITUTION' => "Instituci&oacute;n",
		 'I18N_LANG_FIELD_ISBN' => "N&uacute;mero ISBN",
		 'I18N_LANG_FIELD_ISSN' => "N&uacute;mero ISSN",
		 'I18N_LANG_FIELD_JOURNAL' => "Revista",
		 'I18N_LANG_FIELD_KEYWORDS' => "<strong>Palabras claves</strong>: #1",
		 'I18N_LANG_FIELD_KEYWORDS_TITLE' => "Palabras claves",
		 'I18N_LANG_FIELD_NOTE' => "Nota",
		 'I18N_LANG_FIELD_NUMBER' => "N&uacute;mero",
		 'I18N_LANG_FIELD_ORGANIZATION' => "Organizaci&oacute;n",
		 'I18N_LANG_FIELD_PAGES' => "P&aacute;gina(s)",
		 'I18N_LANG_FIELD_PDFFILE' => "PDF",
		 'I18N_LANG_FIELD_PUBLISHER' => "Editor",
		 'I18N_LANG_FIELD_READERS' => "Lectore(s)",
		 'I18N_LANG_FIELD_SCHOOL' => "Escuela",
		 'I18N_LANG_FIELD_SERIES' => "Serie",
		 'I18N_LANG_FIELD_TITLE' => "T&iacute;tulo",
		 'I18N_LANG_FIELD_TYPE' => "Tipo",
		 'I18N_LANG_FIELD_URL' => "URL",
		 'I18N_LANG_FIELD_VOLUME' => "Volumen",
		 'I18N_LANG_FIELD_YEAR' => "A&ntilde;o",
		 'I18N_LANG_FORMAT_NAME' => "l{ (v)}{ f.}{, j}",
		 'I18N_LANG_FORMAT_NAMES' => "{ y }{, }",
		 'I18N_LANG_FRAME_TITLE_AUTHORS' => "Autores",
		 'I18N_LANG_FRAME_TITLE_TYPES' => "Tipos",
		 'I18N_LANG_FRAMES' => "Frames",
		 'I18N_LANG_INDEX' => "Indice",
		 'I18N_LANG_INDEX_COMMENT_ARTICLE' => "artiuclo",
		 'I18N_LANG_INDEX_COMMENT_AUTHOR' => "autor",
		 'I18N_LANG_INDEX_COMMENT_BOOKTITLE' => "titulo del libro",
		 'I18N_LANG_INDEX_COMMENT_EDITOR' => "Redactor jefe",
		 'I18N_LANG_INDEX_COMMENT_HOWPUBLISHED' => "forma de publicaci&oacute;n",
		 'I18N_LANG_INDEX_COMMENT_INSTITUTION' => "instituci&oacute;n",
		 'I18N_LANG_INDEX_COMMENT_PUBLISHER' => "Editor",
		 'I18N_LANG_INDEX_COMMENT_SCHOOL' => "escuela",
		 'I18N_LANG_INDEX_COMMENT_TITLE' => "titulo",
		 'I18N_LANG_NEXT' => "Siguiente",
		 'I18N_LANG_NO_DATE' => "Sin Fecha",
		 'I18N_LANG_NO_FRAME' => "No Frame",
		 'I18N_LANG_NO_FRAME_ALERT' => ( "<H2>Frame Alert</H2>\n".
						 "<P>Este documento fue dise&ntilde;ando para ser ".
						 "visualizado usando Frames ".
						 ". Si esta viendo este mensaje, ".
						 "esta usando un ".
						 "web browser sin soporte para los Frames.<BR>\n".
						 "Vinculo a <A HREF=\"#1\">".
						 "la versi&oacute;n sin Frames.</A>.<BR>\n#2" ),
		 'I18N_LANG_OVERVIEW' => "Visi&oacute;n General",
		 'I18N_LANG_P_ARTICLE' => "Articulos",
		 'I18N_LANG_P_BOOK' => "Libros",
		 'I18N_LANG_P_BOOKLET' => "Libros Sin Sponsord",
		 'I18N_LANG_P_INBOOK' => "Partes de Libros",
		 'I18N_LANG_P_INCOLLECTION' => "En colecci&oacute;n",
		 'I18N_LANG_P_INPROCEEDINGS' => "En proceedings",
		 'I18N_LANG_P_MANUAL' => "Manuales T&eacute;cnicos",
		 'I18N_LANG_P_MASTERTHESIS' => "Tesis de Master",
		 'I18N_LANG_P_MISC' => 'Documentos miscel&aacute;neos',
		 'I18N_LANG_P_PHDTHESIS' => "Tesis Doctorales",
		 'I18N_LANG_P_PROCEEDINGS' => "Conference proceedings",
		 'I18N_LANG_P_TECHREPORT' => "Reportes T&eacute;cnicos",
		 'I18N_LANG_P_UNPUBLISHED' => "In&eacute;dito",
		 'I18N_LANG_PREV' => "Anterior",
		 'I18N_LANG_TREE' => "Tree",
		 'I18N_LANG_S_ARTICLE' => "Articulo",
		 'I18N_LANG_S_BOOK' => "Libro",
		 'I18N_LANG_S_BOOKLET' => "Not-sponsored book",
		 'I18N_LANG_S_INBOOK' => "Parte de Libro",
		 'I18N_LANG_S_INCOLLECTION' => "En una colecci&oacute;n",
		 'I18N_LANG_S_INPROCEEDINGS' => "En proceedings",
		 'I18N_LANG_S_MANUAL' => "Manual T&eacute;cnico",
		 'I18N_LANG_S_MASTERTHESIS' => "T&eacute;sis de Master",
		 'I18N_LANG_S_MISC' => 'Documento Miscelaneo',
		 'I18N_LANG_S_PHDTHESIS' => "T&eacute;sis Doctoral",
		 'I18N_LANG_S_PROCEEDINGS' => "Conference proceedings",
		 'I18N_LANG_S_TECHREPORT' => "Reporte T&eacute;cnico",
		 'I18N_LANG_S_UNPUBLISHED' => "In&eacute;dito",
		 'I18N_LANG_SMALL_IN' => "en:&nbsp;#1",
		 'I18N_LANG_SUBMIT_BUG' => "Reportar un bug",
		) ;

#------------------------------------------------------
#
# Constructor
#
#------------------------------------------------------

sub new($$) : method {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = $class->SUPER::new("Spanish",\%LANG_DEFS) ;
  bless( $self, $class );
  return $self;
}

1;
__END__

=back

=head1 COPYRIGHT

(c) Copyright 1998-06 St�phane Galland E<lt>galland@arakhne.orgE<gt> and
                      Sebastian Rodriguez E<lt>sebastian.rodriguez@utbm.frE<gt>, under GPL.

=head1 AUTHORS

=over

=item *

Conceived and initially developed by St�phane Galland E<lt>galland@arakhne.orgE<gt>.
Spanish translation by Sebastian Rodriguez E<lt>sebastian.rodriguez@utbm.frE<gt>.

=back

=head1 SEE ALSO

bib2html.pl
